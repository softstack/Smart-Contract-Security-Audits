Major contracts are in the root directory for this presale release. The 'tokens' and 'uniswap' folder contains useful scripts
for testing. Some files in the 'uniswap' folder have been renamed to remove naming conflicts when deploying all contracts.

The 'tokens' folder contains 3 of the simplest tokens I could find with rebasing and fee on transfer mechanisms,
Base2 - rebasing
BombV3 - fee on transfer
Dexttools - does not strictly comply with ERC20 standards (especially the transfer function)

For a presale there is two elements
Base token - the token being raised. If this is set to the WETH9 address the presale is in ETH
Sale token - The token being sold. 

While the sale token can be anything including rebasing and deflationary fee on transfer tokens, 
the base token should never be a rebasing token, as the price is fixed in a presale and the addLiquidity function will 
fail if lets say it rebases -80% and the set liquidity to be locked cant be met. Base tokens should always be normal tokens or 
minor fee on transfer tokens,
e.g. WETH, DAI, USDC, WBTC

*****************************
Order to release contracts in
*****************************

** Changes for mainnet release
On release change presale settings ROUND1_LENGTH

1. Deploy WETH9.sol

2. Deploy UniswapV2Factory.sol

3. Deploy UniswapV2Locker.sol (adding in uniswap factory address)

4. Deploy PresaleSettings.sol

5. Deploy PresaleFactory.sol

6. In PresaleLockForwarder.sol
   -- add in the constructor hardcoded PresaleFactory UnicryptLocker, Uniswap factory address
   -- Deploy

7. In Presale01.sol
   -- Add in the constructor the hardcoded UniswapFactory, WETH, PresaleSettings, PresaleLockForwarder address, Any Dev address

8. In PresaleGenerator01.sol
  -- Add in the constructor hardcoded PresaleFactory, PresaleSettings address
  -- deploy PresaleGenerator01.sol

9. In PresaleFactory.sol
  -- call 'adminAllowPresaleGenerator' function passing in (address PresaleGenerator01, true)

10. In UniswapV2Locker.sol
  -- call 'whitelistFeeAccount' with args (address PresaleLockForwarder, true)