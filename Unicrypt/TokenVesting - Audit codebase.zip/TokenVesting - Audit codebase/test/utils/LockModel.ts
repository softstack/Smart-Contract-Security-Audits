// const { ethers } = require("hardhat")

const Self = {
  getLock: async (vestingContract, lockID) => {
    var lock = await vestingContract.getLock(lockID)
    return {
      lockID: lock[0].toNumber(),
      address: lock[1],
      tokensDeposited: lock[2].toString(),
      tokensWithdrawn: lock[3].toString(),
      sharesDeposited: lock[4].toString(),
      sharesWithdrawn: lock[5].toString(),
      startEmission: lock[6].toNumber(),
      endEmission: lock[7].toNumber(),
      owner: lock[8],
      condition: lock[9]
    }
  },
  getFees: async (vestingContract) => {
    var feeStruct = await vestingContract.FEES()
    return {
      tokenFee: feeStruct[0].toString(),
      freeLockingFee: feeStruct[1].toString(),
      feeAddress: feeStruct[2],
      freeLockingToken: feeStruct[3]
    }
  }
}

module.exports = Self