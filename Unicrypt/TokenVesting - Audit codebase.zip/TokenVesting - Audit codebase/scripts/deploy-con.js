// We require the Hardhat Runtime Environment explicitly here. This is optional 
// but useful for running the script in a standalone fashion through `node <script>`.
//
// When running the script with `hardhat run <script>` you'll find the Hardhat
// Runtime Environment's members available in the global scope.
const hre = require("hardhat");

async function main() {
  // Hardhat always runs the compile task when running scripts with its command
  // line interface.
  //
  // If this script is run directly using `node` you may want to call compile 
  // manually to make sure everything is compiled
  // await hre.run('compile');

  // We get the contract to deploy

  const UAdminContract = await hre.ethers.getContractFactory("UnicryptAdmin");
  const UNI_ADMIN  = await UAdminContract.deploy();
  await UNI_ADMIN.deployed();

  const TokenVestingContract = await hre.ethers.getContractFactory("TokenVesting");
  const TOKEN_VESTING = await TokenVestingContract.deploy(UNI_ADMIN.address);
  await TOKEN_VESTING.deployed();

  const TokenVestingPager = await hre.ethers.getContractFactory("TokenVestingPager");
  const TOKEN_VESTING_PAGER = await TokenVestingPager.deploy(TOKEN_VESTING.address);
  await TOKEN_VESTING_PAGER.deployed();

  console.log("Unicrypt Admin:", UNI_ADMIN.address);
  console.log("Token Vesting:", TOKEN_VESTING.address);
  console.log("Pager:", TOKEN_VESTING_PAGER.address);
  console.log("Done");
}

// We recommend this pattern to be able to use async/await everywhere
// and properly handle errors.
main()
  .then(() => {
    // process.exit(0)
  })
  .catch(error => {
    console.error(error);
    process.exit(1);
  });
