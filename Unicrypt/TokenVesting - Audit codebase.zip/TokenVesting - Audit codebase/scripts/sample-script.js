// We require the Hardhat Runtime Environment explicitly here. This is optional 
// but useful for running the script in a standalone fashion through `node <script>`.
//
// When running the script with `hardhat run <script>` you'll find the Hardhat
// Runtime Environment's members available in the global scope.
const hre = require("hardhat");

async function main() {
  // Hardhat always runs the compile task when running scripts with its command
  // line interface.
  //
  // If this script is run directly using `node` you may want to call compile 
  // manually to make sure everything is compiled
  // await hre.run('compile');

  // We get the contract to deploy
  const UAdminContract = await hre.ethers.getContractFactory("UnicryptAdmin");
  const uAdmin = await UAdminContract.deploy();
  await uAdmin.deployed();

  const TokenVestingContract = await hre.ethers.getContractFactory("TokenVesting");
  const tokenVesting = await TokenVestingContract.deploy(uAdmin.address);
  await tokenVesting.deployed();

  console.log(await tokenVesting.getWhitelistedUsersLength())

  console.log("TokenVesting deployed to:", tokenVesting.address);
  console.log("Done");
  
  const Greeter = await hre.ethers.getContractFactory("Greeter");
  const greeter = await Greeter.deploy("Hello, Hardhat!");

  await greeter.deployed();

  console.log("Greeter deployed to:", greeter.address);
}

// We recommend this pattern to be able to use async/await everywhere
// and properly handle errors.
main()
  .then(() => process.exit(0))
  .catch(error => {
    console.error(error);
    process.exit(1);
  });
