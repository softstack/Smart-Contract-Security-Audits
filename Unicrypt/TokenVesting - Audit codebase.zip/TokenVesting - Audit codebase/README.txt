// Useful commands
npx hardhat compile
npx hardhat test

npx hardhat node

// For deployment in remix,
// First Deploy UnicryptAdmin.sol
// Then Deploy TokenVesting.sol

Scope of this audit, TokenVesting contract, and FullMath (for phantom overflow)
FullMath was ported to solidity 0.8 although uniswap v3 uses a prior solidity version
You can ignore other contracts such as TokenBlacklist, Migrator, And Conditions
Although ConditionLight costs about 24$ to deploy, im sure many users will use this as a switch
for premature unlocking conditions.

About the contract. Token vesting using shares. This allows rebasing, and high deflationary token support in the same way as uniswap pools work.
Two types of locks. A normal lock whereby the tokens are withdrawable on end date
A linear scaling lock where every second you can withdraw more locks

Send multiple locks at once (e.g. 12 locks for every month of the year)