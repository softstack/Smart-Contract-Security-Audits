module.exports = {
  mocha: {
    timeout: 30000
  },
  skipFiles: ['mocks']
}
