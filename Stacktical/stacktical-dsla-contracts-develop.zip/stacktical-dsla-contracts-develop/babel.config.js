module.exports = {
  presets: [['@babel/preset-env']],
  plugins: ['@babel/plugin-proposal-async-generator-functions'],
};
