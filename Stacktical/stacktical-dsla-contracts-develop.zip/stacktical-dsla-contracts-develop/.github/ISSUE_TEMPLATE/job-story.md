---
name: JOB STORY
about: Use this template to streamline the creation of job stories.

---

## JOB STORY
#### DESCRIPTION

When `<persona>` `<usage context>`, `<persona>` wants to `<motivation>` so that `<expected outcome>`

#### ACCEPTANCE CRITERIA

* `<persona>` is able to `<outcome>` 1
* `<persona>` is able to `<outcome>` 2  
...
* `<persona>` is able to `<outcome>` n
