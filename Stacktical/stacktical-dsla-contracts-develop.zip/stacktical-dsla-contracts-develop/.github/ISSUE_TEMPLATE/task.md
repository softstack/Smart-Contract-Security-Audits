---
name: TASK
about: Use this template to streamline the creation of tasks and reference their job
  story.

---

## TASK
#### DESCRIPTION

`<task description>`

#### JOB STORY

`<job story issue link>`
