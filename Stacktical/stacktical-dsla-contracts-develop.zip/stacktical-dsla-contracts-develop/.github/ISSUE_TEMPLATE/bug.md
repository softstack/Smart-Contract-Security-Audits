---
name: BUG
about: Use this template to streamline the logging of bugs.

---

## BUG

#### EXPECTED BEHAVIOUR

#### CURRENT BEHAVIOUR

#### STEPS TO REPRODUCE
