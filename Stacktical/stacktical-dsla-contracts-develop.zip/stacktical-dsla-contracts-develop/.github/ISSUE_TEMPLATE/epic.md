---
name: EPIC
about: Use this template to streamline the creation of epics.

---

## EPIC
#### DESCRIPTION

`<epic description>`
