import generateWeeklyPeriods from './generateWeeklyPeriods';

export {
  // eslint-disable-next-line import/prefer-default-export
  generateWeeklyPeriods,
};
