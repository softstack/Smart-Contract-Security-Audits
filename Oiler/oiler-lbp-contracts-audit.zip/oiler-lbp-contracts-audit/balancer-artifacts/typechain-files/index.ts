import { BFactory__factory } from "./factories/BFactory__factory";
import { BRegistry__factory } from "./factories/BRegistry__factory";
import { CRPFactory__factory } from "./factories/CRPFactory__factory";

export { BFactory__factory, BRegistry__factory, CRPFactory__factory };
