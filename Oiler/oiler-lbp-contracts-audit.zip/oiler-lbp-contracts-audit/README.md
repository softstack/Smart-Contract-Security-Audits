# Oiler LBP Controller

## 0. If you want to have Balancer & Uniswap locally, you need to use ones from oiler-contracts:
```
git clone https://github.com/DemerzelSolutions/oiler-contracts.git
npm run deploy
it will show you all the addresses and saves them to addressBook.json - copy them to addressBook.json of this repo for the local network (1337)
```

## 1. Clone the repo
```
git clone https://github.com/DemerzelSolutions/oiler-lbp-contracts.git
```

## 2. Do npm install
```
npm install
```

## 3. Create `.env` and fill it, based on `.env.example`
```
Specify the OWNER if you want a multisig to be an owner of the LBP otherwise the deployer will become the owner.
```

## 4. Edit `constants.ts/LBP_CONSTANTS` if you need to modify startBlock/endBlock for testing
```
  {
    startBlock: ...,
    endBlock:...,
  }
```

## 5. If you want to use the existing token or usdc address - specify it in the `addressBook.json`. Otherwise the new Mock token will be created and used.

## 6. Load some ETH to your deployer address (which you listed in `.env`)

## 7. Run the LBPController deployment script:
```
npx hardhat run scripts/1_deploy_LBPController.ts --network kovan
```

## 8a. If you're doing Multisig deployment on mainnet - next you need to interact with the newly deployed LBPController using your Multisig interface:
```
a) approve the needed amount of USDC for LBPController from your Multisig
b) approve the needed amount of Tokens for LBPController from your Multisig
c) call LBPController.createSmartPool() from your Multisig
```

## 8b. If you're just testing on Testnet, you can create a pool with script:
```
npx hardhat run scripts/2_createLBP.ts --network kovan
```

## 9. When the time comes to start the weight changes - call startPool from any address:
```
call LBPController.startPool() from any address
or run
npx hardhat run scripts/3_startLBP.ts
```

## 10. Set up Poke Weights in OZ Defender
a) Setup a new Open Zeppelin Defender account.
b) Go to Relay view.
![alt text](https://github.com/DemerzelSolutions/oiler-lbp-contracts/blob/uniswap-migration-split/.github/defender-relayer-view.png?raw=true)
c) Create a new relayer.
![alt text](https://github.com/DemerzelSolutions/oiler-lbp-contracts/blob/uniswap-migration-split/.github/defender-relayer-creation-modal.png?raw=true)
d) Send some ETH to the relayer's address.
e) Go to autotasks.
![alt text](https://github.com/DemerzelSolutions/oiler-lbp-contracts/blob/uniswap-migration-split/.github/defender-autotaks-view.png?raw=true)
f) Create a new autotask and choose the previously created relayer as relayer.
![alt text](https://github.com/DemerzelSolutions/oiler-lbp-contracts/blob/uniswap-migration-split/.github/defender-autotask-creation.png?raw=true)
g) Fill the code box with the following code:
```
const { Relayer } = require('defender-relay-client');

exports.handler = async function(credentials) {
  const relayer = new Relayer(credentials);

  const txRes = await relayer.sendTransaction({
    to: '<LBPController address>',
    value: 0,
    speed: 'fast',
    gasLimit: '300000',
    data: "0xe211b875"
  });

  console.log(txRes);
  return txRes.hash;
}
```


## 11. When LBP ends - call endPool from any address:
```
call LBPController.endPool() from any address
```

## 12. Ending a pool will kill it and give the Multisig owner all the funds that were there - Tokens and USDC.

## 13. Consider adding liquidity to Uniswap with a UniswapMigration contract:
```
call UniswapMigration.migrate() - TBD
```