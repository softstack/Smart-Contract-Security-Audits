import { Signer } from "ethers";

// @ts-ignore
import { ethers } from "hardhat";
import { LBPController__factory, BPool__factory } from "../typechain";
import { loadAddressBook, saveAddressBook } from "../utils/addressBookManager";

export async function main() {
  const signer: Signer = (await ethers.getSigners())[1]; // Use Wallet 1 as the Owner of the LBP
  const net = await signer.provider.getNetwork();

  const addressBook = loadAddressBook(net.chainId);
  const addresses = addressBook[net.chainId];

  if (!addresses || !addresses["LBPController"]) {
    throw new Error("No entry in address book");
  }
  const LBPController = (await ethers.getContractFactory(
    "LBPController"
  )) as LBPController__factory;
  const lbpController = LBPController.attach(addresses["LBPController"]);

  console.log("Current block:", (await signer.provider.getBlock("latest")).number)
  console.log("LBP Start block:", (await lbpController.connect(signer).startBlock()).toString())
  
  // TODO: Assert currentBlock >= LBP start block

  const tx = await lbpController.connect(signer).startPool();
  console.log(await tx.wait())

  // TODO: Assert publicSwap was set to True
  const isPublicSwap = await (BPool__factory.connect(await lbpController.pool(), signer)).isPublicSwap();

  console.log("isPublicSwap:", isPublicSwap)

  console.log("LBP Started!");
  addressBook[net.chainId] = addresses;
  saveAddressBook(addressBook);
}