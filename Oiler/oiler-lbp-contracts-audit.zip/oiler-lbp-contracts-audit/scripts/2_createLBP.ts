import * as dotenv from "dotenv";
dotenv.config();

// @ts-ignore
import { ethers, hardhatArguments } from "hardhat";

import { LBPController__factory, Token, BFactory__factory } from "../typechain";
import { ConfigurableRightsPool__factory as CRP__factory } from "../typechain";

import { Token__factory, BPool__factory, BPool } from "../typechain";

import { ContractTransaction, Signer, BigNumber } from "ethers";

import { loadEnv } from "../utils/loadEnv";
import { loadEnvLbpParams } from "../utils/load-env-lbp-params";

import { loadAddressBook, saveAddressBook } from "../utils/addressBookManager";
import { expect } from "chai";

export async function main() {
  const BONE = BigNumber.from(10).pow(BigNumber.from(18));
  let bPool: BPool;

  loadEnv(hardhatArguments.network);

  const { lbpStartBlock,
    lbpOwner,
    lbpEndBlock,
    lbpStartTokenWeight,
    lbpStartCollateralWeight,
    lbpEndTokenWeight,
    lbpEndCollateralWeight,
    lbpSwapFee } = loadEnvLbpParams();

  const signer: Signer = (await ethers.getSigners())[1]; // Use Wallet 1 as the Owner of the LBP
  const signerAddress = await signer.getAddress();
  console.log("signerAddress:", signerAddress);
  const net = await signer.provider.getNetwork();

  const addressBook = loadAddressBook(net.chainId);
  const addresses = addressBook[net.chainId];

  // Ensure address book.
  if (!addresses) {
    throw new Error(`No addresses found for net id${net.chainId}`);
  }
  if (!addresses["CRPFactory"]) {
    throw new Error("Address for CRP factory not found");
  }
  if (!addresses["BRegistry"]) {
    throw new Error("Address for BRegistry not found");
  }
  if (!addresses["BFactory"]) {
    throw new Error("Address for BFactory not found");
  }
  if (!addresses["token"]) {
    throw new Error("Address for Token not found");
  }
  if (!addresses["USDC"]) {
    throw new Error("Address for USDC not found");
  }
  if (!addresses["LBPController"]) {
    throw new Error("Address for LBPController not found");
  }

  // Initialize token and usdc collateral.
  const Token = (await ethers.getContractFactory("Token")) as Token__factory;

  let tx: ContractTransaction;

  const token = Token.attach(addresses["token"]);
  let tokenAmount = BigNumber.from(process.env.LBP_TOKEN_AMOUNT).mul(
    BigNumber.from(10).pow(await token.decimals())
  );

  const usdc = Token.attach(addresses["USDC"]);
  let usdcAmount = BigNumber.from(process.env.LBP_COLLATERAL_AMOUNT).mul(
    BigNumber.from(10).pow(await usdc.decimals())
  );

  // Create LBP Controller instance.
  const LBPController = (await ethers.getContractFactory(
    "LBPController"
  )) as LBPController__factory;
  const lbpController = LBPController.attach(addresses["LBPController"]);
  const lbpControllerOwner = await lbpController.owner();

  // Ensure token allowance is set.
  console.log("tokenAddress:\t\t", addresses["token"]);
  console.log("tokenAmount:\t\t", tokenAmount.toString());
  console.log(
    "tokenBalance:\t\t",
    (await token.connect(signer).balanceOf(signerAddress)).toString()
  );
  console.log("usdcBalance:\t\t", (await usdc.connect(signer).balanceOf(signerAddress)).toString());

  console.log("lbpController.address:", lbpController.address);
  if ((await token.allowance(lbpControllerOwner, lbpController.address)).lt(tokenAmount)) {
    if (signerAddress.toLocaleLowerCase() === lbpControllerOwner.toLocaleLowerCase()) {
      tx = await token.connect(signer).approve(lbpController.address, tokenAmount);
      await tx.wait();
      console.log(`Approved LBP controller to spend ${tokenAmount} Tokens`);
    } else {
      throw new Error("Unable to set required allowance for tx");
    }
  }
  // Ensure usdc allowance is set.
  if ((await usdc.allowance(lbpControllerOwner, lbpController.address)).lt(usdcAmount)) {
    if (signerAddress.toLocaleLowerCase() === lbpControllerOwner.toLocaleLowerCase()) {
      tx = await usdc.connect(signer).approve(lbpController.address, usdcAmount);
      await tx.wait();
      console.log(`Approved LBP controller to spend ${usdcAmount} USDC`);
    } else {
      throw new Error("Unable to set required allowance for tx");
    }
  }

  expect((await usdc.allowance(lbpControllerOwner, lbpController.address)).gte(usdcAmount)).to.be.true;
  expect((await token.allowance(lbpControllerOwner, lbpController.address)).gte(tokenAmount)).to.be.true;
  expect((await usdc.balanceOf(lbpControllerOwner)).gte(usdcAmount), `Expected lbpControllerOwner to be greater than usdcAmount ${usdcAmount.toString()}`).to.be.true;
  expect((await token.balanceOf(lbpControllerOwner)).gte(tokenAmount), `Expected lbpControllerOwner token amount to be greater than ${tokenAmount.toString()}`).to.be.true;
  // Create CRP.
  console.log(`Creating CRP ...`);

  expect((await signer.provider.getBlock("latest")).number).to.be.lt(BigNumber.from(process.env.LBP_START_BLOCK).toNumber());

  tx = await lbpController.connect(signer).createSmartPool();
  await tx.wait();

  const crpAddress = await lbpController.crp();
  console.log(`CRP created at address ${crpAddress}`);
  const crp = CRP__factory.connect(crpAddress, signer);

  // TODO assertions of below.
  // const fetchedGradualUpdate = await crp.gradualUpdate();
  const rights = {
    canPauseSwapping: true,
    canChangeSwapFee: false,
    canChangeWeights: true,
    canAddRemoveTokens: true,
    canWhitelistLPs: true,
    canChangeCap: false
  }
  const fetchedRights = await crp.rights();
  const keys = Object.keys(fetchedRights).filter(key => isNaN(key as any));
  const fetchedRightsCopy = {}
  keys.forEach(key => fetchedRightsCopy[key] = fetchedRights[key]);

  expect(fetchedRightsCopy).deep.equal(rights);
  
  expect((await crp.bFactory()).toLowerCase()).eq(addresses["BFactory"].toLowerCase());

  expect((await crp.minimumWeightChangeBlockPeriod()).toNumber()).eq(lbpEndBlock-lbpStartBlock-1);
  expect((await crp.addTokenTimeLockInBlocks()).toNumber()).eq(lbpEndBlock-lbpStartBlock-1);

  // Load bPool.
  const bPoolAddress = await crp.bPool();
  bPool = await BPool__factory.connect(bPoolAddress, signer);

  expect(await bPool.isPublicSwap()).eq(false);
  expect(await bPool.isFinalized()).eq(false);

  expect((await bPool.getNumTokens()).toString()).eq('2');
  
  let currentTokens = await bPool.getCurrentTokens();
  expect(currentTokens).contains(token.address);
  expect(currentTokens).contains(usdc.address);

  expect((await bPool.getDenormalizedWeight(token.address)).toString()).eq(BONE.mul(lbpStartTokenWeight).toString());
  expect((await bPool.getDenormalizedWeight(usdc.address)).toString()).eq(BONE.mul(lbpStartCollateralWeight).toString());

  expect((await usdc.balanceOf(bPoolAddress)).toString()).eq(usdcAmount.toString());
  expect((await (await token.balanceOf(bPoolAddress)).toString())).eq(tokenAmount.toString());

  expect((await bPool.getSwapFee()).toString()).eq(BONE.mul(lbpSwapFee*10000).div(10000).toString());
  expect((await bPool.getController()).toString()).eq(crpAddress.toString());


  // Register pool.
  console.log(`Registering pool ...`);
  tx = await lbpController.connect(signer).registerPool();
  await tx.wait();
  const listed = await lbpController.listed();
  console.log(`Pool registered`);

  // TODO: Is it easy to assert the registry if the pool is really registered?


  addresses["token"] = token.address;
  addresses["USDC"] = usdc.address;
  addresses["LBPController"] = lbpController.address;
  addresses["CRP"] = crp.address;
  addresses["Pool"] = bPoolAddress;
  addresses["Listed"] = listed.toNumber().toString();

  addressBook[net.chainId] = addresses;
  saveAddressBook(addressBook);
}
