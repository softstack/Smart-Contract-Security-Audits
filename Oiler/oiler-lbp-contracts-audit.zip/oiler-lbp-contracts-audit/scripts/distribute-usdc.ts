import * as fs from "fs";
// @ts-ignore
import { ethers } from "hardhat";

import * as path from "path";
import * as papaparse from "papaparse";
import { BigNumber, Signer } from "ethers";
import { Token__factory } from "../typechain";
import { loadAddressBook, saveAddressBook } from "../utils/addressBookManager";

export async function main() {
  const signer: Signer = (await ethers.getSigners())[0];
  const net = await signer.provider.getNetwork();

  const addressBook = loadAddressBook(net.chainId);
  const addresses = addressBook[net.chainId];

  if (!addresses || !addresses["USDC"]) {
    throw new Error("No entry in address book");
  }

  const csvUsdcDistribution = fs.readFileSync(path.join(__dirname, "../usdcDistribution.csv"), {
    encoding: "utf8",
  });
  const data = papaparse.parse(csvUsdcDistribution, {
    delimiter: ",",
    header: true,
    skipEmptyLines: true,
  }).data;
  const usdcDistributionAddresses = data.map((item) => {
    return (<{ address: string }>item).address;
  });

  const Token = (await ethers.getContractFactory("Token")) as Token__factory;
  const token = Token.attach(addresses["USDC"]);

  const tokenAmountPerAddress = BigNumber.from("1000000").mul(BigNumber.from(10).pow(6));

  const senderBalance = await token.balanceOf(await signer.getAddress());

  if (senderBalance.lt(tokenAmountPerAddress.mul(usdcDistributionAddresses.length))) {
    throw new Error("Unsufficient balance");
  }

  for (const address of usdcDistributionAddresses) {
    const tx = await token.connect(signer).transfer(address, tokenAmountPerAddress);
    await tx.wait();
  }

  addressBook[net.chainId] = addresses;
  saveAddressBook(addressBook);
}
