import { Signer } from "ethers";

// @ts-ignore
import { ethers, hardhatArguments } from "hardhat";

import { expect } from 'chai';

import { loadEnv } from "../utils/loadEnv";
import { loadAddressBook } from "../utils/addressBookManager";

import {LBPController__factory} from '../typechain';


export async function main(injectedSigner?: Signer) {
  const signer: Signer = injectedSigner ? injectedSigner : (await ethers.getSigners())[0];
  const net = await signer.provider.getNetwork();

  loadEnv(hardhatArguments.network);

  const addressBook = loadAddressBook(net.chainId);
  const addresses = addressBook[net.chainId];

  if(!addresses || !addresses['LBPController']) {
    throw new Error("Invalid address book in order to advance blocks");
  }

  const provider = signer.provider!;

  const lbpController = LBPController__factory.connect(addresses['LBPController'], signer);

  const block = await provider.getBlock("latest");
  for (let i = block.number; i < (await lbpController.startBlock()).toNumber() + 1; i++) {
    await ethers.provider.send("evm_mine", []);
  }
  const nextBlock = await provider.getBlock("latest");
  expect(nextBlock.number).to.be.greaterThan(block.number);
}
