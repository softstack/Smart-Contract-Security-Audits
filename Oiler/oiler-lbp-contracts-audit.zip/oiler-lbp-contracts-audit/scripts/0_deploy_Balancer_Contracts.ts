import { Signer, ContractFactory } from "ethers";
// @ts-ignore
import { ethers } from "hardhat";
import { Artifact } from "hardhat/types";

import {
  BRegistry__factory,
  BFactory__factory,
  CRPFactory__factory,
} from "../balancer-artifacts/typechain-files";

// Import defi-contracts libraries artifcats.
const BalancerSafeMathArtifact: Artifact = require("../balancer-artifacts/builds/BalancerSafeMath.sol/BalancerSafeMath.json");
const RightsManagerArtifact: Artifact = require("../balancer-artifacts/builds/RightsManager.sol/RightsManager.json");
const SmartPoolManagerArtifact: Artifact = require("../balancer-artifacts/builds/SmartPoolManager.sol/SmartPoolManager.json");
const CRPFactoryArtifact: Artifact = require("../balancer-artifacts/builds/CRPFactory.sol/CRPFactory.json");

import { loadAddressBook, saveAddressBook } from "../utils/addressBookManager";

export async function main(
  injectedSigner?: Signer
): Promise<
  | {
      bFactory: string;
      bRegistry: string;
      crpFactory: string;
    }
  | undefined
> {
  const signer: Signer = injectedSigner ? injectedSigner : (await ethers.getSigners())[0];
  const net = await signer.provider.getNetwork();

  const addressBook = loadAddressBook(net.chainId);
  const addresses = addressBook[net.chainId];

  // BFactory

  const BFactory = new BFactory__factory(signer);
  const bFactory = await BFactory.deploy();

  console.log(`BFactory deployed at: ${bFactory.address}`);
  addresses["BFactory"] = bFactory.address;

  // BRegistry

  const BRegistry = new BRegistry__factory(signer);
  const bRegistry = await BRegistry.deploy(bFactory.address);

  console.log(`BRegistry deployed at: ${bRegistry.address}`);
  addresses["BRegistry"] = bRegistry.address;

  // CRPFactory

  const BalancerSafeMath = new ContractFactory(
    BalancerSafeMathArtifact.abi,
    BalancerSafeMathArtifact.bytecode,
    signer
  );
  const balancerSafeMathLib = (await BalancerSafeMath.deploy()).address;

  const RightsManager = new ContractFactory(
    RightsManagerArtifact.abi,
    RightsManagerArtifact.bytecode,
    signer
  );
  const rightsManagerLib = (await RightsManager.deploy()).address;

  const SmartPoolManager = new ContractFactory(
    SmartPoolManagerArtifact.abi,
    SmartPoolManagerArtifact.bytecode,
    signer
  );
  const smartPoolManagerLib = (await SmartPoolManager.deploy()).address;

  const crpFactoryBytecode = CRPFactory__factory.linkBytecode({
    __$1a4c051edb1c933fee4300ad5c62184242$__: balancerSafeMathLib,
    __$c84a2e81b91dd5cf4cdaade623916323c8$__: rightsManagerLib,
    __$f35f032baceccd23ff1c37e8fff20c5124$__: smartPoolManagerLib,
  });
  const CRPFactory = new ContractFactory(
    CRPFactoryArtifact.abi,
    crpFactoryBytecode,
    signer
  ) as CRPFactory__factory;
  const crpFactory = await CRPFactory.deploy();

  console.log(`CRPFactory deployed at: ${crpFactory.address}`);
  addresses["CRPFactory"] = crpFactory.address;

  if (injectedSigner) {
    return {
      bFactory: bFactory.address,
      bRegistry: bRegistry.address,
      crpFactory: crpFactory.address,
    };
  }

  addressBook[net.chainId] = addresses;
  saveAddressBook(addressBook);
}
