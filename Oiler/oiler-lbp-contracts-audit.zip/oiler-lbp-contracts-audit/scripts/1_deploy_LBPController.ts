// @ts-ignore
import { ethers, hardhatArguments } from "hardhat";

// ../typechain will be resolved when you 'npx hardhat compile'
import { LBPController__factory, LBPController, Token } from "../typechain";

// ../typechain will be resolved when you 'npx hardhat compile'
import { Token__factory } from "../typechain";

import { BigNumber, Signer } from "ethers";
import { loadEnv } from "../utils/loadEnv";
import { loadEnvLbpParams } from "../utils/load-env-lbp-params";
import { loadAddressBook, saveAddressBook } from "../utils/addressBookManager";
import { expect } from "chai";

export async function main() {
  const BONE = BigNumber.from(10).pow(BigNumber.from(18));

  loadEnv(hardhatArguments.network);
  const { lbpStartBlock,
          lbpOwner,
          lbpEndBlock,
          lbpStartTokenWeight,
          lbpStartCollateralWeight,
          lbpEndTokenWeight,
          lbpEndCollateralWeight,
          lbpSwapFee } = loadEnvLbpParams();

  console.log("HRE: ", hardhatArguments.network);

  const signer: Signer = (await ethers.getSigners())[0];
  const net = await signer.provider.getNetwork();

  const addressBook = loadAddressBook(net.chainId);
  const addresses = addressBook[net.chainId];

  // Ensure address book.
  if (!addresses) {
    throw new Error(`No addresses found for net id${net.chainId}`);
  }

  // these addresses have to be deployed first with defi-contracts deployments
  if (!addresses.CRPFactory) throw new Error("Address for CRP factory not found");
  if (!addresses.BRegistry) throw new Error("Address for BRegistry not found");
  if (!addresses.BFactory) throw new Error("Address for BFactory not found");

  const crpFactoryAddress: string = addresses["CRPFactory"];
  const bRegistryAddress: string = addresses["BRegistry"];
  const bFactoryAddress: string = addresses["BFactory"];

  // Initialize token and usdc collateral.
  const Token = (await ethers.getContractFactory("Token")) as Token__factory;
  const LBPController = (await ethers.getContractFactory("LBPController")) as LBPController__factory;

  let token: Token;
  let lbpController: LBPController;

  let signer2: string = await (await ethers.getSigners())[1].getAddress();

  // If the token is provided in addressBook - use it. Otherwise - deploy a mock
  if (addresses["token"]) {
    token = Token.attach(addresses["token"]);
    console.log(`Attaching existing token instance found at: ${addresses["token"]}`);
  } else {
    token = await Token.deploy(
      "Token",
      "TKN",
      18,
      BigNumber.from("100000000").mul(BigNumber.from(10).pow(18))
    );

    let tokenAmount = BigNumber.from(process.env.LBP_TOKEN_AMOUNT).mul(
      BigNumber.from(10).pow(await token.decimals())
    );
    console.log(`Transferring ${tokenAmount.toString()} Tokens to ${await signer2}`);

    await token.connect(signer).transfer(signer2, tokenAmount);
    console.log(`Deployed new token instance at: ${token.address}`);
  }

  let usdc: Token;

  // If the USDC is provided in addressBook - use it. Otherwise - deploy a mock
  if (addresses["USDC"]) {
    usdc = Token.attach(addresses["USDC"]);
    console.log(`Attaching existing token instance found at: ${addresses["USDC"]}`);
  } else {
    usdc = await Token.deploy(
      "USDC",
      "USDC",
      6,
      BigNumber.from("1000000000").mul(BigNumber.from(10).pow(6))
    );

    let usdcAmount = BigNumber.from(process.env.LBP_COLLATERAL_AMOUNT).mul(
      BigNumber.from(10).pow(await usdc.decimals())
    );
    console.log(`Transferring ${usdcAmount.toString()} USDC to ${await signer2}`);

    await usdc.connect(signer).transfer(signer2, usdcAmount);
    console.log(`Deployed new token instance at: ${usdc.address}`);
  }

  // Deploy LBP Controller.
  
  let lbpControllerOwner: string;

  // If the LBP_OWNER isn't set in .env - use Wallet[1] as the Owner of the LBP
  if (!lbpOwner) {
    const signer: Signer = (await ethers.getSigners())[1];
    lbpControllerOwner = await signer.getAddress();
  } else {
    lbpControllerOwner = lbpOwner;
  }

  if (addresses["LBPController"]) {
    lbpController = LBPController.attach(addresses["LBPController"]);
    console.log(`Attaching existing LBPController instance found at: ${addresses["LBPController"]}`);
  } else {
    console.log(
      `Deploying LBP controller (start block: ${lbpStartBlock}, end block: ${lbpEndBlock})...`
    );

    lbpController = await LBPController.deploy(
      crpFactoryAddress,
      bRegistryAddress,
      bFactoryAddress,
      token.address,
      usdc.address,
      BigNumber.from(lbpStartBlock),
      BigNumber.from(lbpEndBlock),
      lbpControllerOwner
    );

    console.log(`Deployed LBP controller at address: ${lbpController.address}`);
  }

  expect((await lbpController.CRPFactoryAddress()).toLowerCase()).eq(crpFactoryAddress.toLowerCase());
  expect((await lbpController.BRegistryAddress()).toLowerCase()).eq(bRegistryAddress.toLowerCase());
  expect((await lbpController.BFactoryAddress()).toLowerCase()).eq(bFactoryAddress.toLowerCase());
  expect((await lbpController.tokenAddress()).toLowerCase()).eq(token.address.toLowerCase());
  expect((await lbpController.collateralAddress()).toLowerCase()).eq(usdc.address.toLowerCase());

  expect(await lbpController.startBlock()).eq(lbpStartBlock);
  expect(await lbpController.endBlock()).eq(lbpEndBlock);

  expect((await lbpController.owner()).toLowerCase()).eq(lbpControllerOwner.toLowerCase());

  expect(await lbpController.initialTokenAmount()).eq(process.env.LBP_TOKEN_AMOUNT);
  expect(await lbpController.initialCollateralAmount()).eq(process.env.LBP_COLLATERAL_AMOUNT);
  expect(await lbpController.startTokenWeight()).eq(BONE.mul(lbpStartTokenWeight));
  expect(await lbpController.startCollateralWeight()).eq(BONE.mul(lbpStartCollateralWeight));
  expect(await lbpController.endTokenWeight()).eq(BONE.mul(lbpEndTokenWeight));
  expect(await lbpController.endCollateralWeight()).eq(BONE.mul(lbpEndCollateralWeight));
  expect(await lbpController.swapFee()).eq(BONE.mul(lbpSwapFee*100000).div(100000));

  // TODO: Should we move these to .ENV also?
  const poolParams = {
    poolTokenSymbol: "OILLBP",                       
    poolTokenName: "OilerTokenLBP",                  
    swapFee: BONE.mul(lbpSwapFee*100000).div(100000) 
  }

  const fetchedPoolParams = await lbpController.poolParams();

  expect(fetchedPoolParams.poolTokenName).to.be.equal(poolParams.poolTokenName);
  expect(fetchedPoolParams.poolTokenSymbol).to.be.equal(poolParams.poolTokenSymbol);
  expect(fetchedPoolParams.swapFee.toString()).to.be.equal(poolParams.swapFee.toString());

  const crpParams = {
    initialSupply: BONE.mul(100), 
    minimumWeightChangeBlockPeriod: lbpEndBlock-lbpStartBlock-1,
    addTokenTimeLockInBlocks: lbpEndBlock-lbpStartBlock-1       
  }

  const fetchedCrpParams = await lbpController.crpParams();

  expect(fetchedCrpParams.addTokenTimeLockInBlocks.toString()).to.be.equal(crpParams.addTokenTimeLockInBlocks.toString());
  expect(fetchedCrpParams.initialSupply.toString()).to.be.equal(crpParams.initialSupply.toString());
  expect(fetchedCrpParams.minimumWeightChangeBlockPeriod.toString()).to.be.equal(crpParams.minimumWeightChangeBlockPeriod.toString());

  const rights = {
    canPauseSwapping: true,
    canChangeSwapFee: false,
    canChangeWeights: true,
    canAddRemoveTokens: true,
    canWhitelistLPs: true,
    canChangeCap: false
  }

  const fetchedRights = await lbpController.rights();
  const keys = Object.keys(fetchedRights).filter(key => isNaN(key as any));
  const fetchedRightsCopy = {}
  keys.forEach(key => fetchedRightsCopy[key] = fetchedRights[key]) ;

  expect(fetchedRightsCopy).deep.equal(rights);

  addresses["token"] = token.address;
  addresses["USDC"] = usdc.address;
  addresses["LBPController"] = lbpController.address;

  addressBook[net.chainId] = addresses;
  saveAddressBook(addressBook);
}
