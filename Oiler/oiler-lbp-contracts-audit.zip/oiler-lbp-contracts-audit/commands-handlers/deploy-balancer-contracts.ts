import { main } from "../scripts/0_deploy_Balancer_Contracts";

main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });
