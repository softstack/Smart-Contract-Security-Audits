import * as path from "path";
import * as dotenv from "dotenv";

// @ts-ignore
import { ethers } from "hardhat";
import { step } from "mocha-steps";

import {
  LBPController__factory,
  Token__factory,
  LBPController,
  Token,
  ConfigurableRightsPool__factory,
  BPool__factory,
  BPool,
  ConfigurableRightsPool,
} from "../typechain";

import { BigNumber, Signer, providers, constants } from "ethers";
const { AddressZero, MaxUint256 } = constants;

import { solidity } from "ethereum-waffle";
import * as chai from "chai";
import { fromWei, toWei } from "../utils/weiConvertionNormalized";
import { main as balancerDeployer } from "../scripts/0_deploy_Balancer_Contracts";

chai.use(solidity);
dotenv.config({ path: path.join(__dirname, "../.env") });

const { expect, assert } = chai;
const addressBook = require(path.join(__dirname, "../../addressBook"));


describe("LBPController", function () {
  let provider: providers.Provider;
  let signers: Signer[];

  let lbpController: LBPController;
  let collateral: Token;
  let token: Token;
  let addresses: Record<string, string>;

  let bPool: BPool;
  let crp: ConfigurableRightsPool;

  let deployer: Signer;
  let owner: Signer;
  let buyer: Signer;

  let testStartBlock: number;
  let startBlock: number;
  let endBlock: number;

  const initialTokenAmount = BigNumber.from(1775000); // TODO: take from ENV
  const initialCollateralAmount = BigNumber.from(147546);

  const randomAddress = "0x4000000000000000000000000000000000000005";
  const BONE = BigNumber.from(10).pow(BigNumber.from(18));

  this.beforeEach(async () => {
    signers = await ethers.getSigners();
    if (signers.length < 3)
      throw new Error("In order to run the tests at least 3 accounts must be provided");
    provider = signers[0].provider;

    const networkId = (await provider.getNetwork()).chainId;

    
    deployer = signers[0];
    owner = signers[1];
    buyer = signers[2];

    addresses = addressBook[networkId];

    const Token = (await ethers.getContractFactory("Token")) as Token__factory;

    console.log("Creting tokens:");
    collateral = await Token.deploy("USDC coin", "USDC", 6, MaxUint256.toHexString());
    token = await Token.deploy("Token", "TKN", 18, MaxUint256.toHexString());
    console.log("token", token.address);
    console.log("collateral", collateral.address);

    // Deploy LBP controller.
    const LBPController = (await ethers.getContractFactory(
      "LBPController"
    )) as LBPController__factory;

    const isDev =
      addresses === undefined ||
      ["BRegistry", "CRPFactory", "BFactory"].some((r) => Object.keys(addresses).includes(r));

    const contracts = isDev ? await balancerDeployer(signers[0]) : null;

    if (isDev) {
      console.log("Balancer contracts deployed: ");
      console.log(contracts);
    }

    const lbpBlocksDuration = 100;
    testStartBlock = await provider.getBlockNumber();
    startBlock = testStartBlock + 100;
    endBlock = startBlock + lbpBlocksDuration - 1;

    console.log("Creating LBPController...");
    lbpController = await LBPController.deploy(
      isDev ? contracts.crpFactory : addresses.CRPFactory,
      isDev ? contracts.bRegistry : addresses.BRegistry,
      isDev ? contracts.bFactory : addresses.BFactory,
      token.address,
      collateral.address,
      startBlock,
      endBlock,
      await owner.getAddress()
    );

    console.log("lbpController deployed: ", lbpController.address);

    console.log("owner", await owner.getAddress());
  });

  this.afterEach(async () => {
    expect(await token.balanceOf(await owner.getAddress())).to.be.gt(await toWei(initialTokenAmount.sub("2000"), token))
    expect(await collateral.balanceOf(await owner.getAddress())).to.be.gt(await toWei(initialCollateralAmount.sub("100"), collateral))
  })

  async function loadOwnerWithFunds() {
    await collateral
      .connect(deployer)
      .transfer(await owner.getAddress(), await toWei(initialCollateralAmount, collateral));
    await token
      .connect(deployer)
      .transfer(await owner.getAddress(), await toWei(initialTokenAmount, token));
  };

  async function createPool() {
    // // Give approvals.
    console.log("Token: Giving approvals to LBPController from Owner");
    await token.connect(owner).approve(lbpController.address, MaxUint256.toHexString());
    console.log("Collateral: Giving approvals to LBPController from Owner");
    await collateral.connect(owner).approve(lbpController.address, MaxUint256.toHexString());

    const ownerAddress = await owner.getAddress();

    // Load token balance beore creation.
    const tokenBalanceBeforeCreation = await fromWei(await token.balanceOf(ownerAddress), token);
    const collateralBalanceBeforeCreation = await fromWei(
      await collateral.balanceOf(ownerAddress),
      collateral
    );
    console.log("tokenBalanceBeforeCreation:", tokenBalanceBeforeCreation.toString());
    console.log("collateralBalanceBeforeCreation:", collateralBalanceBeforeCreation.toString());

    // Create pool.
    // Ensure owner has enough collateral.
    if (
      (await lbpController.initialCollateralAmount()).gt(
        await fromWei(await collateral.balanceOf(ownerAddress), collateral)
      )
    ) {
      throw new Error(`Owner does not have enough collateral to create pool`);
    }

    // Ensure owner has enough token.
    if (
      (await lbpController.initialTokenAmount()).gt(
        await fromWei(await token.balanceOf(ownerAddress), token)
      )
    ) {
      throw new Error(`Owner does not have enough tokens to create pool`);
    }

    // Esnure allowances are set.
    if (
      (await lbpController.initialCollateralAmount()).gt(
        await fromWei(await collateral.allowance(ownerAddress, lbpController.address), collateral)
      )
    ) {
      throw new Error(`Collateral approval required.`);
    }

    if (
      (await lbpController.initialTokenAmount()).gt(
        await fromWei(await token.allowance(ownerAddress, lbpController.address), token)
      )
    ) {
      throw new Error(`Tokens approval required.`);
    }

    if ((await lbpController.startBlock()).lt((await provider.getBlock("latest")).number)) {
      throw new Error(`startBlock should be in the future.`);
    }

    const gas = await lbpController.connect(owner).estimateGas.createSmartPool();
    console.log("Gas estimated:", gas.toString())

    // ============================================================
    // ==                      CREATE POOL                       ==
    // ============================================================
    const tx = await lbpController.connect(owner).createSmartPool();
    await tx.wait();

    // Load token balances after creation.
    const collateralBalanceAfterCreation = await fromWei(
      await collateral.balanceOf(ownerAddress),
      collateral
    );
    const tokenBalanceAfterCreation = await fromWei(
      await collateral.balanceOf(ownerAddress),
      token
    );

    // Expect COLLATERAL has been transfered from owner.
    expect(
      collateralBalanceBeforeCreation.sub(collateralBalanceAfterCreation).toHexString()
    ).to.be.equal(
      (await lbpController.initialCollateralAmount()).toHexString(),
      "COLLATERAL balances expectations not met."
    );

    // Expect Tokens have been transfered from owner.
    expect(tokenBalanceBeforeCreation.sub(tokenBalanceAfterCreation).toHexString()).to.be.equal(
      (await lbpController.initialTokenAmount()).toHexString(),
      "Token balances expectations not met."
    );

    // Assert pools are created properly.
    const crpAddress = await lbpController.crp();

    assert.notEqual(crpAddress, AddressZero, "CRP creation failed");

    crp = ConfigurableRightsPool__factory.connect(crpAddress, deployer);

    const bPoolAddress = await crp.bPool();
    assert.notEqual(bPoolAddress, AddressZero, "BPool creation failed");

    bPool = await BPool__factory.connect(bPoolAddress, deployer);

    // Assert bPool received liquidity.
    const bPoolCollateralAmount = await fromWei(
      await collateral.balanceOf(bPoolAddress),
      collateral
    );
    const bPoolTokenAmount = await fromWei(await token.balanceOf(bPoolAddress), token);

    expect(bPoolCollateralAmount.toHexString()).to.be.equal(
      (await lbpController.initialCollateralAmount()).toHexString()
    );

    expect(bPoolTokenAmount.toHexString()).to.be.equal(
      (await lbpController.initialTokenAmount()).toHexString()
    );

    const liquidityTokens = await crp.totalSupply();

    // Assert LP tokens have been minted.
    assert.isTrue(liquidityTokens.gt(0));

    const controllerLpTokensBalance = await crp.balanceOf(lbpController.address);
    // Assert LBP controller is only LP tokens holder.
    assert.isTrue(controllerLpTokensBalance.eq(liquidityTokens));
  };

  async function withdrawLiquidityTokens() {
    await lbpController.connect(owner).withdrawLBPTokens();
  };

  async function withdrawAssets() {
    const crpToken = await Token__factory.connect(crp.address, owner);

    console.log("bPool Token balance before:", (await fromWei(await token.balanceOf(bPool.address), token)).toString());
    console.log("bPool Collateral balance before:", (await fromWei(await collateral.balanceOf(bPool.address), collateral)).toString());
    console.log("owner CRP tokens balance before:", (await fromWei(await crpToken.balanceOf(await owner.getAddress()), crpToken)).toString())
    console.log("owner Token balance before:", (await fromWei(await token.balanceOf(await owner.getAddress()), token)).toString());
    console.log("owner Collateral balance before:", (await fromWei(await collateral.balanceOf(await owner.getAddress()), collateral)).toString());

    console.log("\nWithdrawing assets from LBP...\n")
    await crp.connect(owner).exitPool(BONE.mul(BigNumber.from(99999)).div(BigNumber.from(1000)), [0,0]);

    console.log("bPool Token balance after:", (await fromWei(await token.balanceOf(bPool.address), token)).toString());
    console.log("bPool Collateral balance after:", (await fromWei(await collateral.balanceOf(bPool.address), collateral)).toString());
    console.log("owner CRP tokens balance after:", (await fromWei(await crpToken.balanceOf(await owner.getAddress()), crpToken)).toString())
    console.log("owner Token balance after:", (await fromWei(await token.balanceOf(await owner.getAddress()), token)).toString());
    console.log("owner Collateral balance after:", (await fromWei(await collateral.balanceOf(await owner.getAddress()), collateral)).toString());
  };

  async function withdrawAssetsFails() {
    const crpToken = await Token__factory.connect(crp.address, owner);
    console.log("\nWithdrawing assets from LBP...\n")
    await expect(crp.connect(owner).exitPool(BONE.mul(BigNumber.from(99999)).div(BigNumber.from(1000)), [0,0])).to.be.revertedWith("ERR_AMOUNTS_MISMATCH");
  };

  async function moveBackLPTokens() {
    const crpToken = await Token__factory.connect(crp.address, owner);
    await crpToken.transfer(lbpController.address, await crpToken.balanceOf(await owner.getAddress()));
  }

  async function waitTillLBPStarts() {
    const block = await provider.getBlock("latest");
    for (let i = block.number; i < startBlock + 1; i++) {
      await ethers.provider.send("evm_mine", []);
    }
    const nextBlock = await provider.getBlock("latest");
    expect(nextBlock.number).to.be.greaterThan(block.number);
  };


  async function startPool() {
    await lbpController.startPool();
    const isFinalized = await bPool.isFinalized();
    expect(isFinalized).to.be.equal(false);
    const isPublicSwap = await bPool.isPublicSwap();
    expect(isPublicSwap).to.be.equal(true);
  };


  async function pokeWeights() {
    const collateralWeightBeforePoke = await bPool.getNormalizedWeight(collateral.address);
    const tokenWeightBeforePoke = await bPool.getNormalizedWeight(token.address);
    await crp.pokeWeights();
    const collateralWeightAfterPoke = await bPool.getNormalizedWeight(collateral.address);
    const tokenWeightAfterPoke = await bPool.getNormalizedWeight(token.address);
    expect(
      collateralWeightAfterPoke.gt(collateralWeightBeforePoke),
      "Expected COLLATERAL weight to increase after poking"
    ).to.be.true;
    expect(
      tokenWeightAfterPoke.lt(tokenWeightBeforePoke),
      "Expected Token weight to decrease after poking"
    ).to.be.true;
  };

  async function buyTokens() {
    const buyerAddress = await buyer.getAddress();
    await collateral.connect(deployer).transfer(buyerAddress, await toWei("1000", collateral));
    await collateral
      .connect(buyer)
      .approve(bPool.address, await collateral.balanceOf(buyerAddress));

    // Buy tokens.
    const collateralBalanceBeforeSwap = await collateral.balanceOf(buyerAddress);
    const priceBeforeSwap = await bPool.getSpotPriceSansFee(collateral.address, token.address);

    await bPool
      .connect(buyer)
      .swapExactAmountIn(
        collateral.address,
        await collateral.balanceOf(buyerAddress),
        token.address,
        0,
        MaxUint256.toHexString()
      );

    const tokenBalanceAfterSwap = await token.balanceOf(buyerAddress);
    const collateralBalanceAfterSwap = await collateral.balanceOf(buyerAddress);
    const priceAfterSwap = await bPool.getSpotPriceSansFee(collateral.address, token.address);

    assert.isTrue(collateralBalanceAfterSwap.lt(collateralBalanceBeforeSwap));
    assert.isTrue(tokenBalanceAfterSwap.gt(0));

    expect(priceAfterSwap.toNumber()).to.be.greaterThan(priceBeforeSwap.toNumber());
  };

  async function buyTokensFails() {
    const buyerAddress = await buyer.getAddress();
    await collateral.connect(deployer).transfer(buyerAddress, await toWei("1000", collateral));
    await collateral
      .connect(buyer)
      .approve(bPool.address, await collateral.balanceOf(buyerAddress));

    // Buy tokens.

    await expect(bPool
      .connect(buyer)
      .swapExactAmountIn(
        collateral.address,
        await collateral.balanceOf(buyerAddress),
        token.address,
        0,
        MaxUint256.toHexString()
      ), "anykind").to.be.revertedWith("ERR_MAX_IN_RATIO");
  };

  async function waitTillLBPEnds() {
    const block = await provider.getBlock("latest");
    for (let i = block.number; i < endBlock + 5; i++) {
      await ethers.provider.send("evm_mine", []);
    }
    const nextBlock = await provider.getBlock("latest");
    expect(nextBlock.number).to.be.greaterThan(block.number);
  };



  async function endPool() {
    const ownerAddress = await owner.getAddress();

    const collateralBalanceBeforeExit = await collateral.balanceOf(ownerAddress);
    const tokenBalanceBeforeExit = await token.balanceOf(ownerAddress);

    await lbpController.connect(buyer).endPool();
    const publicSwap = await crp.isPublicSwap();
    assert.isFalse(publicSwap);

    const collateralBalanceAfterExit = await collateral.balanceOf(ownerAddress);
    const tokenBalanceAfterExit = await token.balanceOf(ownerAddress);

    expect(collateralBalanceAfterExit.gt(collateralBalanceBeforeExit)).to.be.true;
    expect(tokenBalanceAfterExit.gt(tokenBalanceBeforeExit)).to.be.true;
  };

  it("After pool creation but before pool start block", async () => {
    console.log("loadOwnerWithFunds")
    await loadOwnerWithFunds()
    console.log("createPool")
    await createPool()
    console.log("withdrawLiquidityTokens")
    await withdrawLiquidityTokens()

    console.log("withdrawAssets")
    await withdrawAssets()

    console.log("waitTillLBPStarts")
    await waitTillLBPStarts()
    console.log("startPool")
    await startPool()
    console.log("pokeWeights")
    await pokeWeights()
    // console.log("buyTokens")
    // await buyTokens()
    console.log("buyTokensFails")
    await buyTokensFails()
    console.log("waitTillLBPEnds")
    await waitTillLBPEnds()
    console.log("pokeWeights")
    await pokeWeights()
    console.log("moveBackLPTokens")
    await moveBackLPTokens()
    console.log("endPool")
    await endPool()
    
  });

  it("After LBP start block but before startPool() is called", async () => {
    console.log("loadOwnerWithFunds")
    await loadOwnerWithFunds()
    console.log("createPool")
    await createPool()
    console.log("withdrawLiquidityTokens")
    await withdrawLiquidityTokens()
    console.log("waitTillLBPStarts")
    await waitTillLBPStarts()

    console.log("withdrawAssets")
    await withdrawAssets()

    console.log("startPool")
    await startPool()
    console.log("pokeWeights")
    await pokeWeights()
    // console.log("buyTokens")
    // await buyTokens()
    console.log("buyTokensFails")
    await buyTokensFails()
    console.log("waitTillLBPEnds")
    await waitTillLBPEnds()
    console.log("pokeWeights")
    await pokeWeights()
    console.log("moveBackLPTokens")
    await moveBackLPTokens()
    console.log("endPool")
    await endPool()
  });

  it("After startPool()", async () => {
    console.log("loadOwnerWithFunds")
    await loadOwnerWithFunds()
    console.log("createPool")
    await createPool()
    console.log("withdrawLiquidityTokens")
    await withdrawLiquidityTokens()
    console.log("waitTillLBPStarts")
    await waitTillLBPStarts()
    console.log("startPool")
    await startPool()

    console.log("withdrawAssets")
    await withdrawAssets()

    console.log("pokeWeights")
    await pokeWeights()
    // console.log("buyTokens")
    // await buyTokens()
    console.log("buyTokensFails")
    await buyTokensFails()
    console.log("waitTillLBPEnds")
    await waitTillLBPEnds()
    console.log("pokeWeights")
    await pokeWeights()
    console.log("moveBackLPTokens")
    await moveBackLPTokens()
    console.log("endPool")
    await endPool()
  });

  it("After pokeWeights()", async () => {
    console.log("loadOwnerWithFunds")
    await loadOwnerWithFunds()
    console.log("createPool")
    await createPool()
    console.log("withdrawLiquidityTokens")
    await withdrawLiquidityTokens()
    console.log("waitTillLBPStarts")
    await waitTillLBPStarts()
    console.log("startPool")
    await startPool()
    console.log("pokeWeights")
    await pokeWeights()

    console.log("withdrawAssets")
    await withdrawAssets()

    // console.log("buyTokens")
    // await buyTokens()
    console.log("buyTokensFails")
    await buyTokensFails()
    console.log("waitTillLBPEnds")
    await waitTillLBPEnds()
    console.log("pokeWeights")
    await pokeWeights()
    console.log("moveBackLPTokens")
    await moveBackLPTokens()
    console.log("endPool")
    await endPool()
  });

  it("After buy tokens", async () => {
    console.log("loadOwnerWithFunds")
    await loadOwnerWithFunds()
    console.log("createPool")
    await createPool()
    console.log("withdrawLiquidityTokens")
    await withdrawLiquidityTokens()
    console.log("waitTillLBPStarts")
    await waitTillLBPStarts()
    console.log("startPool")
    await startPool()
    console.log("pokeWeights")
    await pokeWeights()
    console.log("buyTokens")
    await buyTokens()

    // console.log("buyTokensFails")
    // await buyTokensFails()

    console.log("withdrawAssets")
    await withdrawAssets()

    console.log("waitTillLBPEnds")
    await waitTillLBPEnds()
    console.log("pokeWeights")
    await pokeWeights()
    console.log("moveBackLPTokens")
    await moveBackLPTokens()
    console.log("endPool")
    await endPool()
  });

  it("After LBP endBlock but before endPool()", async () => {
    console.log("loadOwnerWithFunds")
    await loadOwnerWithFunds()
    console.log("createPool")
    await createPool()
    console.log("withdrawLiquidityTokens")
    await withdrawLiquidityTokens()
    console.log("waitTillLBPStarts")
    await waitTillLBPStarts()
    console.log("startPool")
    await startPool()
    console.log("pokeWeights")
    await pokeWeights()
    console.log("buyTokens")
    await buyTokens()
    // console.log("buyTokensFails")
    // await buyTokensFails()
    console.log("waitTillLBPEnds")
    await waitTillLBPEnds()

    console.log("withdrawAssets")
    await withdrawAssets()

    console.log("pokeWeights")
    await pokeWeights()
    console.log("moveBackLPTokens")
    await moveBackLPTokens()
    console.log("endPool")
    await endPool()
  });

  it("After endPool()", async () => {
    console.log("loadOwnerWithFunds")
    await loadOwnerWithFunds()
    console.log("createPool")
    await createPool()
    console.log("withdrawLiquidityTokens")
    await withdrawLiquidityTokens()
    console.log("waitTillLBPStarts")
    await waitTillLBPStarts()
    console.log("startPool")
    await startPool()
    console.log("pokeWeights")
    await pokeWeights()
    console.log("buyTokens")
    await buyTokens()
    // console.log("buyTokensFails")
    // await buyTokensFails()
    console.log("waitTillLBPEnds")
    await waitTillLBPEnds()
    console.log("pokeWeights")
    await pokeWeights()
    console.log("moveBackLPTokens")
    await moveBackLPTokens()
    console.log("endPool")
    await endPool()

    console.log("withdrawAssetsFails")
    await withdrawAssetsFails()
  });

});