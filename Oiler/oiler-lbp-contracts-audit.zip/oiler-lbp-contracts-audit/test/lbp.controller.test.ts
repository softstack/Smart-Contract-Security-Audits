import * as path from "path";
import * as dotenv from "dotenv";

// @ts-ignore
import { ethers } from "hardhat";
import { step } from "mocha-steps";

import {
  LBPController__factory,
  Token__factory,
  LBPController,
  Token,
  ConfigurableRightsPool__factory,
  BPool__factory,
  BPool,
  ConfigurableRightsPool,
} from "../typechain";

import { BigNumber, Signer, providers, constants } from "ethers";
const { AddressZero, MaxUint256 } = constants;

import { solidity } from "ethereum-waffle";
import * as chai from "chai";
import { fromWei, toWei } from "../utils/weiConvertionNormalized";
import { main as balancerDeployer } from "../scripts/0_deploy_Balancer_Contracts";

chai.use(solidity);
dotenv.config({ path: path.join(__dirname, "../.env") });

const { expect, assert } = chai;
const addressBook = require(path.join(__dirname, "../../addressBook"));

describe("LBPController", function () {
  let provider: providers.Provider;
  let signers: Signer[];

  let lbpController: LBPController;
  let collateral: Token;
  let token: Token;
  let addresses: Record<string, string>;

  let bPool: BPool;
  let crp: ConfigurableRightsPool;

  let deployer: Signer;
  let owner: Signer;
  let buyer: Signer;

  let testStartBlock: number;
  let startBlock: number;
  let endBlock: number;

  const initialTokenAmount = BigNumber.from(1775000); // TODO: Take these both from the .ENV.network
  const initialCollateralAmount = BigNumber.from(147546);

  const randomAddress = "0x4000000000000000000000000000000000000005";
  const BONE = BigNumber.from(10).pow(BigNumber.from(18));

  this.beforeAll(async () => {
    // if (!process.env.LBP_START_BLOCK) throw new Error("LBP_START_BLOCK not set");
    // const lbpBlocksDuration = Number(process.env.LBP_START_BLOCK);

    signers = await ethers.getSigners();
    if (signers.length < 3)
      throw new Error("In order to run the tests at least 3 accounts must be provided");
    provider = signers[0].provider;

    const networkId = (await provider.getNetwork()).chainId;

    
    deployer = signers[0];
    owner = signers[1];
    buyer = signers[2];

    addresses = addressBook[networkId];

    const Token = (await ethers.getContractFactory("Token")) as Token__factory;

    console.log("Creting tokens:");
    collateral = await Token.deploy("USDC coin", "USDC", 6, MaxUint256.toHexString());
    token = await Token.deploy("Token", "TKN", 18, MaxUint256.toHexString());
    console.log("token", token.address);
    console.log("collateral", collateral.address);

    // Deploy LBP controller.
    const LBPController = (await ethers.getContractFactory(
      "LBPController"
    )) as LBPController__factory;

    const isDev =
      addresses === undefined ||
      ["BRegistry", "CRPFactory", "BFactory"].some((r) => Object.keys(addresses).includes(r));

    const contracts = isDev ? await balancerDeployer(signers[0]) : null;

    if (isDev) {
      console.log("Balancer contracts deployed: ");
      console.log(contracts);
    }

    const lbpBlocksDuration = 100;
    testStartBlock = await provider.getBlockNumber();
    startBlock = testStartBlock + 100;
    endBlock = startBlock + lbpBlocksDuration - 1;

    console.log("Creating LBPController...");
    lbpController = await LBPController.deploy(
      isDev ? contracts.crpFactory : addresses.CRPFactory,
      isDev ? contracts.bRegistry : addresses.BRegistry,
      isDev ? contracts.bFactory : addresses.BFactory,
      token.address,
      collateral.address,
      startBlock,
      endBlock,
      await owner.getAddress()
    );

    console.log("lbpController deployed: ", lbpController.address);

    console.log("owner", await owner.getAddress());
  });

  step("Ensure not initialized", async () => {
    const crpAddress = await lbpController.crp();
    expect(crpAddress.toLocaleLowerCase()).to.be.equal(AddressZero);
  });

  step("Load Owner with funds", async () => {
    await collateral
      .connect(deployer)
      .transfer(await owner.getAddress(), await toWei(initialCollateralAmount, collateral));
    await token
      .connect(deployer)
      .transfer(await owner.getAddress(), await toWei(initialTokenAmount, token));
  });

  step("Create the pool", async () => {
    // // Give approvals.
    console.log("Token: Giving approvals to LBPController from Owner");
    await token.connect(owner).approve(lbpController.address, MaxUint256.toHexString());
    console.log("Collateral: Giving approvals to LBPController from Owner");
    await collateral.connect(owner).approve(lbpController.address, MaxUint256.toHexString());

    const ownerAddress = await owner.getAddress();

    // Load token balance beore creation.
    const tokenBalanceBeforeCreation = await fromWei(await token.balanceOf(ownerAddress), token);
    const collateralBalanceBeforeCreation = await fromWei(
      await collateral.balanceOf(ownerAddress),
      collateral
    );
    console.log("tokenBalanceBeforeCreation:", tokenBalanceBeforeCreation.toString());
    console.log("collateralBalanceBeforeCreation:", collateralBalanceBeforeCreation.toString());

    // Create pool.
    // Ensure owner has enough collateral.
    if (
      (await lbpController.initialCollateralAmount()).gt(
        await fromWei(await collateral.balanceOf(ownerAddress), collateral)
      )
    ) {
      throw new Error(`Owner does not have enough collateral to create pool`);
    }

    // Ensure owner has enough token.
    if (
      (await lbpController.initialTokenAmount()).gt(
        await fromWei(await token.balanceOf(ownerAddress), token)
      )
    ) {
      throw new Error(`Owner does not have enough tokens to create pool`);
    }

    // Esnure allowances are set.
    if (
      (await lbpController.initialCollateralAmount()).gt(
        await fromWei(await collateral.allowance(ownerAddress, lbpController.address), collateral)
      )
    ) {
      throw new Error(`Collateral approval required.`);
    }

    if (
      (await lbpController.initialTokenAmount()).gt(
        await fromWei(await token.allowance(ownerAddress, lbpController.address), token)
      )
    ) {
      throw new Error(`Tokens approval required.`);
    }

    if ((await lbpController.startBlock()).lt((await provider.getBlock("latest")).number)) {
      throw new Error(`startBlock should be in the future.`);
    }

    const gas = await lbpController.connect(owner).estimateGas.createSmartPool();
    console.log("Gas estimated:", gas.toString())

    // ============================================================
    // ==                      CREATE POOL                       ==
    // ============================================================
    const tx = await lbpController.connect(owner).createSmartPool();
    await tx.wait();

    // Load token balances after creation.
    const collateralBalanceAfterCreation = await fromWei(
      await collateral.balanceOf(ownerAddress),
      collateral
    );
    const tokenBalanceAfterCreation = await fromWei(
      await collateral.balanceOf(ownerAddress),
      token
    );

    // Expect COLLATERAL has been transfered from owner.
    expect(
      collateralBalanceBeforeCreation.sub(collateralBalanceAfterCreation).toHexString()
    ).to.be.equal(
      (await lbpController.initialCollateralAmount()).toHexString(),
      "COLLATERAL balances expectations not met."
    );

    // Expect Tokens have been transfered from owner.
    expect(tokenBalanceBeforeCreation.sub(tokenBalanceAfterCreation).toHexString()).to.be.equal(
      (await lbpController.initialTokenAmount()).toHexString(),
      "Token balances expectations not met."
    );

    // Assert pools are created properly.
    const crpAddress = await lbpController.crp();

    assert.notEqual(crpAddress, AddressZero, "CRP creation failed");

    crp = ConfigurableRightsPool__factory.connect(crpAddress, deployer);

    const bPoolAddress = await crp.bPool();
    assert.notEqual(bPoolAddress, AddressZero, "BPool creation failed");

    bPool = await BPool__factory.connect(bPoolAddress, deployer);

    // Assert bPool received liquidity.
    const bPoolCollateralAmount = await fromWei(
      await collateral.balanceOf(bPoolAddress),
      collateral
    );
    const bPoolTokenAmount = await fromWei(await token.balanceOf(bPoolAddress), token);

    expect(bPoolCollateralAmount.toHexString()).to.be.equal(
      (await lbpController.initialCollateralAmount()).toHexString()
    );

    expect(bPoolTokenAmount.toHexString()).to.be.equal(
      (await lbpController.initialTokenAmount()).toHexString()
    );

    const liquidityTokens = await crp.totalSupply();

    // Assert LP tokens have been minted.
    assert.isTrue(liquidityTokens.gt(0));

    const controllerLpTokensBalance = await crp.balanceOf(lbpController.address);
    // Assert LBP controller is only LP tokens holder.
    assert.isTrue(controllerLpTokensBalance.eq(liquidityTokens));
  });

  step("Security tests before LBP Start", async () => {
    const crpAddress = await lbpController.crp();
    assert.notEqual(crpAddress, AddressZero, "CRP address is zero");
    crp = ConfigurableRightsPool__factory.connect(crpAddress, buyer);
    const bPoolAddress = await crp.bPool();
    assert.notEqual(bPoolAddress, AddressZero, "BPool address is zero");
    bPool = await BPool__factory.connect(bPoolAddress, buyer);

    // ====================
    //    LBPController:
    // ====================
    
    // Only owner (our Multisig) can call these functions:
      // createSmartPool() - only owner can call it
      await expect(lbpController.connect(buyer).createSmartPool()).to.be.revertedWith("Ownable: caller is not the owner");
      // registerPool() - only owner can call it
      await expect(lbpController.connect(buyer).registerPool()).to.be.revertedWith("Ownable: caller is not the owner");
      // withdrawLBPTokens() - only owner can call it
      await expect(lbpController.connect(buyer).withdrawLBPTokens()).to.be.revertedWith("Ownable: caller is not the owner");
    
    // These functions can be called by anyone, but they are time-restricted by blockNumber:
      // startPool() - only can be called after startBlock of LBP
      await expect(lbpController.connect(buyer).startPool()).to.be.revertedWith("LBP didn't start yet");
      // endPool() - only can be called after endBlock of LBP
      await expect(lbpController.connect(buyer).endPool()).to.be.revertedWith("LBP didn't end yet");
      // pokeWeights() - only can be called during LBP
      await expect(lbpController.connect(buyer).pokeWeights()).to.be.revertedWith("ERR_CANT_POKE_YET");

    // ============
    //    bPool:
    // ============

    //  Only controller (CRP) can call, but we don't call any of these directly:
      //    setSwapFee(uint swapFee) - only controller
      await expect(bPool.setSwapFee(BigNumber.from(10).pow(BigNumber.from(16)))).to.be.revertedWith("ERR_NOT_CONTROLLER");
      //    setPublicSwap(bool public_) - only controller
      await expect(bPool.setPublicSwap(true)).to.be.revertedWith("ERR_NOT_CONTROLLER");
      //    finalize() - only controller
      await expect(bPool.finalize()).to.be.revertedWith("ERR_NOT_CONTROLLER");
      //    bind(address token, uint balance, uint denorm) - only controller
      await expect(bPool.bind(randomAddress, BONE.mul(BigNumber.from(150)), BONE.mul(BigNumber.from(50)))).to.be.revertedWith("ERR_NOT_CONTROLLER");
      //    rebind(address token, uint balance, uint denorm) - only controller
      await expect(bPool.rebind(randomAddress, BONE.mul(BigNumber.from(150)), BONE.mul(BigNumber.from(50)))).to.be.revertedWith("ERR_NOT_CONTROLLER");
      //    unbind(address token) - only controller
      await expect(bPool.unbind(token.address)).to.be.revertedWith("ERR_NOT_CONTROLLER");
      //    setController(address manager) - only controller
      await expect(bPool.setController(randomAddress)).to.be.revertedWith("ERR_NOT_CONTROLLER");

    //  Only can be called if Pool is finalized (it is never in our case):
      //    joinPool(uint poolAmountOut, uint[] calldata maxAmountsIn) - only finalized
      await expect(bPool.joinPool(BONE, [BigNumber.from(0)])).to.be.revertedWith("ERR_NOT_FINALIZED");
      //    exitPool(uint poolAmountIn, uint[] calldata minAmountsOut) - only finalized
      await expect(bPool.exitPool(BONE, [BigNumber.from(0)])).to.be.revertedWith("ERR_NOT_FINALIZED");
      //    joinswapExternAmountIn(address tokenIn, uint tokenAmountIn, uint minPoolAmountOut) - only finalized
      await expect(bPool.joinswapExternAmountIn(token.address, BONE, BigNumber.from(0))).to.be.revertedWith("ERR_NOT_FINALIZED");
      //    joinswapPoolAmountOut(address tokenIn, uint poolAmountOut, uint maxAmountIn) - only finalized
      await expect(bPool.joinswapPoolAmountOut(token.address, BONE, BigNumber.from(0))).to.be.revertedWith("ERR_NOT_FINALIZED");
      //    exitswapPoolAmountIn(address tokenOut, uint poolAmountIn, uint minAmountOut)
      await expect(bPool.exitswapPoolAmountIn(token.address, BONE, BigNumber.from(0))).to.be.revertedWith("ERR_NOT_FINALIZED");
      //    exitswapExternAmountOut(address tokenOut, uint tokenAmountOut, uint maxPoolAmountIn)
      await expect(bPool.exitswapExternAmountOut(token.address, BONE, BigNumber.from(0))).to.be.revertedWith("ERR_NOT_FINALIZED");

    //  Only can be called if publicSwap == true (we enable it only during LBP run):
      //    swapExactAmountIn(address tokenIn, uint tokenAmountIn, address tokenOut, uint minAmountOut, uint maxPrice) - only publicSwap
      await expect(bPool.swapExactAmountIn(token.address, BONE, collateral.address, BigNumber.from(0), BONE)).to.be.revertedWith("ERR_SWAP_NOT_PUBLIC");
      //    swapExactAmountOut(address tokenIn, uint maxAmountIn, address tokenOut, uint tokenAmountOut, uint maxPrice) - only publicSwap
      await expect(bPool.swapExactAmountOut(token.address, BONE, collateral.address, BigNumber.from(0), BONE)).to.be.revertedWith("ERR_SWAP_NOT_PUBLIC");


    // ============
    //     CRP:
    // ============
    //  Only owner can call it, and we call it via LBPController:
      //    createPool(uint initialSupply,
      //               uint minimumWeightChangeBlockPeriodParam,
      //               uint addTokenTimeLockInBlocksParam) - only owner, we do it only in constructor
      await expect(crp["createPool(uint256,uint256,uint256)"](BONE.mul(BigNumber.from(100)),
                                  BONE.mul(BigNumber.from(100)),
                                  BONE.mul(BigNumber.from(100)))).to.be.revertedWith("ERR_NOT_CONTROLLER");
      //    setPublicSwap(bool publicSwap) - only owner, only if canPauseSwapping, we do it in constructor, startPool, endPool (with block checks)
      await expect(crp.setPublicSwap(true)).to.be.revertedWith("ERR_NOT_CONTROLLER");
      //    updateWeightsGradually(uint[] calldata newWeights, uint startBlock, uint endBlock) - only owner, only if canChangeWeights, we do it only in constructor
      await expect(crp.updateWeightsGradually([BONE, BONE], 123, 234)).to.be.revertedWith("ERR_NOT_CONTROLLER");
      //    removeToken(address token) - only owner, only if canAddRemoveTokens and isCommitted, and no gradual update running, we call it in endPool (with block checks)
      await expect(crp.removeToken(token.address)).to.be.revertedWith("ERR_NOT_CONTROLLER");

    //  Only owner can call it, but we don't have it in LBPController, so it cannot be called anyone, even us:
      //    createPool(uint initialSupply) - only owner, we don't call it
      await expect(crp["createPool(uint256)"](BONE)).to.be.revertedWith("ERR_NOT_CONTROLLER");
      //    setCap(uint newCap) - only owner, only if canChangeCap - we don't call it
      await expect(crp.setCap(BONE)).to.be.revertedWith("ERR_NOT_CONTROLLER");
      //    setSwapFee(uint swapFee) - only owner, only if canChangeSwapFee, we don't call it
      await expect(crp.setSwapFee(BONE)).to.be.revertedWith("ERR_NOT_CONTROLLER");
      //    updateWeight(address token, uint newWeight) - only owner, only if canChangeWeights, we don't call it
      await expect(crp.updateWeight(token.address, BONE)).to.be.revertedWith("ERR_NOT_CONTROLLER");
      //    commitAddToken(address token, uint balance, uint denormalizedWeight) - only owner, only if canAddRemoveTokens, we don't call it
      await expect(crp.commitAddToken(token.address, BONE, BONE)).to.be.revertedWith("ERR_NOT_CONTROLLER");
      //    applyAddToken() - only owner, only if canAddRemoveTokens, we don't call it
      await expect(crp.applyAddToken()).to.be.revertedWith("ERR_NOT_CONTROLLER");
      //    whitelistLiquidityProvider(address provider) - only owner, we don't call it
      await expect(crp.whitelistLiquidityProvider(randomAddress)).to.be.revertedWith("ERR_NOT_CONTROLLER");
      //    removeWhitelistedLiquidityProvider(address provider) - only owner, we don't call it
      await expect(crp.removeWhitelistedLiquidityProvider(randomAddress)).to.be.revertedWith("ERR_NOT_CONTROLLER");

    //  Only whiteListed people can call it, but our whiteList is always empty, and we don't have functions to modify it:
      //    joinPool(uint poolAmountOut, uint[] calldata maxAmountsIn) - only whiteListed, our whiteList is always empty
      await expect(crp.joinPool(BONE, [BONE, BONE])).to.be.revertedWith("ERR_NOT_ON_WHITELIST");
      //    joinswapExternAmountIn(address tokenIn, uint tokenAmountIn, uint minPoolAmountOut) - only whiteListed, our whiteList is always empty
      await expect(crp.joinswapExternAmountIn(token.address, BONE, BONE)).to.be.revertedWith("ERR_NOT_ON_WHITELIST");
      //    joinswapPoolAmountOut(address tokenIn, uint poolAmountOut, uint maxAmountIn) - only whiteListed, our whiteList is always empty
      await expect(crp.joinswapPoolAmountOut(token.address, BONE, BONE)).to.be.revertedWith("ERR_NOT_ON_WHITELIST");

    //  Only somebody with PoolShare can have it (only our LBP contract has it, if we don't use Escape-Hatch to withdraw it):
      //    exitswapPoolAmountIn(address tokenOut, uint poolAmountIn, uint minAmountOut) - only if has PoolShare
      await expect(crp.exitswapPoolAmountIn(token.address, BONE, 0)).to.be.revertedWith("ERR_SUB_UNDERFLOW");
      //    exitswapExternAmountOut(address tokenOut, uint tokenAmountOut, uint maxPoolAmountIn) - only if has poolShare
      await expect(crp.exitswapExternAmountOut(token.address, BONE, MaxUint256)).to.be.revertedWith("ERR_SUB_UNDERFLOW");
      //    exitPool(uint poolAmountIn, uint[] calldata minAmountsOut) - only if has PoolShare
      await expect(crp.exitPool(BONE, [0, 0])).to.be.revertedWith("ERR_SUB_UNDERFLOW");

    //  Internal functions, market as "public", but with require(msg.sender == address(this)) - meaning only contract itself can call it:
      //    mintPoolShareFromLib(uint amount) - only contract itself can call it (internal, but public because of the call from lib)
      await expect(crp.mintPoolShareFromLib(BONE)).to.be.revertedWith("ERR_NOT_CONTROLLER");
      //    pushPoolShareFromLib(address to, uint amount) - same as above
      await expect(crp.pushPoolShareFromLib(randomAddress, BONE)).to.be.revertedWith("ERR_NOT_CONTROLLER");
      //    pullPoolShareFromLib(address from, uint amount) - same as above
      await expect(crp.pullPoolShareFromLib(randomAddress, BONE)).to.be.revertedWith("ERR_NOT_CONTROLLER");
      //    burnPoolShareFromLib(uint amount) - same as above
      await expect(crp.burnPoolShareFromLib(BONE)).to.be.revertedWith("ERR_NOT_CONTROLLER");
    //
    //  Public function:
      //    pokeWeights() - can be called by anyone
      await expect(crp.pokeWeights()).to.be.revertedWith("ERR_CANT_POKE_YET")
  });

  step("Ensure LBP has been initialized properly", async () => {
    const lbpInitialAmounts = {
      collateral: (
        await toWei(await lbpController.initialCollateralAmount(), collateral)
      ).toString(),
      token: (await toWei(await lbpController.initialTokenAmount(), token)).toString(),
    };

    const poolBalances = {
      collateral: (await collateral.balanceOf(bPool.address)).toString(),
      token: (await token.balanceOf(bPool.address)).toString(),
    };

    expect(lbpInitialAmounts.collateral).to.be.equal(poolBalances.collateral);
    expect(lbpInitialAmounts.token).to.be.equal(poolBalances.token);

    const expectedWeightsDenormalized = {
      token: await lbpController.startTokenWeight(),
      collateral: await lbpController.startCollateralWeight(),
    };

    const expectedWeights = {
      collateral: expectedWeightsDenormalized.collateral
        .mul(BigNumber.from(10).pow(18))
        .div(expectedWeightsDenormalized.token.add(expectedWeightsDenormalized.collateral))
        .toString(),
      token: expectedWeightsDenormalized.token
        .mul(BigNumber.from(10).pow(18))
        .div(expectedWeightsDenormalized.token.add(expectedWeightsDenormalized.collateral))
        .toString(),
    };

    const actualWeights = {
      collateral: (await bPool.getNormalizedWeight(collateral.address)).toString(),
      token: (await bPool.getNormalizedWeight(token.address)).toString(),
    };

    expect(actualWeights.collateral).to.be.equal(expectedWeights.collateral);
    expect(actualWeights.token).to.be.equal(expectedWeights.token);

    const isPublicSwap = await crp.isPublicSwap();
    expect(isPublicSwap).to.be.false;
  });

  step("Ensure second LBP initialization will be reverted", async () => {
    await expect(lbpController.createSmartPool()).to.be.reverted;
  });

  step("Ensure swap attempt will be reverted before pool start", async () => {
    await collateral.connect(deployer).approve(bPool.address, "1000000");
    await expect(
      bPool
        .connect(buyer)
        .swapExactAmountIn(
          collateral.address,
          "1000000",
          token.address,
          0,
          MaxUint256.toHexString()
        )
    ).to.be.reverted;
  });

  step("Wait n blocks till LBP starts", async () => {
    const block = await provider.getBlock("latest");
    for (let i = block.number; i < startBlock + 1; i++) {
      await ethers.provider.send("evm_mine", []);
    }
    const nextBlock = await provider.getBlock("latest");
    expect(nextBlock.number).to.be.greaterThan(block.number);
  });

  step("Start bPool", async () => {
    await lbpController.startPool();
    const isFinalized = await bPool.isFinalized();
    expect(isFinalized).to.be.equal(false);
    const isPublicSwap = await bPool.isPublicSwap();
    expect(isPublicSwap).to.be.equal(true);
  });

  step("Security tests after LBP Start", async () => {
    const crpAddress = await lbpController.crp();
    assert.notEqual(crpAddress, AddressZero, "CRP address is zero");
    crp = ConfigurableRightsPool__factory.connect(crpAddress, buyer);
    const bPoolAddress = await crp.bPool();
    assert.notEqual(bPoolAddress, AddressZero, "BPool address is zero");
    bPool = await BPool__factory.connect(bPoolAddress, buyer);

    // ====================
    //    LBPController:
    // ====================
    
    // Only owner (our Multisig) can call these functions:
      // createSmartPool() - only owner can call it
      await expect(lbpController.connect(buyer).createSmartPool()).to.be.revertedWith("Ownable: caller is not the owner");
      // registerPool() - only owner can call it
      await expect(lbpController.connect(buyer).registerPool()).to.be.revertedWith("Ownable: caller is not the owner");
      // withdrawLBPTokens() - only owner can call it
      await expect(lbpController.connect(buyer).withdrawLBPTokens()).to.be.revertedWith("Ownable: caller is not the owner");
    
    // These functions can be called by anyone, but they are time-restricted by blockNumber:
      // endPool() - only can be called after endBlock of LBP
      await expect(lbpController.connect(buyer).endPool()).to.be.revertedWith("LBP didn't end yet");

    // ============
    //    bPool:
    // ============

    //  Only controller (CRP) can call, but we don't call any of these directly:
      //    setSwapFee(uint swapFee) - only controller
      await expect(bPool.setSwapFee(BigNumber.from(10).pow(BigNumber.from(16)))).to.be.revertedWith("ERR_NOT_CONTROLLER");
      //    setPublicSwap(bool public_) - only controller
      await expect(bPool.setPublicSwap(false)).to.be.revertedWith("ERR_NOT_CONTROLLER");
      //    finalize() - only controller
      await expect(bPool.finalize()).to.be.revertedWith("ERR_NOT_CONTROLLER");
      //    bind(address token, uint balance, uint denorm) - only controller
      await expect(bPool.bind(randomAddress, BONE.mul(BigNumber.from(150)), BONE.mul(BigNumber.from(50)))).to.be.revertedWith("ERR_NOT_CONTROLLER");
      //    rebind(address token, uint balance, uint denorm) - only controller
      await expect(bPool.rebind(randomAddress, BONE.mul(BigNumber.from(150)), BONE.mul(BigNumber.from(50)))).to.be.revertedWith("ERR_NOT_CONTROLLER");
      //    unbind(address token) - only controller
      await expect(bPool.unbind(token.address)).to.be.revertedWith("ERR_NOT_CONTROLLER");
      //    setController(address manager) - only controller
      await expect(bPool.setController(randomAddress)).to.be.revertedWith("ERR_NOT_CONTROLLER");

    //  Only can be called if Pool is finalized (it is never in our case):
      //    joinPool(uint poolAmountOut, uint[] calldata maxAmountsIn) - only finalized
      await expect(bPool.joinPool(BONE, [BigNumber.from(0)])).to.be.revertedWith("ERR_NOT_FINALIZED");
      //    exitPool(uint poolAmountIn, uint[] calldata minAmountsOut) - only finalized
      await expect(bPool.exitPool(BONE, [BigNumber.from(0)])).to.be.revertedWith("ERR_NOT_FINALIZED");
      //    joinswapExternAmountIn(address tokenIn, uint tokenAmountIn, uint minPoolAmountOut) - only finalized
      await expect(bPool.joinswapExternAmountIn(token.address, BONE, BigNumber.from(0))).to.be.revertedWith("ERR_NOT_FINALIZED");
      //    joinswapPoolAmountOut(address tokenIn, uint poolAmountOut, uint maxAmountIn) - only finalized
      await expect(bPool.joinswapPoolAmountOut(token.address, BONE, BigNumber.from(0))).to.be.revertedWith("ERR_NOT_FINALIZED");
      //    exitswapPoolAmountIn(address tokenOut, uint poolAmountIn, uint minAmountOut)
      await expect(bPool.exitswapPoolAmountIn(token.address, BONE, BigNumber.from(0))).to.be.revertedWith("ERR_NOT_FINALIZED");
      //    exitswapExternAmountOut(address tokenOut, uint tokenAmountOut, uint maxPoolAmountIn)
      await expect(bPool.exitswapExternAmountOut(token.address, BONE, BigNumber.from(0))).to.be.revertedWith("ERR_NOT_FINALIZED");

    // ============
    //     CRP:
    // ============
    //  Only owner can call it, and we call it via LBPController:
      //    createPool(uint initialSupply,
      //               uint minimumWeightChangeBlockPeriodParam,
      //               uint addTokenTimeLockInBlocksParam) - only owner, we do it only in constructor
      await expect(crp["createPool(uint256,uint256,uint256)"](BONE.mul(BigNumber.from(100)),
                                  BONE.mul(BigNumber.from(100)),
                                  BONE.mul(BigNumber.from(100)))).to.be.revertedWith("ERR_NOT_CONTROLLER");
      //    setPublicSwap(bool publicSwap) - only owner, only if canPauseSwapping, we do it in constructor, startPool, endPool (with block checks)
      await expect(crp.setPublicSwap(true)).to.be.revertedWith("ERR_NOT_CONTROLLER");
      //    updateWeightsGradually(uint[] calldata newWeights, uint startBlock, uint endBlock) - only owner, only if canChangeWeights, we do it only in constructor
      await expect(crp.updateWeightsGradually([BONE, BONE], 123, 234)).to.be.revertedWith("ERR_NOT_CONTROLLER");
      //    removeToken(address token) - only owner, only if canAddRemoveTokens and isCommitted, and no gradual update running, we call it in endPool (with block checks)
      await expect(crp.removeToken(token.address)).to.be.revertedWith("ERR_NOT_CONTROLLER");

    //  Only owner can call it, but we don't have it in LBPController, so it cannot be called anyone, even us:
      //    createPool(uint initialSupply) - only owner, we don't call it
      await expect(crp["createPool(uint256)"](BONE)).to.be.revertedWith("ERR_NOT_CONTROLLER");
      //    setCap(uint newCap) - only owner, only if canChangeCap - we don't call it
      await expect(crp.setCap(BONE)).to.be.revertedWith("ERR_NOT_CONTROLLER");
      //    setSwapFee(uint swapFee) - only owner, only if canChangeSwapFee, we don't call it
      await expect(crp.setSwapFee(BONE)).to.be.revertedWith("ERR_NOT_CONTROLLER");
      //    updateWeight(address token, uint newWeight) - only owner, only if canChangeWeights, we don't call it
      await expect(crp.updateWeight(token.address, BONE)).to.be.revertedWith("ERR_NOT_CONTROLLER");
      //    commitAddToken(address token, uint balance, uint denormalizedWeight) - only owner, only if canAddRemoveTokens, we don't call it
      await expect(crp.commitAddToken(token.address, BONE, BONE)).to.be.revertedWith("ERR_NOT_CONTROLLER");
      //    applyAddToken() - only owner, only if canAddRemoveTokens, we don't call it
      await expect(crp.applyAddToken()).to.be.revertedWith("ERR_NOT_CONTROLLER");
      //    whitelistLiquidityProvider(address provider) - only owner, we don't call it
      await expect(crp.whitelistLiquidityProvider(randomAddress)).to.be.revertedWith("ERR_NOT_CONTROLLER");
      //    removeWhitelistedLiquidityProvider(address provider) - only owner, we don't call it
      await expect(crp.removeWhitelistedLiquidityProvider(randomAddress)).to.be.revertedWith("ERR_NOT_CONTROLLER");

    //  Only whiteListed people can call it, but our whiteList is always empty, and we don't have functions to modify it:
      //    joinPool(uint poolAmountOut, uint[] calldata maxAmountsIn) - only whiteListed, our whiteList is always empty
      await expect(crp.joinPool(BONE, [BONE, BONE])).to.be.revertedWith("ERR_NOT_ON_WHITELIST");
      //    joinswapExternAmountIn(address tokenIn, uint tokenAmountIn, uint minPoolAmountOut) - only whiteListed, our whiteList is always empty
      await expect(crp.joinswapExternAmountIn(token.address, BONE, BONE)).to.be.revertedWith("ERR_NOT_ON_WHITELIST");
      //    joinswapPoolAmountOut(address tokenIn, uint poolAmountOut, uint maxAmountIn) - only whiteListed, our whiteList is always empty
      await expect(crp.joinswapPoolAmountOut(token.address, BONE, BONE)).to.be.revertedWith("ERR_NOT_ON_WHITELIST");

    //  Only somebody with PoolShare can have it (only our LBP contract has it, if we don't use Escape-Hatch to withdraw it):
      //    exitswapPoolAmountIn(address tokenOut, uint poolAmountIn, uint minAmountOut) - only if has PoolShare
      await expect(crp.exitswapPoolAmountIn(token.address, BONE, 0)).to.be.revertedWith("ERR_SUB_UNDERFLOW");
      //    exitswapExternAmountOut(address tokenOut, uint tokenAmountOut, uint maxPoolAmountIn) - only if has poolShare
      await expect(crp.exitswapExternAmountOut(token.address, BONE, MaxUint256)).to.be.revertedWith("ERR_SUB_UNDERFLOW");
      //    exitPool(uint poolAmountIn, uint[] calldata minAmountsOut) - only if has PoolShare
      await expect(crp.exitPool(BONE, [0, 0])).to.be.revertedWith("ERR_SUB_UNDERFLOW");

    //  Internal functions, market as "public", but with require(msg.sender == address(this)) - meaning only contract itself can call it:
      //    mintPoolShareFromLib(uint amount) - only contract itself can call it (internal, but public because of the call from lib)
      await expect(crp.mintPoolShareFromLib(BONE)).to.be.revertedWith("ERR_NOT_CONTROLLER");
      //    pushPoolShareFromLib(address to, uint amount) - same as above
      await expect(crp.pushPoolShareFromLib(randomAddress, BONE)).to.be.revertedWith("ERR_NOT_CONTROLLER");
      //    pullPoolShareFromLib(address from, uint amount) - same as above
      await expect(crp.pullPoolShareFromLib(randomAddress, BONE)).to.be.revertedWith("ERR_NOT_CONTROLLER");
      //    burnPoolShareFromLib(uint amount) - same as above
      await expect(crp.burnPoolShareFromLib(BONE)).to.be.revertedWith("ERR_NOT_CONTROLLER");
  });

  step("Poke weights", async () => {
    const collateralWeightBeforePoke = await bPool.getNormalizedWeight(collateral.address);
    const tokenWeightBeforePoke = await bPool.getNormalizedWeight(token.address);
    await crp.pokeWeights();
    const collateralWeightAfterPoke = await bPool.getNormalizedWeight(collateral.address);
    const tokenWeightAfterPoke = await bPool.getNormalizedWeight(token.address);
    expect(
      collateralWeightAfterPoke.gt(collateralWeightBeforePoke),
      "Expected COLLATERAL weight to increase after poking"
    ).to.be.true;
    expect(
      tokenWeightAfterPoke.lt(tokenWeightBeforePoke),
      "Expected Token weight to decrease after poking"
    ).to.be.true;
  });

  step("Buy tokens from bPool", async () => {
    const buyerAddress = await buyer.getAddress();
    await collateral.connect(deployer).transfer(buyerAddress, await toWei("1000", collateral));
    await collateral
      .connect(buyer)
      .approve(bPool.address, await collateral.balanceOf(buyerAddress));

    // Buy tokens.
    const collateralBalanceBeforeSwap = await collateral.balanceOf(buyerAddress);
    const priceBeforeSwap = await bPool.getSpotPriceSansFee(collateral.address, token.address);

    await bPool
      .connect(buyer)
      .swapExactAmountIn(
        collateral.address,
        await collateral.balanceOf(buyerAddress),
        token.address,
        0,
        MaxUint256.toHexString()
      );

    const tokenBalanceAfterSwap = await token.balanceOf(buyerAddress);
    const collateralBalanceAfterSwap = await collateral.balanceOf(buyerAddress);
    const priceAfterSwap = await bPool.getSpotPriceSansFee(collateral.address, token.address);

    assert.isTrue(collateralBalanceAfterSwap.lt(collateralBalanceBeforeSwap));
    assert.isTrue(tokenBalanceAfterSwap.gt(0));

    expect(priceAfterSwap.toNumber()).to.be.greaterThan(priceBeforeSwap.toNumber());
  });

  step("Try to end LBP", async () => {
    await expect(lbpController.endPool()).to.be.reverted;
  });

  step("Wait n blocks till LBP ends", async () => {
    const block = await provider.getBlock("latest");
    for (let i = block.number; i < endBlock + 5; i++) {
      await ethers.provider.send("evm_mine", []);
    }
    const nextBlock = await provider.getBlock("latest");
    expect(nextBlock.number).to.be.greaterThan(block.number);
  });

  step("Poke weights", async () => {
    const collateralWeightBeforePoke = await bPool.getNormalizedWeight(collateral.address);
    const tokenWeightBeforePoke = await bPool.getNormalizedWeight(token.address);
    await crp.pokeWeights();

    const collateralWeightAfterPoke = await bPool.getNormalizedWeight(collateral.address);
    const tokenWeightAfterPoke = await bPool.getNormalizedWeight(token.address);

    expect(
      collateralWeightAfterPoke.gt(collateralWeightBeforePoke),
      "Expected COLLATERAL weight to increase"
    ).to.be.true;

    expect(tokenWeightAfterPoke.lt(tokenWeightBeforePoke), "Expected Token weight to decrease").to
      .be.true;

    });

  step("Security tests after LBP End Block, but before endPool() is called", async () => {
    const crpAddress = await lbpController.crp();
    assert.notEqual(crpAddress, AddressZero, "CRP address is zero");
    crp = ConfigurableRightsPool__factory.connect(crpAddress, buyer);
    const bPoolAddress = await crp.bPool();
    assert.notEqual(bPoolAddress, AddressZero, "BPool address is zero");
    bPool = await BPool__factory.connect(bPoolAddress, buyer);

    // ====================
    //    LBPController:
    // ====================
    
    // Only owner (our Multisig) can call these functions:
      // createSmartPool() - only owner can call it
      await expect(lbpController.connect(buyer).createSmartPool()).to.be.revertedWith("Ownable: caller is not the owner");
      // registerPool() - only owner can call it
      await expect(lbpController.connect(buyer).registerPool()).to.be.revertedWith("Ownable: caller is not the owner");
      // withdrawLBPTokens() - only owner can call it
      await expect(lbpController.connect(buyer).withdrawLBPTokens()).to.be.revertedWith("Ownable: caller is not the owner");
    
    // These functions can be called by anyone, but they are time-restricted by blockNumber:
      // startPool() - only can be called after startBlock of LBP
      await expect(lbpController.connect(buyer).startPool()).to.be.revertedWith("LBP already ended");
      // pokeWeights() - only can be called during LBP. If called after endBlock - doesn't change the weights
      const collateralWeightBeforePoke = await bPool.getNormalizedWeight(collateral.address);
      const tokenWeightBeforePoke = await bPool.getNormalizedWeight(token.address);
      await lbpController.pokeWeights();
      const collateralWeightAfterPoke = await bPool.getNormalizedWeight(collateral.address);
      const tokenWeightAfterPoke = await bPool.getNormalizedWeight(token.address);
      expect(collateralWeightAfterPoke.eq(collateralWeightBeforePoke), "Expected COLLATERAL weight to stay same").to.be.true;
      expect(tokenWeightAfterPoke.eq(tokenWeightBeforePoke), "Expected Token weight to stay same").to.be.true;
  

    // ============
    //    bPool:
    // ============

    //  Only controller (CRP) can call, but we don't call any of these directly:
      //    setSwapFee(uint swapFee) - only controller
      await expect(bPool.setSwapFee(BigNumber.from(10).pow(BigNumber.from(16)))).to.be.revertedWith("ERR_NOT_CONTROLLER");
      //    setPublicSwap(bool public_) - only controller
      await expect(bPool.setPublicSwap(true)).to.be.revertedWith("ERR_NOT_CONTROLLER");
      //    finalize() - only controller
      await expect(bPool.finalize()).to.be.revertedWith("ERR_NOT_CONTROLLER");
      //    bind(address token, uint balance, uint denorm) - only controller
      await expect(bPool.bind(randomAddress, BONE.mul(BigNumber.from(150)), BONE.mul(BigNumber.from(50)))).to.be.revertedWith("ERR_NOT_CONTROLLER");
      //    rebind(address token, uint balance, uint denorm) - only controller
      await expect(bPool.rebind(randomAddress, BONE.mul(BigNumber.from(150)), BONE.mul(BigNumber.from(50)))).to.be.revertedWith("ERR_NOT_CONTROLLER");
      //    unbind(address token) - only controller
      await expect(bPool.unbind(token.address)).to.be.revertedWith("ERR_NOT_CONTROLLER");
      //    setController(address manager) - only controller
      await expect(bPool.setController(randomAddress)).to.be.revertedWith("ERR_NOT_CONTROLLER");

    //  Only can be called if Pool is finalized (it is never in our case):
      //    joinPool(uint poolAmountOut, uint[] calldata maxAmountsIn) - only finalized
      await expect(bPool.joinPool(BONE, [BigNumber.from(0)])).to.be.revertedWith("ERR_NOT_FINALIZED");
      //    exitPool(uint poolAmountIn, uint[] calldata minAmountsOut) - only finalized
      await expect(bPool.exitPool(BONE, [BigNumber.from(0)])).to.be.revertedWith("ERR_NOT_FINALIZED");
      //    joinswapExternAmountIn(address tokenIn, uint tokenAmountIn, uint minPoolAmountOut) - only finalized
      await expect(bPool.joinswapExternAmountIn(token.address, BONE, BigNumber.from(0))).to.be.revertedWith("ERR_NOT_FINALIZED");
      //    joinswapPoolAmountOut(address tokenIn, uint poolAmountOut, uint maxAmountIn) - only finalized
      await expect(bPool.joinswapPoolAmountOut(token.address, BONE, BigNumber.from(0))).to.be.revertedWith("ERR_NOT_FINALIZED");
      //    exitswapPoolAmountIn(address tokenOut, uint poolAmountIn, uint minAmountOut)
      await expect(bPool.exitswapPoolAmountIn(token.address, BONE, BigNumber.from(0))).to.be.revertedWith("ERR_NOT_FINALIZED");
      //    exitswapExternAmountOut(address tokenOut, uint tokenAmountOut, uint maxPoolAmountIn)
      await expect(bPool.exitswapExternAmountOut(token.address, BONE, BigNumber.from(0))).to.be.revertedWith("ERR_NOT_FINALIZED");

    // ============
    //     CRP:
    // ============
    //  Only owner can call it, and we call it via LBPController:
      //    createPool(uint initialSupply,
      //               uint minimumWeightChangeBlockPeriodParam,
      //               uint addTokenTimeLockInBlocksParam) - only owner, we do it only in constructor
      await expect(crp["createPool(uint256,uint256,uint256)"](BONE.mul(BigNumber.from(100)),
                                  BONE.mul(BigNumber.from(100)),
                                  BONE.mul(BigNumber.from(100)))).to.be.revertedWith("ERR_NOT_CONTROLLER");
      //    setPublicSwap(bool publicSwap) - only owner, only if canPauseSwapping, we do it in constructor, startPool, endPool (with block checks)
      await expect(crp.setPublicSwap(true)).to.be.revertedWith("ERR_NOT_CONTROLLER");
      //    updateWeightsGradually(uint[] calldata newWeights, uint startBlock, uint endBlock) - only owner, only if canChangeWeights, we do it only in constructor
      await expect(crp.updateWeightsGradually([BONE, BONE], 123, 234)).to.be.revertedWith("ERR_NOT_CONTROLLER");
      //    removeToken(address token) - only owner, only if canAddRemoveTokens and isCommitted, and no gradual update running, we call it in endPool (with block checks)
      await expect(crp.removeToken(token.address)).to.be.revertedWith("ERR_NOT_CONTROLLER");

    //  Only owner can call it, but we don't have it in LBPController, so it cannot be called anyone, even us:
      //    createPool(uint initialSupply) - only owner, we don't call it
      await expect(crp["createPool(uint256)"](BONE)).to.be.revertedWith("ERR_NOT_CONTROLLER");
      //    setCap(uint newCap) - only owner, only if canChangeCap - we don't call it
      await expect(crp.setCap(BONE)).to.be.revertedWith("ERR_NOT_CONTROLLER");
      //    setSwapFee(uint swapFee) - only owner, only if canChangeSwapFee, we don't call it
      await expect(crp.setSwapFee(BONE)).to.be.revertedWith("ERR_NOT_CONTROLLER");
      //    updateWeight(address token, uint newWeight) - only owner, only if canChangeWeights, we don't call it
      await expect(crp.updateWeight(token.address, BONE)).to.be.revertedWith("ERR_NOT_CONTROLLER");
      //    commitAddToken(address token, uint balance, uint denormalizedWeight) - only owner, only if canAddRemoveTokens, we don't call it
      await expect(crp.commitAddToken(token.address, BONE, BONE)).to.be.revertedWith("ERR_NOT_CONTROLLER");
      //    applyAddToken() - only owner, only if canAddRemoveTokens, we don't call it
      await expect(crp.applyAddToken()).to.be.revertedWith("ERR_NOT_CONTROLLER");
      //    whitelistLiquidityProvider(address provider) - only owner, we don't call it
      await expect(crp.whitelistLiquidityProvider(randomAddress)).to.be.revertedWith("ERR_NOT_CONTROLLER");
      //    removeWhitelistedLiquidityProvider(address provider) - only owner, we don't call it
      await expect(crp.removeWhitelistedLiquidityProvider(randomAddress)).to.be.revertedWith("ERR_NOT_CONTROLLER");

    //  Only whiteListed people can call it, but our whiteList is always empty, and we don't have functions to modify it:
      //    joinPool(uint poolAmountOut, uint[] calldata maxAmountsIn) - only whiteListed, our whiteList is always empty
      await expect(crp.joinPool(BONE, [BONE, BONE])).to.be.revertedWith("ERR_NOT_ON_WHITELIST");
      //    joinswapExternAmountIn(address tokenIn, uint tokenAmountIn, uint minPoolAmountOut) - only whiteListed, our whiteList is always empty
      await expect(crp.joinswapExternAmountIn(token.address, BONE, BONE)).to.be.revertedWith("ERR_NOT_ON_WHITELIST");
      //    joinswapPoolAmountOut(address tokenIn, uint poolAmountOut, uint maxAmountIn) - only whiteListed, our whiteList is always empty
      await expect(crp.joinswapPoolAmountOut(token.address, BONE, BONE)).to.be.revertedWith("ERR_NOT_ON_WHITELIST");

    //  Only somebody with PoolShare can have it (only our LBP contract has it, if we don't use Escape-Hatch to withdraw it):
      //    exitswapPoolAmountIn(address tokenOut, uint poolAmountIn, uint minAmountOut) - only if has PoolShare
      await expect(crp.exitswapPoolAmountIn(token.address, BONE, 0)).to.be.revertedWith("ERR_SUB_UNDERFLOW");
      //    exitswapExternAmountOut(address tokenOut, uint tokenAmountOut, uint maxPoolAmountIn) - only if has poolShare
      await expect(crp.exitswapExternAmountOut(token.address, BONE, MaxUint256)).to.be.revertedWith("ERR_SUB_UNDERFLOW");
      //    exitPool(uint poolAmountIn, uint[] calldata minAmountsOut) - only if has PoolShare
      await expect(crp.exitPool(BONE, [0, 0])).to.be.revertedWith("ERR_SUB_UNDERFLOW");

    //  Internal functions, market as "public", but with require(msg.sender == address(this)) - meaning only contract itself can call it:
      //    mintPoolShareFromLib(uint amount) - only contract itself can call it (internal, but public because of the call from lib)
      await expect(crp.mintPoolShareFromLib(BONE)).to.be.revertedWith("ERR_NOT_CONTROLLER");
      //    pushPoolShareFromLib(address to, uint amount) - same as above
      await expect(crp.pushPoolShareFromLib(randomAddress, BONE)).to.be.revertedWith("ERR_NOT_CONTROLLER");
      //    pullPoolShareFromLib(address from, uint amount) - same as above
      await expect(crp.pullPoolShareFromLib(randomAddress, BONE)).to.be.revertedWith("ERR_NOT_CONTROLLER");
      //    burnPoolShareFromLib(uint amount) - same as above
      await expect(crp.burnPoolShareFromLib(BONE)).to.be.revertedWith("ERR_NOT_CONTROLLER");
    //
    //  Public function:
      //    pokeWeights() - can be called by anyone, but after LBP end - weights shouldn't change
      const crpCollateralWeightBeforePoke = await bPool.getNormalizedWeight(collateral.address);
      const crpTokenWeightBeforePoke = await bPool.getNormalizedWeight(token.address);
      await crp.pokeWeights();
      const crpCollateralWeightAfterPoke = await bPool.getNormalizedWeight(collateral.address);
      const crpTokenWeightAfterPoke = await bPool.getNormalizedWeight(token.address);
      expect(crpCollateralWeightBeforePoke.eq(crpCollateralWeightAfterPoke), "Expected COLLATERAL weight to stay same").to.be.true;
      expect(crpTokenWeightBeforePoke.eq(crpTokenWeightAfterPoke), "Expected Token weight to stay same").to.be.true;
  });

  step("End LBP using arbitrary address to withdraw collateral/tokens to owner", async () => {
    const ownerAddress = await owner.getAddress();

    const collateralBalanceBeforeExit = await collateral.balanceOf(ownerAddress);
    const tokenBalanceBeforeExit = await token.balanceOf(ownerAddress);

    await lbpController.connect(buyer).endPool();
    const publicSwap = await crp.isPublicSwap();
    assert.isFalse(publicSwap);

    const collateralBalanceAfterExit = await collateral.balanceOf(ownerAddress);
    const tokenBalanceAfterExit = await token.balanceOf(ownerAddress);

    expect(collateralBalanceAfterExit.gt(collateralBalanceBeforeExit)).to.be.true;
    expect(tokenBalanceAfterExit.gt(tokenBalanceBeforeExit)).to.be.true;
  });

  step("Security tests after LBP ended and pool destroyed by endPool()", async () => {
    const crpAddress = await lbpController.crp();
    assert.notEqual(crpAddress, AddressZero, "CRP address is zero");
    crp = ConfigurableRightsPool__factory.connect(crpAddress, buyer);
    const bPoolAddress = await crp.bPool();
    assert.notEqual(bPoolAddress, AddressZero, "BPool address is zero");
    bPool = await BPool__factory.connect(bPoolAddress, buyer);

    // ====================
    //    LBPController:
    // ====================
    
    // Only owner (our Multisig) can call these functions:
      // createSmartPool() - only owner can call it
      await expect(lbpController.connect(buyer).createSmartPool()).to.be.revertedWith("Ownable: caller is not the owner");
      // registerPool() - only owner can call it
      await expect(lbpController.connect(buyer).registerPool()).to.be.revertedWith("Ownable: caller is not the owner");
      // withdrawLBPTokens() - only owner can call it
      await expect(lbpController.connect(buyer).withdrawLBPTokens()).to.be.revertedWith("Ownable: caller is not the owner");
    
    // These functions can be called by anyone, but they are time-restricted by blockNumber:
      // startPool() - only can be called after startBlock of LBP
      await expect(lbpController.connect(buyer).startPool()).to.be.revertedWith("LBP already ended");
      // endPool() - only can be called after endBlock of LBP
      await expect(lbpController.connect(buyer).endPool()).to.be.revertedWith("ERR_NOT_BOUND");
      // pokeWeights() - only can be called during LBP, or if after - weights shouldn't change

    // ============
    //    bPool:
    // ============

    //  Only controller (CRP) can call, but we don't call any of these directly:
      //    setSwapFee(uint swapFee) - only controller
      await expect(bPool.setSwapFee(BigNumber.from(10).pow(BigNumber.from(16)))).to.be.revertedWith("ERR_NOT_CONTROLLER");
      //    setPublicSwap(bool public_) - only controller
      await expect(bPool.setPublicSwap(true)).to.be.revertedWith("ERR_NOT_CONTROLLER");
      //    finalize() - only controller
      await expect(bPool.finalize()).to.be.revertedWith("ERR_NOT_CONTROLLER");
      //    bind(address token, uint balance, uint denorm) - only controller
      await expect(bPool.bind(randomAddress, BONE.mul(BigNumber.from(150)), BONE.mul(BigNumber.from(50)))).to.be.revertedWith("ERR_NOT_CONTROLLER");
      //    rebind(address token, uint balance, uint denorm) - only controller
      await expect(bPool.rebind(randomAddress, BONE.mul(BigNumber.from(150)), BONE.mul(BigNumber.from(50)))).to.be.revertedWith("ERR_NOT_CONTROLLER");
      //    unbind(address token) - only controller
      await expect(bPool.unbind(token.address)).to.be.revertedWith("ERR_NOT_CONTROLLER");
      //    setController(address manager) - only controller
      await expect(bPool.setController(randomAddress)).to.be.revertedWith("ERR_NOT_CONTROLLER");

    //  Only can be called if Pool is finalized (it is never in our case):
      //    joinPool(uint poolAmountOut, uint[] calldata maxAmountsIn) - only finalized
      await expect(bPool.joinPool(BONE, [BigNumber.from(0)])).to.be.revertedWith("ERR_NOT_FINALIZED");
      //    exitPool(uint poolAmountIn, uint[] calldata minAmountsOut) - only finalized
      await expect(bPool.exitPool(BONE, [BigNumber.from(0)])).to.be.revertedWith("ERR_NOT_FINALIZED");
      //    joinswapExternAmountIn(address tokenIn, uint tokenAmountIn, uint minPoolAmountOut) - only finalized
      await expect(bPool.joinswapExternAmountIn(token.address, BONE, BigNumber.from(0))).to.be.revertedWith("ERR_NOT_FINALIZED");
      //    joinswapPoolAmountOut(address tokenIn, uint poolAmountOut, uint maxAmountIn) - only finalized
      await expect(bPool.joinswapPoolAmountOut(token.address, BONE, BigNumber.from(0))).to.be.revertedWith("ERR_NOT_FINALIZED");
      //    exitswapPoolAmountIn(address tokenOut, uint poolAmountIn, uint minAmountOut)
      await expect(bPool.exitswapPoolAmountIn(token.address, BONE, BigNumber.from(0))).to.be.revertedWith("ERR_NOT_FINALIZED");
      //    exitswapExternAmountOut(address tokenOut, uint tokenAmountOut, uint maxPoolAmountIn)
      await expect(bPool.exitswapExternAmountOut(token.address, BONE, BigNumber.from(0))).to.be.revertedWith("ERR_NOT_FINALIZED");

    //  Only can be called if publicSwap == true (we enable it only during LBP run):
      //    swapExactAmountIn(address tokenIn, uint tokenAmountIn, address tokenOut, uint minAmountOut, uint maxPrice) - only publicSwap
      await expect(bPool.swapExactAmountIn(token.address, BONE, collateral.address, BigNumber.from(0), BONE)).to.be.revertedWith("ERR_NOT_BOUND");
      //    swapExactAmountOut(address tokenIn, uint maxAmountIn, address tokenOut, uint tokenAmountOut, uint maxPrice) - only publicSwap
      await expect(bPool.swapExactAmountOut(token.address, BONE, collateral.address, BigNumber.from(0), BONE)).to.be.revertedWith("ERR_NOT_BOUND");

    console.log("CRP")
    // ============
    //     CRP:
    // ============
    //  Only owner can call it, and we call it via LBPController:
      //    createPool(uint initialSupply,
      //               uint minimumWeightChangeBlockPeriodParam,
      //               uint addTokenTimeLockInBlocksParam) - only owner, we do it only in constructor
      await expect(crp["createPool(uint256,uint256,uint256)"](BONE.mul(BigNumber.from(100)),
                                  BONE.mul(BigNumber.from(100)),
                                  BONE.mul(BigNumber.from(100)))).to.be.revertedWith("ERR_NOT_CONTROLLER");
      //    setPublicSwap(bool publicSwap) - only owner, only if canPauseSwapping, we do it in constructor, startPool, endPool (with block checks)
      await expect(crp.setPublicSwap(true)).to.be.revertedWith("ERR_NOT_CONTROLLER");
      //    updateWeightsGradually(uint[] calldata newWeights, uint startBlock, uint endBlock) - only owner, only if canChangeWeights, we do it only in constructor
      await expect(crp.updateWeightsGradually([BONE, BONE], 123, 234)).to.be.revertedWith("ERR_NOT_CONTROLLER");
      //    removeToken(address token) - only owner, only if canAddRemoveTokens and isCommitted, and no gradual update running, we call it in endPool (with block checks)
      await expect(crp.removeToken(token.address)).to.be.revertedWith("ERR_NOT_CONTROLLER");

    //  Only owner can call it, but we don't have it in LBPController, so it cannot be called anyone, even us:
      //    createPool(uint initialSupply) - only owner, we don't call it
      await expect(crp["createPool(uint256)"](BONE)).to.be.revertedWith("ERR_NOT_CONTROLLER");
      //    setCap(uint newCap) - only owner, only if canChangeCap - we don't call it
      await expect(crp.setCap(BONE)).to.be.revertedWith("ERR_NOT_CONTROLLER");
      //    setSwapFee(uint swapFee) - only owner, only if canChangeSwapFee, we don't call it
      await expect(crp.setSwapFee(BONE)).to.be.revertedWith("ERR_NOT_CONTROLLER");
      //    updateWeight(address token, uint newWeight) - only owner, only if canChangeWeights, we don't call it
      await expect(crp.updateWeight(token.address, BONE)).to.be.revertedWith("ERR_NOT_CONTROLLER");
      //    commitAddToken(address token, uint balance, uint denormalizedWeight) - only owner, only if canAddRemoveTokens, we don't call it
      await expect(crp.commitAddToken(token.address, BONE, BONE)).to.be.revertedWith("ERR_NOT_CONTROLLER");
      //    applyAddToken() - only owner, only if canAddRemoveTokens, we don't call it
      await expect(crp.applyAddToken()).to.be.revertedWith("ERR_NOT_CONTROLLER");
      //    whitelistLiquidityProvider(address provider) - only owner, we don't call it
      await expect(crp.whitelistLiquidityProvider(randomAddress)).to.be.revertedWith("ERR_NOT_CONTROLLER");
      //    removeWhitelistedLiquidityProvider(address provider) - only owner, we don't call it
      await expect(crp.removeWhitelistedLiquidityProvider(randomAddress)).to.be.revertedWith("ERR_NOT_CONTROLLER");

    //  Only whiteListed people can call it, but our whiteList is always empty, and we don't have functions to modify it:
      //    joinPool(uint poolAmountOut, uint[] calldata maxAmountsIn) - only whiteListed, our whiteList is always empty
      await expect(crp.joinPool(BONE, [BONE, BONE])).to.be.revertedWith("ERR_NOT_ON_WHITELIST");
      //    joinswapExternAmountIn(address tokenIn, uint tokenAmountIn, uint minPoolAmountOut) - only whiteListed, our whiteList is always empty
      await expect(crp.joinswapExternAmountIn(token.address, BONE, BONE)).to.be.revertedWith("ERR_NOT_ON_WHITELIST");
      //    joinswapPoolAmountOut(address tokenIn, uint poolAmountOut, uint maxAmountIn) - only whiteListed, our whiteList is always empty
      await expect(crp.joinswapPoolAmountOut(token.address, BONE, BONE)).to.be.revertedWith("ERR_NOT_ON_WHITELIST");

    //  Only somebody with PoolShare can have it (only our LBP contract has it, if we don't use Escape-Hatch to withdraw it):
      //    exitswapPoolAmountIn(address tokenOut, uint poolAmountIn, uint minAmountOut) - only if has PoolShare
      await expect(crp.exitswapPoolAmountIn(token.address, 0, 0)).to.be.revertedWith("ERR_NOT_BOUND");
      //    exitswapExternAmountOut(address tokenOut, uint tokenAmountOut, uint maxPoolAmountIn) - only if has poolShare
      await expect(crp.exitswapExternAmountOut(token.address, BONE, MaxUint256)).to.be.revertedWith("ERR_NOT_BOUND");
      //    exitPool(uint poolAmountIn, uint[] calldata minAmountsOut) - only if has PoolShare
      await expect(crp.exitPool(0, [0, 0])).to.be.revertedWith("ERR_AMOUNTS_MISMATCH");

    //  Internal functions, market as "public", but with require(msg.sender == address(this)) - meaning only contract itself can call it:
      //    mintPoolShareFromLib(uint amount) - only contract itself can call it (internal, but public because of the call from lib)
      await expect(crp.mintPoolShareFromLib(BONE)).to.be.revertedWith("ERR_NOT_CONTROLLER");
      //    pushPoolShareFromLib(address to, uint amount) - same as above
      await expect(crp.pushPoolShareFromLib(randomAddress, BONE)).to.be.revertedWith("ERR_NOT_CONTROLLER");
      //    pullPoolShareFromLib(address from, uint amount) - same as above
      await expect(crp.pullPoolShareFromLib(randomAddress, BONE)).to.be.revertedWith("ERR_NOT_CONTROLLER");
      //    burnPoolShareFromLib(uint amount) - same as above
      await expect(crp.burnPoolShareFromLib(BONE)).to.be.revertedWith("ERR_NOT_CONTROLLER");
  });

  step("Ensure swap attempt after LBP end will be reverted", async () => {
    await collateral.connect(owner).approve(bPool.address, "1000000");
    await expect(
      bPool
        .connect(owner)
        .swapExactAmountIn(
          collateral.address,
          "1000000",
          token.address,
          0,
          MaxUint256.toHexString()
        )
    ).to.be.reverted;
  });
});
