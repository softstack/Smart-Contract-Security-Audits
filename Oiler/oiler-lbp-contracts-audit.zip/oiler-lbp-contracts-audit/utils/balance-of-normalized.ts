import { BigNumber } from "ethers";
import { Token } from "../typechain";

export async function balanceOfNormalized(account: string, token: Token) {
  const decimals = await token.decimals();
  const balanceOf = await token.balanceOf(account);
  return balanceOf.div(BigNumber.from(10).pow(decimals));
}
