export function loadEnv(network?: string) {
  const path = require("path");

  if (!network) {
    network = process.env.HARDHAT_NETWORK_NAME;
  }

  if (!network) {
    let args = process.argv;
    if (args.indexOf("--network") >= 0) {
      network = args[args.indexOf("--network") + 1];
      process.env.HARDHAT_NETWORK_NAME = network;
    } else {
      network = "spaceneth" // default network if nothing specified
      process.env.HARDHAT_NETWORK_NAME = network;
    }
  }

  if (!network) {
    throw new Error("Unable to set network");
  }

  const envPath = path.join(__dirname, "../.env." + network);
  console.log(`loading env from ${envPath}`);
  require("dotenv").config({ path: envPath });
  return network;
}
