import { BigNumber, BigNumberish } from "ethers";
import { Token } from "../typechain";

export async function denormalizeBalance(balance: BigNumberish, token: Token) {
  const decimals = await token.decimals();
  return BigNumber.from(balance).mul(BigNumber.from(10).pow(decimals));
}
