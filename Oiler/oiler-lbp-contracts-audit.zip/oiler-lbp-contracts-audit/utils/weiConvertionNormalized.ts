import { BigNumber, BigNumberish } from "ethers";
import { Token } from "../typechain";

export async function toWei(amount: BigNumberish, token: Token) {
  const decimals = await token.decimals();
  return BigNumber.from(amount).mul(BigNumber.from(10).pow(decimals));
}

export async function fromWei(amount: BigNumberish, token: Token) {
  const decimals = await token.decimals();
  return BigNumber.from(amount).div(BigNumber.from(10).pow(decimals));
}
