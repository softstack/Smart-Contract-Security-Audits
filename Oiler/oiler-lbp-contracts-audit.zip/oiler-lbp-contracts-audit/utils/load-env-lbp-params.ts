import { isAddress } from "ethers/lib/utils";

export function loadEnvLbpParams(): {
  lbpStartBlock: number;
  lbpEndBlock: number;
  lbpOwner: string;
  lbpStartTokenWeight: number;
  lbpStartCollateralWeight: number;
  lbpEndTokenWeight: number;
  lbpEndCollateralWeight: number;
  lbpSwapFee: number;
} {
  // Ensure env params set.
  if (!process.env.LBP_START_BLOCK) throw new Error("LBP start block not defined");
  if (!process.env.LBP_END_BLOCK) throw new Error("LBP end block not defined");
  if (!process.env.START_TOKEN_WEIGHT) throw new Error("LBP start token weight not defined");
  if (!process.env.START_COLLATERAL_WEIGHT) throw new Error("LBP start collateral weight not defined");
  if (!process.env.END_TOKEN_WEIGHT) throw new Error("LBP end token weight not defined");
  if (!process.env.END_COLLATERAL_WEIGHT) throw new Error("LBP end collateral weight not defined");
  if (!process.env.SWAP_FEE) throw new Error("LBP swap fee not defined");
  // if (!process.env.OWNER) throw new Error("LBP owner not defined"); TODO: Figure out how to skip the owner for test nets, but still make sure it is present on mainnet

  if (!Number.isInteger(parseInt(process.env.LBP_START_BLOCK))) throw new Error("LBP start block type invalid");
  if (!Number.isInteger(parseInt(process.env.LBP_END_BLOCK))) throw new Error("LBP end block type invalid");
  if (!Number.isInteger(parseInt(process.env.START_TOKEN_WEIGHT))) throw new Error("LBP start token weight type invalid");
  if (!Number.isInteger(parseInt(process.env.START_COLLATERAL_WEIGHT))) throw new Error("LBP start collateral weight type invalid");
  if (!Number.isInteger(parseInt(process.env.END_TOKEN_WEIGHT))) throw new Error("LBP end token weight type invalid");
  if (!Number.isInteger(parseInt(process.env.END_COLLATERAL_WEIGHT))) throw new Error("LBP end collateral weight type invalid");
  if (!Number.isFinite(parseFloat(process.env.SWAP_FEE))) throw new Error("LBP swap fee type invalid");
  // if (!isAddress(process.env.OWNER)) throw new Error("LBP owner type invalid"); TODO: see todo above

  return {
    lbpStartBlock: Number(process.env.LBP_START_BLOCK),
    lbpEndBlock: Number(process.env.LBP_END_BLOCK),
    lbpOwner: process.env.OWNER,
    lbpStartTokenWeight: Number(process.env.START_TOKEN_WEIGHT),
    lbpStartCollateralWeight: Number(process.env.START_COLLATERAL_WEIGHT),
    lbpEndTokenWeight: Number(process.env.END_TOKEN_WEIGHT),
    lbpEndCollateralWeight: Number(process.env.END_COLLATERAL_WEIGHT),
    lbpSwapFee: Number(process.env.SWAP_FEE),
  };
}
