import "@nomiclabs/hardhat-waffle";
import "hardhat-gas-reporter";
import "hardhat-typechain";

import { HardhatUserConfig } from "hardhat/types";
import { loadEnv } from "./utils/loadEnv";

const network = loadEnv();

// process.env.CONFIG_NAME <- use this for env values
console.log("preloaded", network);

// TODO rename Private key to deployer key.
// TODO: Refactor these 3 private keys into deployer, owner, buyer, and all the logic behind it
const accounts = process.env.PRIVATE_KEY
  ? [
      process.env.PRIVATE_KEY,
      "0xc526ee95bf44d8fc405a158bb884d9d1238d99f0612e9f33d006bb0789009aaa",
      "0x8166f546bab6da521a8369cab06c5d2b9e46670292d85c875ee9ec20e84ffb61",
    ]
  : "remote";

const isAlchemy = process.env.ALCHEMY_API_KEY !== undefined;
const isInfura = process.env.INFURA_API_KEY !== undefined;
const apiKey = process.env.ALCHEMY_API_KEY || process.env.INFURA_API_KEY;
const fallbackUrl = process.env.URL;

const url = isAlchemy
  ? `https://eth-${network}.alchemyapi.io/v2/${apiKey}`
  : isInfura
  ? `https://${network}.infura.io/v3/${apiKey}`
  : fallbackUrl !== undefined
  ? fallbackUrl
  : "http://localhost:8545";

const config: HardhatUserConfig = {
  solidity: {
    version: "0.7.6",
    settings: {
      optimizer: {
        enabled: true,
        runs: 9999,
      },
    },
  },
  networks: {
    hardhat: {
      blockGasLimit: 12000000,
    },
    spaceneth: {
      url,
      accounts,
      gas: 12000000,
    },
    ganache: {
      url,
      chainId: 1337,
      accounts,
    },
    kovan: {
      url,
      accounts,
      gas: 12000000,
      gasPrice: 20000000000,
    },
    ropsten: {
      url,
      accounts,
    },
  },
  mocha: {
    timeout: "20000000000000000000",
  },
};

export default config;
