import { ethers } from "hardhat";
import { deployMocks } from "./utils/deploy-mocks";

import {
  IERC20,
  MultipleTxnsProxy__factory,
  Staking,
  Staking__factory,
} from "../typechain";
import { Signer } from "@ethersproject/abstract-signer";
import { parseEther, formatEther } from "@ethersproject/units";

import { solidity } from "ethereum-waffle";
import * as chai from "chai";
import { expect } from "chai";
import { step } from "mocha-steps";
import { predictContractAddressCREATE } from "./utils/predict-create-address";
import { constants } from "ethers";
import { deployStaking } from "./utils/deploy-staking";

chai.use(solidity);

// TODO tests: multi-user staking - to check if proportions are good
// TODO tests: one user staking multiple stakes
// TODO tests: funny test with locking and unlocking in the same block (that might require stopping mining for a while? maybe not worth the time) (edited)

describe("Oiler Staking contract test", () => {
  let accounts: Signer[];

  // Contracts
  let poolToken: IERC20;
  let oilerToken: IERC20;
  let stakingContract: Staking;

  const stakeParams = {
    tokenAmount: parseEther("1000"),
    lockingPeriod: 10,
  };

  const stakingFundAmount = parseEther("10000");

  before(async () => {
    accounts = await ethers.getSigners();
    const mocks = await deployMocks(ethers);
    poolToken = mocks.poolToken;
    oilerToken = mocks.oilerToken;
  });

  it("Should properly lock tokens", async () => {
    const stakingContract = await deployStaking(ethers, accounts[0], {
      poolToken,
      oilerToken,
    });
    // Transfer some LP tokens to account 1.
    await poolToken.transfer(
      await accounts[1].getAddress(),
      parseEther("10000")
    );

    const lpTokenBalancesOfBeforeLock = {
      locker: await poolToken.balanceOf(await accounts[1].getAddress()),
      staking: await poolToken.balanceOf(stakingContract.address),
    };

    await poolToken
      .connect(accounts[1])
      .approve(stakingContract.address, constants.MaxUint256);

    const lockTx = await stakingContract
      .connect(accounts[1])
      .lockTokens(stakeParams.tokenAmount, stakeParams.lockingPeriod);

    const lpTokenBalancesOfAfterLock = {
      locker: await poolToken.balanceOf(await accounts[1].getAddress()),
      staking: await poolToken.balanceOf(stakingContract.address),
    };

    // Expect staking contract to increase it's balance by 1000 tokens.
    expect(
      lpTokenBalancesOfBeforeLock.staking
        .add(stakeParams.tokenAmount)
        .toString()
    ).to.be.equal(lpTokenBalancesOfAfterLock.staking.toString());

    // Expect locker account to decrease it's balance by 1000 tokens.
    expect(
      lpTokenBalancesOfBeforeLock.locker.sub(stakeParams.tokenAmount).toString()
    ).to.be.equal(lpTokenBalancesOfAfterLock.locker.toString());

    // Check if stake has been properly saved in contract memory.
    const createdStake = await stakingContract.stakes(
      await accounts[1].getAddress()
    );

    expect(createdStake.tokenAmount.toString()).to.be.equal(
      stakeParams.tokenAmount.toString()
    );
    expect(createdStake.startBlock).to.be.equal(lockTx.blockNumber);
    expect(createdStake.lockingPeriodInBlocks).to.be.equal(
      stakeParams.lockingPeriod
    );

    const lockReward = stakeParams.tokenAmount.mul(stakeParams.lockingPeriod);
    const bonusLockReward = lockReward.mul(stakeParams.lockingPeriod);

    const rewardPointsEarned = await stakingContract.rewardPointsEarned(
      await accounts[1].getAddress()
    );
    expect(rewardPointsEarned.toString()).to.be.equal(
      bonusLockReward.toString()
    );

    const totalRewardPoints = await stakingContract.totalRewardPoints();
    expect(totalRewardPoints.toString()).to.be.equal(
      bonusLockReward.toString()
    );
  });

  it("Should throw when unlocking tokens without any lock", async () => {
    const stakingContract = await deployStaking(ethers, accounts[0], {
      oilerToken,
      poolToken,
    });
    await expect(
      stakingContract.connect(accounts[1]).unlockTokens()
    ).to.be.revertedWith("You don't have a stake to unlock");
  });

  it("Should throw when locking again without previous unlock", async () => {
    const stakingContract = await deployStaking(ethers, accounts[0], {
      oilerToken,
      poolToken,
    });

    await poolToken.transfer(
      await accounts[1].getAddress(),
      stakeParams.tokenAmount.mul(2)
    );

    await poolToken
      .connect(accounts[1])
      .approve(stakingContract.address, constants.MaxUint256);

    await stakingContract
      .connect(accounts[1])
      .lockTokens(stakeParams.tokenAmount, stakeParams.lockingPeriod);
    await expect(
      stakingContract
        .connect(accounts[1])
        .lockTokens(stakeParams.tokenAmount, stakeParams.lockingPeriod)
    ).to.be.revertedWith("Already staking");
  });

  it("Should throw when locking without approval", async () => {
    const stakingContract = await deployStaking(ethers, accounts[0], {
      oilerToken,
      poolToken,
    });

    await poolToken.transfer(
      await accounts[1].getAddress(),
      stakeParams.tokenAmount.mul(2)
    );

    await expect(
      stakingContract
        .connect(accounts[1])
        .lockTokens(stakeParams.tokenAmount, stakeParams.lockingPeriod)
    ).to.be.revertedWith("ERC20: transfer amount exceeds allowance");
  });

  it("Should throw when claiming rewards without previous lock", async () => {
    const stakingContract = await deployStaking(ethers, accounts[0], {
      oilerToken,
      poolToken,
    });

    const stakingProgramEndsBlock = await stakingContract.stakingProgramEndsBlock();
    const currentBlock = await accounts[1].provider.getBlockNumber();
    for (
      let i = 0;
      i < stakingProgramEndsBlock.toNumber() - currentBlock;
      i++
    ) {
      await ethers.provider.send("evm_mine", []);
    }

    await expect(
      stakingContract.connect(accounts[1]).getRewards()
    ).to.be.revertedWith("You don't have any rewardPoints");
  });

  it("Should throw when claiming rewards without previous unlock", async () => {
    const stakingContract = await deployStaking(ethers, accounts[0], {
      oilerToken,
      poolToken,
    });

    await poolToken.transfer(
      await accounts[1].getAddress(),
      stakeParams.tokenAmount.mul(2)
    );

    await poolToken
      .connect(accounts[1])
      .approve(stakingContract.address, constants.MaxUint256);

    await stakingContract
      .connect(accounts[1])
      .lockTokens(stakeParams.tokenAmount, stakeParams.lockingPeriod);

    const stakingProgramEndsBlock = await stakingContract.stakingProgramEndsBlock();
    const currentBlock = await accounts[1].provider.getBlockNumber();
    for (
      let i = 0;
      i < stakingProgramEndsBlock.toNumber() - currentBlock;
      i++
    ) {
      await ethers.provider.send("evm_mine", []);
    }

    await expect(
      stakingContract.connect(accounts[1]).getRewards()
    ).to.be.revertedWith(
      "You still have a stake locked - please unlock first, don't leave free money here"
    );
  });

  it("Should throw when trying to release vesting without previous staking", async () => {
    const stakingContract = await deployStaking(ethers, accounts[0], {
      oilerToken,
      poolToken,
    });

    await poolToken.transfer(
      await accounts[1].getAddress(),
      stakeParams.tokenAmount.mul(2)
    );

    await poolToken
      .connect(accounts[1])
      .approve(stakingContract.address, constants.MaxUint256);

    const stakingProgramEndsBlock = await stakingContract.stakingProgramEndsBlock();
    const currentBlock = await accounts[1].provider.getBlockNumber();
    for (
      let i = 0;
      i < stakingProgramEndsBlock.toNumber() - currentBlock;
      i++
    ) {
      await ethers.provider.send("evm_mine", []);
    }

    await expect(
      stakingContract.connect(accounts[1]).release()
    ).to.be.revertedWith("Vesting release: no tokens are due");
  });

  it("Should throw when trying to release vesting without unlocking", async () => {
    const stakingContract = await deployStaking(ethers, accounts[0], {
      oilerToken,
      poolToken,
    });

    await poolToken.transfer(
      await accounts[1].getAddress(),
      stakeParams.tokenAmount.mul(2)
    );

    await poolToken
      .connect(accounts[1])
      .approve(stakingContract.address, constants.MaxUint256);

    await stakingContract
      .connect(accounts[1])
      .lockTokens(stakeParams.tokenAmount, stakeParams.lockingPeriod);

    const stakingProgramEndsBlock = await stakingContract.stakingProgramEndsBlock();
    const currentBlock = await accounts[1].provider.getBlockNumber();
    for (
      let i = 0;
      i < stakingProgramEndsBlock.toNumber() - currentBlock;
      i++
    ) {
      await ethers.provider.send("evm_mine", []);
    }

    await expect(
      stakingContract.connect(accounts[1]).release()
    ).to.be.revertedWith("Vesting release: no tokens are due");
  });

  it("Should throw when trying to lock after program ends", async () => {
    const stakingContract = await deployStaking(ethers, accounts[0], {
      oilerToken,
      poolToken,
    });

    await poolToken.transfer(
      await accounts[1].getAddress(),
      stakeParams.tokenAmount.mul(2)
    );

    await poolToken
      .connect(accounts[1])
      .approve(stakingContract.address, constants.MaxUint256);

    await stakingContract
      .connect(accounts[1])
      .lockTokens(stakeParams.tokenAmount, stakeParams.lockingPeriod);

    const stakingProgramEndsBlock = await stakingContract.stakingProgramEndsBlock();
    const currentBlock = await accounts[1].provider.getBlockNumber();
    for (
      let i = 0;
      i < stakingProgramEndsBlock.toNumber() - currentBlock;
      i++
    ) {
      await ethers.provider.send("evm_mine", []);
    }

    await expect(
      stakingContract.connect(accounts[1]).lockTokens(1, 1)
    ).to.be.revertedWith("Your lock period exceeds Staking Program duration");
  });

  it("Should throw when trying to overflow locking period", async () => {
    const stakingContract = await deployStaking(ethers, accounts[0], {
      oilerToken,
      poolToken,
    });

    await poolToken.transfer(
      await accounts[1].getAddress(),
      stakeParams.tokenAmount.mul(2)
    );

    await poolToken
      .connect(accounts[1])
      .approve(stakingContract.address, constants.MaxUint256);

    await stakingContract
      .connect(accounts[1])
      .lockTokens(stakeParams.tokenAmount, stakeParams.lockingPeriod);

    const stakingProgramEndsBlock = await stakingContract.stakingProgramEndsBlock();
    const currentBlock = await accounts[1].provider.getBlockNumber();
    for (
      let i = 0;
      i < stakingProgramEndsBlock.toNumber() - currentBlock;
      i++
    ) {
      await ethers.provider.send("evm_mine", []);
    }

    await expect(stakingContract.connect(accounts[1]).lockTokens(1, "16777215"))
      .to.be.reverted;
  });

  it("Should throw when pool token is not set", async () => {
    const factory = (await ethers.getContractFactory(
      "Staking"
    )) as Staking__factory;

    const deployerAddress = await accounts[0].getAddress();
    const currentNonce = await accounts[0].getTransactionCount();
    const stakingContractAddress = predictContractAddressCREATE(
      deployerAddress,
      currentNonce + 1
    );

    await oilerToken.approve(stakingContractAddress, parseEther("10000"));

    const stakingContract = await factory.deploy(
      oilerToken.address,
      0,
      await accounts[0].getAddress(),
      parseEther("40"),
      parseEther("40"),
      await accounts[0].getAddress()
    );

    await expect(stakingContract.lockTokens(20, 10)).to.be.revertedWith(
      "poolToken not set"
    );
  });

  it("Should throw when claiming rewards before Staking Program ends", async () => {
    const stakingContract = await deployStaking(ethers, accounts[0], {
      oilerToken,
      poolToken,
    });

    await poolToken.transfer(
      await accounts[1].getAddress(),
      stakeParams.tokenAmount.mul(2)
    );

    await poolToken
      .connect(accounts[1])
      .approve(stakingContract.address, constants.MaxUint256);

    await stakingContract
      .connect(accounts[1])
      .lockTokens(stakeParams.tokenAmount, stakeParams.lockingPeriod);

    step("Wait for the stake to end", async () => {
      for (let i = 0; i < stakeParams.lockingPeriod; i++) {
        await ethers.provider.send("evm_mine", []);
      }
    });

    await stakingContract.connect(accounts[1]).unlockTokens();

    await expect(
      stakingContract.connect(accounts[1]).getRewards()
    ).to.be.revertedWith("You can only get Rewards after Staking Program ends");
  });

  it("Should throw when releasing vested tokens before Staking Program ends", async () => {
    const stakingContract = await deployStaking(ethers, accounts[0], {
      oilerToken,
      poolToken,
    });

    await poolToken.transfer(
      await accounts[1].getAddress(),
      stakeParams.tokenAmount.mul(2)
    );

    await poolToken
      .connect(accounts[1])
      .approve(stakingContract.address, constants.MaxUint256);

    await stakingContract
      .connect(accounts[1])
      .lockTokens(stakeParams.tokenAmount, stakeParams.lockingPeriod);

    step("Wait for the stake to end", async () => {
      for (let i = 0; i < stakeParams.lockingPeriod; i++) {
        await ethers.provider.send("evm_mine", []);
      }
    });

    await stakingContract.connect(accounts[1]).unlockTokens();

    await expect(stakingContract.connect(accounts[1]).release()).to.be.reverted;
  });

  it("Should throw when locking 0 tokens", async () => {
    const stakingContract = await deployStaking(ethers, accounts[0], {
      oilerToken,
      poolToken,
    });

    await poolToken.transfer(
      await accounts[1].getAddress(),
      stakeParams.tokenAmount.mul(2)
    );

    await poolToken
      .connect(accounts[1])
      .approve(stakingContract.address, constants.MaxUint256);

    await expect(
      stakingContract
        .connect(accounts[1])
        .lockTokens(0, stakeParams.lockingPeriod)
    ).to.be.revertedWith("Neither tokenAmount nor lockingPeriod couldn't be 0");
  });

  it("Should throw when locking tokens with 0 blocks period", async () => {
    const stakingContract = await deployStaking(ethers, accounts[0], {
      oilerToken,
      poolToken,
    });

    await poolToken.transfer(
      await accounts[1].getAddress(),
      stakeParams.tokenAmount.mul(2)
    );

    await poolToken
      .connect(accounts[1])
      .approve(stakingContract.address, constants.MaxUint256);

    await expect(
      stakingContract
        .connect(accounts[1])
        .lockTokens(stakeParams.tokenAmount, 0)
    ).to.be.revertedWith("Neither tokenAmount nor lockingPeriod couldn't be 0");
  });

  it("Should set pool token", async () => {
    const factory = (await ethers.getContractFactory(
      "Staking"
    )) as Staking__factory;

    const deployerAddress = await accounts[0].getAddress();
    const currentNonce = await accounts[0].getTransactionCount();
    const stakingContractAddress = predictContractAddressCREATE(
      deployerAddress,
      currentNonce + 1
    );

    await oilerToken.approve(stakingContractAddress, parseEther("10000"));

    const stakingContract = await factory.deploy(
      oilerToken.address,
      0,
      await accounts[0].getAddress(),
      parseEther("40"),
      parseEther("40"),
      await accounts[0].getAddress()
    );

    await stakingContract.connect(accounts[0]).setPoolToken(poolToken.address);

    const poolTokenAddress = await stakingContract.poolToken();

    expect(poolTokenAddress.toLocaleLowerCase()).to.not.be.equal(
      constants.AddressZero.toLocaleLowerCase()
    );
  });

  it("Should throw when trying to set poolToken address to 0", async () => {
    const factory = (await ethers.getContractFactory(
      "Staking"
    )) as Staking__factory;

    const deployerAddress = await accounts[0].getAddress();
    const currentNonce = await accounts[0].getTransactionCount();
    const stakingContractAddress = predictContractAddressCREATE(
      deployerAddress,
      currentNonce + 1
    );

    await oilerToken.approve(stakingContractAddress, parseEther("10000"));

    const stakingContract = await factory.deploy(
      oilerToken.address,
      0,
      await accounts[0].getAddress(),
      parseEther("40"),
      parseEther("40"),
      await accounts[0].getAddress()
    );

    await expect(
      stakingContract.connect(accounts[0]).setPoolToken(constants.AddressZero)
    ).to.be.revertedWith("poolToken address cannot be zero");
  });

  it("Should throw when trying to set poolToken address multiple times", async () => {
    const factory = (await ethers.getContractFactory(
      "Staking"
    )) as Staking__factory;

    const deployerAddress = await accounts[0].getAddress();
    const currentNonce = await accounts[0].getTransactionCount();
    const stakingContractAddress = predictContractAddressCREATE(
      deployerAddress,
      currentNonce + 1
    );

    await oilerToken.approve(stakingContractAddress, parseEther("10000"));

    const stakingContract = await factory.deploy(
      oilerToken.address,
      0,
      await accounts[0].getAddress(),
      parseEther("40"),
      parseEther("40"),
      await accounts[0].getAddress()
    );

    await stakingContract.connect(accounts[0]).setPoolToken(poolToken.address);

    await expect(
      stakingContract.connect(accounts[0]).setPoolToken(poolToken.address)
    ).to.be.revertedWith("poolToken was already set");
  });

  it("Should throw when not an owner is trying to set poolToken address", async () => {
    const factory = (await ethers.getContractFactory(
      "Staking"
    )) as Staking__factory;

    const deployerAddress = await accounts[0].getAddress();
    const currentNonce = await accounts[0].getTransactionCount();
    const stakingContractAddress = predictContractAddressCREATE(
      deployerAddress,
      currentNonce + 1
    );

    await oilerToken.approve(stakingContractAddress, parseEther("10000"));

    const stakingContract = await factory.deploy(
      oilerToken.address,
      0,
      await accounts[0].getAddress(),
      parseEther("40"),
      parseEther("40"),
      await accounts[0].getAddress()
    );

    await expect(
      stakingContract.connect(accounts[1]).setPoolToken(poolToken.address)
    ).to.be.revertedWith("Can only be called by owner");
  });

  it("Should throw when tokens are locked and unlocked in the same block", async () => {
    const stakingContract = await deployStaking(ethers, accounts[0], {
      poolToken,
      oilerToken,
    });

    const testMultipleTxnsProxy = await (<MultipleTxnsProxy__factory>(
      await ethers.getContractFactory("MultipleTxnsProxy")
    )).deploy();

    // Transfer some LP tokens to test proxy.
    await poolToken.transfer(
      testMultipleTxnsProxy.address,
      stakeParams.tokenAmount
    );

    const approveTx = await poolToken.populateTransaction.approve(
      stakingContract.address,
      stakeParams.tokenAmount
    );
    const lockTx = await stakingContract.populateTransaction.lockTokens(
      stakeParams.tokenAmount,
      stakeParams.lockingPeriod
    );
    const unlockTx = await stakingContract.populateTransaction.unlockTokens();

    await expect(
      testMultipleTxnsProxy.multipleExecution(
        [approveTx.data, lockTx.data, unlockTx.data],
        [poolToken.address, stakingContract.address, stakingContract.address]
      )
    ).to.be.reverted;
  });

  describe("Constructor reverts test", () => {
    it("Should revert when owner address is 0", async () => {
      const factory = (await ethers.getContractFactory(
        "Staking"
      )) as Staking__factory;
      await expect(
        factory.deploy(
          oilerToken.address,
          0,
          await accounts[0].getAddress(),
          parseEther("40"),
          parseEther("40"),
          constants.AddressZero
        )
      ).to.be.revertedWith("Owner address cannot be zero");
    });

    it("Should revert when oilerToken address is 0", async () => {
      const factory = (await ethers.getContractFactory(
        "Staking"
      )) as Staking__factory;
      await expect(
        factory.deploy(
          constants.AddressZero,
          0,
          await accounts[0].getAddress(),
          parseEther("40"),
          parseEther("40"),
          await accounts[0].getAddress()
        )
      ).to.be.revertedWith("oilerToken address cannot be zero");
    });

    it("Should revert when staking fund address is 0", async () => {
      const factory = (await ethers.getContractFactory(
        "Staking"
      )) as Staking__factory;
      await expect(
        factory.deploy(
          oilerToken.address,
          0,
          constants.AddressZero,
          parseEther("40"),
          parseEther("40"),
          await accounts[0].getAddress()
        )
      ).to.be.revertedWith("StakingFund address cannot be zero");
    });

    it("Should revert when staking fund address does not have enought tokens", async () => {
      const factory = (await ethers.getContractFactory(
        "Staking"
      )) as Staking__factory;

      const stakingFundAddress = await accounts[2].getAddress();

      await expect(
        factory.deploy(
          oilerToken.address,
          100,
          stakingFundAddress,
          parseEther("1000"),
          30,
          await accounts[0].getAddress()
        )
      ).to.be.revertedWith("StakingFund doesn't have enough OIL balance");
    });

    it("Should revert when staking fund address did not set allowance", async () => {
      const factory = (await ethers.getContractFactory(
        "Staking"
      )) as Staking__factory;

      const stakingFundAddress = await accounts[2].getAddress();

      await oilerToken
        .connect(accounts[0])
        .transfer(stakingFundAddress, parseEther("1000"));

      await expect(
        factory.deploy(
          oilerToken.address,
          100,
          stakingFundAddress,
          parseEther("1000"),
          30,
          await accounts[0].getAddress()
        )
      ).to.be.revertedWith("StakingFund doesn't have enough allowance");
    });
  });

  describe("Constructor test", () => {
    before(async () => {
      accounts = await ethers.getSigners();
    });

    it("Should initialize the contract properly", async () => {
      const { poolToken, oilerToken } = await deployMocks(ethers);
      const Staking = (await ethers.getContractFactory(
        "Staking"
      )) as Staking__factory;

      const deployerAddress = await accounts[0].getAddress();
      const currentNonce = await accounts[0].getTransactionCount();
      const stakingContractAddress = predictContractAddressCREATE(
        deployerAddress,
        currentNonce + 1
      );

      await oilerToken.approve(stakingContractAddress, stakingFundAmount);

      const stakingContract = await Staking.deploy(
        oilerToken.address,
        100,
        await accounts[0].getAddress(),
        stakingFundAmount,
        200,
        await accounts[0].getAddress()
      );

      await stakingContract.setPoolToken(poolToken.address);

      const contractOilerBalance = await oilerToken.balanceOf(
        stakingContract.address
      );
      expect(contractOilerBalance.toString()).to.be.equal(
        stakingFundAmount.toString()
      );

      expect(
        (await stakingContract.stakingFundAmount()).toString()
      ).to.be.equal(stakingFundAmount.toString());

      const stakingProgramEndsBlock = await stakingContract.stakingProgramEndsBlock();
      expect(stakingProgramEndsBlock.toNumber()).to.be.equal(
        stakingContract.deployTransaction.blockNumber + 100
      );

      const poolTokenAddress = await stakingContract.poolToken();
      expect(poolTokenAddress.toLocaleLowerCase()).to.be.equal(
        poolToken.address.toLocaleLowerCase()
      );

      const oilerTokenAddress = await stakingContract.oilerToken();
      expect(oilerTokenAddress.toLocaleLowerCase()).to.be.equal(
        oilerToken.address.toLocaleLowerCase()
      );

      const vestingDuration = await stakingContract.vestingDuration();
      expect(vestingDuration.toNumber()).to.be.equal(200);
    });
  });

  describe("Staking scenario test", () => {
    before(async () => {
      accounts = await ethers.getSigners();

      const mocks = await deployMocks(ethers);
      poolToken = mocks.poolToken;
      oilerToken = mocks.oilerToken;

      const Staking = (await ethers.getContractFactory(
        "Staking"
      )) as Staking__factory;

      const deployerAddress = await accounts[0].getAddress();
      const currentNonce = await accounts[0].getTransactionCount();
      const stakingContractAddress = predictContractAddressCREATE(
        deployerAddress,
        currentNonce + 1
      );

      await oilerToken.approve(stakingContractAddress, stakingFundAmount);

      stakingContract = await Staking.deploy(
        oilerToken.address,
        100,
        await accounts[0].getAddress(),
        stakingFundAmount,
        200,
        await accounts[0].getAddress()
      );

      await stakingContract.setPoolToken(poolToken.address);

      await poolToken.transfer(
        await accounts[1].getAddress(),
        stakeParams.tokenAmount
      );
    });

    step("Lock tokens for 10 blocks", async () => {
      await poolToken
        .connect(accounts[1])
        .approve(stakingContract.address, constants.MaxUint256);
      await stakingContract
        .connect(accounts[1])
        .lockTokens(stakeParams.tokenAmount, stakeParams.lockingPeriod);
    });

    step("Wait 10 blocks", async () => {
      for (let i = 0; i < 10; i++) {
        await ethers.provider.send("evm_mine", []);
      }
    });

    step("Unlock tokens", async () => {
      const contractBalancesBefore = {
        oil: await oilerToken.balanceOf(stakingContract.address),
        pool: await poolToken.balanceOf(stakingContract.address),
      };

      const preUnlock = await stakingContract.rewardPointsEarned(
        await accounts[1].getAddress()
      );

      await stakingContract.connect(accounts[1]).unlockTokens();

      const postUnlock = await stakingContract.rewardPointsEarned(
        await accounts[1].getAddress()
      );

      const lockReward = stakeParams.tokenAmount.mul(stakeParams.lockingPeriod);
      const bonusLockReward = lockReward.mul(stakeParams.lockingPeriod);

      expect(postUnlock.toString()).to.be.equal(
        preUnlock.toString(),
        "Unlocking slashed the bonus"
      );

      const contractBalancesAfter = {
        oil: await oilerToken.balanceOf(stakingContract.address),
        pool: await poolToken.balanceOf(stakingContract.address),
      };

      const balanceAfterUnlock = await poolToken.balanceOf(
        await accounts[1].getAddress()
      );

      expect(contractBalancesBefore.oil.toString()).to.be.equal(
        contractBalancesAfter.oil.toString(),
        "Oil balance changed"
      );

      expect(
        contractBalancesBefore.pool.sub(stakeParams.tokenAmount).toString()
      ).to.be.equal(
        contractBalancesAfter.pool.toString(),
        "Returned LP amount after unlock doesn't match stake"
      );

      expect(balanceAfterUnlock.toString()).to.be.equal(
        stakeParams.tokenAmount,
        "Returned balance of LPs doesn't match the locked stake"
      );
    });

    step("Wait until staking ends", async () => {
      const stakingProgramEndsBlock = await stakingContract.stakingProgramEndsBlock();
      const currentBlock = await accounts[1].provider.getBlockNumber();

      for (
        let i = 0;
        i < stakingProgramEndsBlock.toNumber() - currentBlock;
        i++
      ) {
        await ethers.provider.send("evm_mine", []);
      }
    });

    step("Get rewards", async () => {
      const lockReward = stakeParams.tokenAmount.mul(stakeParams.lockingPeriod);
      const bonusLockReward = lockReward.mul(stakeParams.lockingPeriod);

      const preRewards = await stakingContract.rewardPointsEarned(
        await accounts[1].getAddress()
      );

      expect(preRewards).to.be.equal(bonusLockReward);

      await stakingContract.connect(accounts[1]).getRewards();
      const postRewards = await stakingContract.rewardPointsEarned(
        await accounts[1].getAddress()
      );
      expect(postRewards.toString()).to.be.equal("0");

      const harvest = bonusLockReward
        .mul(stakingFundAmount)
        .div(await stakingContract.totalRewardPoints());

      expect(
        await stakingContract.grantedTokens(await accounts[1].getAddress())
      ).to.be.equal(harvest);
    });

    step("Wait vesting period", async () => {
      const vestingDurationBlocks = await stakingContract.vestingDuration();
      for (let i = 0; i < vestingDurationBlocks.toNumber(); i++) {
        ethers.provider.send("evm_mine", []);
      }
    });

    step("Release Vesting reward", async () => {
      const oilBalanceBefore = await oilerToken.balanceOf(
        await accounts[1].getAddress()
      );
      await stakingContract.connect(accounts[1]).release();

      const oilBalanceAfter = await oilerToken.balanceOf(
        await accounts[1].getAddress()
      );

      const released = oilBalanceAfter.sub(oilBalanceBefore);

      const _released = await stakingContract.releasedTokens(
        await accounts[1].getAddress()
      );

      expect(released.toString()).to.be.equal(_released.toString());

      const lockReward = stakeParams.tokenAmount.mul(stakeParams.lockingPeriod);
      const bonusLockReward = lockReward.mul(stakeParams.lockingPeriod);
      const harvest = bonusLockReward
        .mul(stakingFundAmount)
        .div(await stakingContract.totalRewardPoints());

      expect(released.toString()).to.be.equal(harvest.toString());
    });
  });

  describe("Staking scenario test with early unlock punishment", () => {
    before(async () => {
      accounts = await ethers.getSigners();

      const mocks = await deployMocks(ethers);
      poolToken = mocks.poolToken;
      oilerToken = mocks.oilerToken;

      const Staking = (await ethers.getContractFactory(
        "Staking"
      )) as Staking__factory;

      const deployerAddress = await accounts[0].getAddress();
      const currentNonce = await accounts[0].getTransactionCount();
      const stakingContractAddress = predictContractAddressCREATE(
        deployerAddress,
        currentNonce + 1
      );

      await oilerToken.approve(stakingContractAddress, parseEther("10000"));

      stakingContract = await Staking.deploy(
        oilerToken.address,
        100,
        await accounts[0].getAddress(),
        stakingFundAmount,
        200,
        await accounts[0].getAddress()
      );

      await stakingContract.setPoolToken(poolToken.address);

      await poolToken.transfer(
        await accounts[1].getAddress(),
        stakeParams.tokenAmount
      );
    });

    step("Lock tokens for 10 blocks", async () => {
      await poolToken
        .connect(accounts[1])
        .approve(stakingContract.address, constants.MaxUint256);
      await stakingContract
        .connect(accounts[1])
        .lockTokens(stakeParams.tokenAmount, stakeParams.lockingPeriod);
    });

    step("Wait 5 blocks", async () => {
      for (let i = 0; i < 5; i++) {
        await ethers.provider.send("evm_mine", []);
      }
    });

    step("Unlock tokens prematurely", async () => {
      const contractBalancesBefore = {
        oil: await oilerToken.balanceOf(stakingContract.address),
        pool: await poolToken.balanceOf(stakingContract.address),
      };

      const preRewards = await stakingContract.rewardPointsEarned(
        await accounts[1].getAddress()
      );

      const unlockTx = await stakingContract
        .connect(accounts[1])
        .unlockTokens();

      const postRewards = await stakingContract.rewardPointsEarned(
        await accounts[1].getAddress()
      );

      const lockReward = stakeParams.tokenAmount.mul(stakeParams.lockingPeriod);
      const bonusLockReward = lockReward.mul(stakeParams.lockingPeriod);

      expect(preRewards.sub(postRewards).toString()).to.be.equal(
        bonusLockReward.toString(),
        "Bonus didn't slash for premature unlocking"
      );

      const contractBalancesAfter = {
        oil: await oilerToken.balanceOf(stakingContract.address),
        pool: await poolToken.balanceOf(stakingContract.address),
      };

      const balanceAfterUnlock = await poolToken.balanceOf(
        await accounts[1].getAddress()
      );

      expect(unlockTx).to.emit(stakingContract, "StakeUnlockedPrematurely");

      expect(contractBalancesBefore.oil.toString()).to.be.equal(
        contractBalancesAfter.oil.toString()
      );

      expect(
        contractBalancesBefore.pool.sub(stakeParams.tokenAmount).toString()
      ).to.be.equal(contractBalancesAfter.pool.toString());

      expect(balanceAfterUnlock.toString()).to.be.equal(
        stakeParams.tokenAmount.toString()
      );
    });

    step("Wait until staking ends", async () => {
      const stakingProgramEndsBlock = await stakingContract.stakingProgramEndsBlock();
      const currentBlock = await accounts[1].provider.getBlockNumber();

      for (
        let i = 0;
        i < stakingProgramEndsBlock.toNumber() - currentBlock;
        i++
      ) {
        await ethers.provider.send("evm_mine", []);
      }
    });

    step("Try to get rewards", async () => {
      await expect(
        stakingContract.connect(accounts[1]).getRewards()
      ).to.be.revertedWith("You don't have any rewardPoints");
    });

    step("Try to release Vesting reward", async () => {
      await expect(
        stakingContract.connect(accounts[1]).release()
      ).to.be.revertedWith("Vesting release: no tokens are due");
    });
  });

  describe("Staking scenario without any locking", () => {
    before(async () => {
      accounts = await ethers.getSigners();

      const mocks = await deployMocks(ethers);
      poolToken = mocks.poolToken;
      oilerToken = mocks.oilerToken;

      const Staking = (await ethers.getContractFactory(
        "Staking"
      )) as Staking__factory;

      const deployerAddress = await accounts[0].getAddress();
      const currentNonce = await accounts[0].getTransactionCount();
      const stakingContractAddress = predictContractAddressCREATE(
        deployerAddress,
        currentNonce + 1
      );

      await oilerToken.approve(stakingContractAddress, stakingFundAmount);

      stakingContract = await Staking.deploy(
        oilerToken.address,
        100,
        await accounts[0].getAddress(),
        stakingFundAmount,
        200,
        await accounts[0].getAddress()
      );

      await stakingContract.setPoolToken(poolToken.address);

      await poolToken.transfer(
        await accounts[1].getAddress(),
        stakeParams.tokenAmount
      );
    });

    step("Wait until staking ends", async () => {
      const stakingProgramEndsBlock = await stakingContract.stakingProgramEndsBlock();
      const currentBlock = await accounts[1].provider.getBlockNumber();

      for (
        let i = 0;
        i < stakingProgramEndsBlock.toNumber() - currentBlock;
        i++
      ) {
        await ethers.provider.send("evm_mine", []);
      }
    });

    step("Try to get rewards", async () => {
      await expect(
        stakingContract.connect(accounts[1]).getRewards()
      ).to.be.revertedWith("You don't have any rewardPoints");
    });

    step("Try to release Vesting reward", async () => {
      await expect(
        stakingContract.connect(accounts[1]).release()
      ).to.be.revertedWith("Vesting release: no tokens are due");
    });
  });

  describe("Staking scenario with release in the middle of vesting", () => {
    before(async () => {
      accounts = await ethers.getSigners();

      const mocks = await deployMocks(ethers);
      poolToken = mocks.poolToken;
      oilerToken = mocks.oilerToken;

      const Staking = (await ethers.getContractFactory(
        "Staking"
      )) as Staking__factory;

      const deployerAddress = await accounts[0].getAddress();
      const currentNonce = await accounts[0].getTransactionCount();
      const stakingContractAddress = predictContractAddressCREATE(
        deployerAddress,
        currentNonce + 1
      );

      await oilerToken.approve(stakingContractAddress, stakingFundAmount);

      stakingContract = await Staking.deploy(
        oilerToken.address,
        100,
        await accounts[0].getAddress(),
        stakingFundAmount,
        200,
        await accounts[0].getAddress()
      );

      await stakingContract.setPoolToken(poolToken.address);

      await poolToken.transfer(
        await accounts[1].getAddress(),
        stakeParams.tokenAmount
      );
    });

    step("Lock tokens for 10 blocks", async () => {
      await poolToken
        .connect(accounts[1])
        .approve(stakingContract.address, constants.MaxUint256);
      await stakingContract
        .connect(accounts[1])
        .lockTokens(stakeParams.tokenAmount, stakeParams.lockingPeriod);
    });

    step("Wait 10 blocks", async () => {
      for (let i = 0; i < 10; i++) {
        await ethers.provider.send("evm_mine", []);
      }
    });

    step("Unlock tokens", async () => {
      const contractBalancesBefore = {
        oil: await oilerToken.balanceOf(stakingContract.address),
        pool: await poolToken.balanceOf(stakingContract.address),
      };

      const preUnlock = await stakingContract.rewardPointsEarned(
        await accounts[1].getAddress()
      );

      const lockReward = stakeParams.tokenAmount.mul(stakeParams.lockingPeriod);
      const bonusLockReward = lockReward.mul(stakeParams.lockingPeriod);

      expect(preUnlock.toString()).to.be.equal(
        bonusLockReward.toString(),
        "Bonus doesn't match expected"
      );

      await stakingContract.connect(accounts[1]).unlockTokens();

      const postUnlock = await stakingContract.rewardPointsEarned(
        await accounts[1].getAddress()
      );

      expect(postUnlock.toString()).to.be.equal(
        preUnlock.toString(),
        "Bonus was slashed"
      );

      const contractBalancesAfter = {
        oil: await oilerToken.balanceOf(stakingContract.address),
        pool: await poolToken.balanceOf(stakingContract.address),
      };

      const balanceAfterUnlock = await poolToken.balanceOf(
        await accounts[1].getAddress()
      );

      expect(contractBalancesBefore.oil.toString()).to.be.equal(
        contractBalancesAfter.oil.toString()
      );

      expect(
        contractBalancesBefore.pool.sub(stakeParams.tokenAmount).toString()
      ).to.be.equal(contractBalancesAfter.pool.toString());

      expect(balanceAfterUnlock.toString()).to.be.equal(
        stakeParams.tokenAmount.toString()
      );
    });

    step("Wait until staking ends", async () => {
      const stakingProgramEndsBlock = await stakingContract.stakingProgramEndsBlock();
      const currentBlock = await accounts[1].provider.getBlockNumber();

      for (
        let i = 0;
        i < stakingProgramEndsBlock.toNumber() - currentBlock;
        i++
      ) {
        await ethers.provider.send("evm_mine", []);
      }
    });

    step("Get rewards", async () => {
      const preRewards = await stakingContract.rewardPointsEarned(
        await accounts[1].getAddress()
      );

      const lockReward = stakeParams.tokenAmount.mul(stakeParams.lockingPeriod);
      const bonusLockReward = lockReward.mul(stakeParams.lockingPeriod);

      expect(preRewards.toString()).to.be.equal(bonusLockReward.toString());

      await stakingContract.connect(accounts[1]).getRewards();

      const postRewards = await stakingContract.rewardPointsEarned(
        await accounts[1].getAddress()
      );

      expect(postRewards.toString()).to.be.equal("0");
    });

    step("Wait half of vesting period", async () => {
      const stakingProgramEndsBlock = await stakingContract.stakingProgramEndsBlock();
      const currentBlock = await accounts[1].provider.getBlockNumber();
      const vestingDuration = await stakingContract.vestingDuration();
      const halfOfVestingPeriodBlock = stakingProgramEndsBlock.add(
        vestingDuration.div(2)
      );
      for (
        let i = 0;
        i < halfOfVestingPeriodBlock.sub(currentBlock).toNumber() - 1;
        i++
      ) {
        ethers.provider.send("evm_mine", []);
      }
    });

    step("Release half of reward", async () => {
      const oilBalanceBefore = await oilerToken.balanceOf(
        await accounts[1].getAddress()
      );

      await stakingContract.connect(accounts[1]).release();

      const oilBalanceAfter = await oilerToken.balanceOf(
        await accounts[1].getAddress()
      );

      const released = oilBalanceAfter.sub(oilBalanceBefore);

      const _released = await stakingContract.releasedTokens(
        await accounts[1].getAddress()
      );

      expect(released.toString()).to.be.equal(
        _released.toString(),
        "Released amount doesn't match the balance change"
      );

      const lockReward = stakeParams.tokenAmount.mul(stakeParams.lockingPeriod);
      const bonusLockReward = lockReward.mul(stakeParams.lockingPeriod);
      const harvest = bonusLockReward
        .mul(stakingFundAmount)
        .div(await stakingContract.totalRewardPoints());

      expect(released.toString()).to.be.equal(
        harvest.div(2).toString(),
        "Released reward was not a half"
      );
    });

    step("Wait until end of vesting period", async () => {
      const currentBlock = await accounts[1].provider.getBlockNumber();
      const stakingProgramEndsBlock = await stakingContract.stakingProgramEndsBlock();
      const vestingDuration = await stakingContract.vestingDuration();
      const vestingPeriodEndBlock = stakingProgramEndsBlock.add(
        vestingDuration
      );
      for (
        let i = 0;
        i < vestingPeriodEndBlock.sub(currentBlock).toNumber();
        i++
      ) {
        ethers.provider.send("evm_mine", []);
      }
    });

    step("Release other half of reward", async () => {
      const oilBalanceBefore = await oilerToken.balanceOf(
        await accounts[1].getAddress()
      );

      await stakingContract.connect(accounts[1]).release();

      const oilBalanceAfter = await oilerToken.balanceOf(
        await accounts[1].getAddress()
      );

      const released = oilBalanceAfter.sub(oilBalanceBefore);

      const _released = await stakingContract.releasedTokens(
        await accounts[1].getAddress()
      );

      const lockReward = stakeParams.tokenAmount.mul(stakeParams.lockingPeriod);
      const bonusLockReward = lockReward.mul(stakeParams.lockingPeriod);
      const harvest = bonusLockReward
        .mul(stakingFundAmount)
        .div(await stakingContract.totalRewardPoints());

      expect(oilBalanceAfter.toString()).to.be.equal(
        _released.toString(),
        "Released amount doesn't match balance"
      );
      expect(
        await stakingContract.grantedTokens(await accounts[1].getAddress())
      ).to.be.equal(harvest, "Vested doesn't match harvest");
      expect(released.toString()).to.be.equal(
        harvest.div(2).toString(),
        "Released balance update is not a half"
      );
      expect(_released.toString()).to.be.equal(
        harvest.toString(),
        "Released doesn't match harvest"
      );
      expect(oilBalanceAfter.toString()).to.be.equal(
        harvest.toString(),
        "Harvest doesn't match the final token balance"
      );
    });
  });

  describe("Staking scenario with no integer amount of wei reward", () => {
    before(async () => {
      accounts = await ethers.getSigners();

      const mocks = await deployMocks(ethers);
      poolToken = mocks.poolToken;
      oilerToken = mocks.oilerToken;

      const Staking = (await ethers.getContractFactory(
        "Staking"
      )) as Staking__factory;

      const deployerAddress = await accounts[0].getAddress();
      const currentNonce = await accounts[0].getTransactionCount();
      const stakingContractAddress = predictContractAddressCREATE(
        deployerAddress,
        currentNonce + 1
      );

      await oilerToken.approve(stakingContractAddress, parseEther("500000"));

      stakingContract = await Staking.deploy(
        oilerToken.address,
        120,
        await accounts[0].getAddress(),
        parseEther("500000"),
        200,
        await accounts[0].getAddress()
      );

      await stakingContract.setPoolToken(poolToken.address);

      await poolToken.transfer(
        await accounts[1].getAddress(),
        parseEther("4700")
      );

      await poolToken.transfer(
        await accounts[2].getAddress(),
        stakeParams.tokenAmount
      );
    });

    step("Player1: Lock 4700 LP tokens for 100 blocks", async () => {
      await poolToken
        .connect(accounts[1])
        .approve(stakingContract.address, constants.MaxUint256);
      await stakingContract
        .connect(accounts[1])
        .lockTokens(parseEther("4700"), 100);
    });

    step("Player2: Lock 1 wei of tokens for 1 block", async () => {
      await poolToken
        .connect(accounts[2])
        .approve(stakingContract.address, constants.MaxUint256);
      await stakingContract.connect(accounts[2]).lockTokens(1, 1);
    });

    step("Wait 100 blocks", async () => {
      for (let i = 0; i < 100; i++) {
        await ethers.provider.send("evm_mine", []);
      }
    });

    step("Unlock tokens", async () => {
      await stakingContract.connect(accounts[1]).unlockTokens();
      await stakingContract.connect(accounts[2]).unlockTokens();
    });

    step("Wait until staking ends", async () => {
      const stakingProgramEndsBlock = await stakingContract.stakingProgramEndsBlock();
      const currentBlock = await accounts[1].provider.getBlockNumber();

      for (
        let i = 0;
        i < stakingProgramEndsBlock.toNumber() - currentBlock;
        i++
      ) {
        await ethers.provider.send("evm_mine", []);
      }
    });

    step("Get rewards", async () => {
      console.log("Player1 RP:", (await stakingContract.rewardPointsEarned(await accounts[1].getAddress())).toString());
      console.log("Player2 RP:", (await stakingContract.rewardPointsEarned(await accounts[2].getAddress())).toString());
      console.log("Total RP:",(await stakingContract.totalRewardPoints()).toString());

      await stakingContract.connect(accounts[1]).getRewards();

      await expect(
        stakingContract.connect(accounts[2]).getRewards()
      ).to.be.revertedWith("You didn't earn any integer amount of wei");

      console.log(
        "Player1 GrantedTokens:",
        (
          await stakingContract.grantedTokens(await accounts[1].getAddress())
        ).toString()
      );
      console.log(
        "Player2 GrantedTokens:",
        (
          await stakingContract.grantedTokens(await accounts[2].getAddress())
        ).toString()
      );
    });

    step("Wait vesting period", async () => {
      const vestingDurationBlocks = await stakingContract.vestingDuration();
      for (let i = 0; i < vestingDurationBlocks.toNumber(); i++) {
        ethers.provider.send("evm_mine", []);
      }
    });

    step("Release Vesting reward", async () => {
      const oilBalanceBefore = await oilerToken.balanceOf(
        await accounts[1].getAddress()
      );
      await stakingContract.connect(accounts[1]).release();

      const oilBalanceAfter = await oilerToken.balanceOf(
        await accounts[1].getAddress()
      );

      const released = oilBalanceAfter.sub(oilBalanceBefore);

      const _released = await stakingContract.releasedTokens(
        await accounts[1].getAddress()
      );

      expect(released.toString()).to.be.equal(_released.toString());

      const lockReward = parseEther("4700").mul(100);
      const bonusLockReward = lockReward.mul(100);
      const harvest = bonusLockReward
        .mul(parseEther("500000"))
        .div(await stakingContract.totalRewardPoints());

      expect(released.toString()).to.be.equal(harvest.toString());

      console.log(
        "OIL left in contract:",
        (await oilerToken.balanceOf(stakingContract.address)).toString(),
        "wei"
      );
    });
  });
});
