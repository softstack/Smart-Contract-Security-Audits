import { parseEther } from "@ethersproject/units";
import { HardhatEthersHelpers } from "@nomiclabs/hardhat-ethers/types";
import { ethers, Signer } from "ethers";

import { IERC20, Staking, Staking__factory } from "../../typechain";
import { predictContractAddressCREATE } from "./predict-create-address";

export async function deployStaking(
  _ethers: typeof ethers & HardhatEthersHelpers,
  deployer: Signer,
  options: {
    oilerToken: IERC20;
    poolToken: IERC20;
  }
): Promise<Staking> {
  const { oilerToken, poolToken } = options;

  const Staking = (await _ethers.getContractFactory(
    "Staking"
  )) as Staking__factory;

  const deployerAddress = await deployer.getAddress();
  const currentNonce = await deployer.getTransactionCount();
  const stakingContractAddress = predictContractAddressCREATE(
    deployerAddress,
    currentNonce + 1
  );

  await oilerToken.approve(stakingContractAddress, parseEther("10000"));

  const staking = await Staking.deploy(
    oilerToken.address,
    100,
    await deployer.getAddress(),
    parseEther("10000"),
    100,
    await deployer.getAddress()
  );

  await staking.setPoolToken(poolToken.address);
  return staking;
}
