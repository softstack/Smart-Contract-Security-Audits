import { HardhatEthersHelpers } from "@nomiclabs/hardhat-ethers/types";
import { constants, ethers } from "ethers";

import {
  IERC20,
  OilerToken__factory,
  PoolToken__factory,
} from "../../typechain";

interface DeployedMocks {
  poolToken: IERC20;
  oilerToken: IERC20;
}

export async function deployMocks(
  _ethers: typeof ethers & HardhatEthersHelpers
): Promise<DeployedMocks> {
  const PoolToken = (await _ethers.getContractFactory(
    "PoolToken"
  )) as PoolToken__factory;
  const OilerToken = (await _ethers.getContractFactory(
    "OilerToken"
  )) as OilerToken__factory;

  const poolToken = await PoolToken.deploy(constants.MaxUint256);
  const oilerToken = await OilerToken.deploy(constants.MaxUint256);

  return {
    poolToken,
    oilerToken,
  };
}
