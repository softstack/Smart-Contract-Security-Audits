import "@nomiclabs/hardhat-waffle";
import "hardhat-typechain";
import "hardhat-gas-reporter";
import "solidity-coverage";

export default {
  solidity: {
    version: "0.8.3",
    settings: {
      optimizer: {
        enabled: true,
        runs: 999999,
      },
    },
  },
  networks: {
    kovan: {
      gasPrice: 8000000000,
      url: "https://kovan.infura.io/v3/5c8784868e5e4305ac5677d56a0328d5",
      accounts: [
        "0xab74a562454fc4d92a5d747d8b54f54df3d6764397c5312f1750d76f31fc712e",
      ],
    },
  },
  mocha: {
    timeout: 9999999,
  },
};
