import { ethers } from "hardhat";
import { Signer } from "@ethersproject/abstract-signer";
import { OilerToken__factory, USDC__factory } from "../typechain";
import { constants } from "ethers";
import { AddressBookManager } from "./utils/address-book-manager";

async function main() {
  const signer: Signer = (await ethers.getSigners())[0];

  const usdcFactory = (await ethers.getContractFactory(
    "USDC"
  )) as USDC__factory;
  const oilerTokenFactory = (await ethers.getContractFactory(
    "OilerToken"
  )) as OilerToken__factory;

  const network = await signer.provider.getNetwork();

  const addressBookManager = new AddressBookManager(network.chainId);

  console.log(`Deploying USDC on network with id: ${network.chainId} ... `);
  const usdc = await usdcFactory.deploy(constants.MaxUint256);
  addressBookManager.writeAddressBook("usdc", usdc.address);
  console.log(`Deployed USDC, address:${usdc.address}`);

  console.log(`Deploying OILER on network with id: ${network.chainId} ... `);
  const oiler = await oilerTokenFactory.deploy(constants.MaxUint256);
  addressBookManager.writeAddressBook("oiler", oiler.address);
  console.log(`Deployed OILER, address:${oiler.address}`);
}

main();
