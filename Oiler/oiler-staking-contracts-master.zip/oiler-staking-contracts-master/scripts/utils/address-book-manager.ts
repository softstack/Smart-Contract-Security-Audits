import { readFileSync, writeFileSync } from "fs";

type AddressBookMember =
  | "usdc"
  | "oiler"
  | "lpToken"
  | "uniswapRouter"
  | "staking";

interface Addresses {
  usdc?: string;
  oiler?: string;
  lpToken?: string;
  uniswapRouter?: string;
  staking?: string;
}

export class AddressBookManager {
  constructor(private readonly chainId: number) {}

  loadAddressBook(): Addresses {
    const addressBookSerialized = readFileSync("addressBook.json", "utf-8");

    if (!addressBookSerialized || !addressBookSerialized.length) return {};

    const addresses = JSON.parse(addressBookSerialized)[
      this.chainId.toString()
    ];
    if (!addresses) return {};
    return addresses;
  }

  writeAddressBook(member: AddressBookMember, address: string) {
    const addressBookSerialized = readFileSync("addressBook.json", "utf-8");

    // ChainId.toString() => addresses
    let addressBook: Record<string, Addresses>;

    if (!addressBookSerialized || !addressBookSerialized.length) {
      addressBook = {};
    } else {
      addressBook = JSON.parse(addressBookSerialized);
    }

    if (!addressBook[this.chainId.toString()]) {
      addressBook[this.chainId.toString()] = {};
    }

    addressBook[this.chainId.toString()][member.toLocaleLowerCase()] = address;

    writeFileSync("addressBook.json", JSON.stringify(addressBook));
  }
}
