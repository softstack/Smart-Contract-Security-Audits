import { ethers } from "hardhat";
import { Signer } from "@ethersproject/abstract-signer";
import { AddressBookManager } from "./utils/address-book-manager";

async function main() {
  console.log("WIP");
  process.exit(0);
  const signer: Signer = (await ethers.getSigners())[0];

  const network = await signer.provider.getNetwork();

  const addressBookManager = new AddressBookManager(network.chainId);
}

main();
