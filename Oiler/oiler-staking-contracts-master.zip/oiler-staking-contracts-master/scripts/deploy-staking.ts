import { ethers } from "hardhat";
import { Signer } from "@ethersproject/abstract-signer";
import { AddressBookManager } from "./utils/address-book-manager";
import { IERC20__factory, Staking__factory } from "../typechain";
import { predictContractAddressCREATE } from "./utils/predict-create-address";
import { parseEther } from "@ethersproject/units";
import { constants } from "ethers";

async function main() {
  const signer: Signer = (await ethers.getSigners())[0];
  const network = await signer.provider.getNetwork();
  const addressBookManager = new AddressBookManager(network.chainId);
  const addresses = addressBookManager.loadAddressBook();

  if (!addresses.oiler) throw new Error(`Please deploy OILER first`);
  if (!addresses.lpToken) throw new Error(`Please deploy LP first`);

  const lpToken = IERC20__factory.connect(addresses.lpToken, signer);
  const oilerToken = IERC20__factory.connect(addresses.oiler, signer);

  const deployerAddress = await signer.getAddress();
  console.log(`Staking deployer: ${deployerAddress}`);

  const currentNonce = await signer.getTransactionCount();
  console.log(`Deployer account nonce: ${await signer.getTransactionCount()}`);

  const stakingContractAddress = predictContractAddressCREATE(
    deployerAddress,
    currentNonce + 1
  );
  console.log(`Expected staking address: ${stakingContractAddress}`);

  console.log(`Approving ...`);
  await oilerToken.approve(stakingContractAddress, constants.MaxUint256);
  console.log(`Approved`);

  const stakingFactory = (await ethers.getContractFactory(
    "Staking"
  )) as Staking__factory;

  console.log(`Deploying staking ...`);
  const staking = await stakingFactory.deploy(
    oilerToken.address,
    1000,
    deployerAddress,
    parseEther("5000"),
    500,
    deployerAddress
  );
  console.log(`Staking deployed`);

  addressBookManager.writeAddressBook("staking", stakingContractAddress);

  console.log(`Setting pool token ...`);
  await staking.setPoolToken(lpToken.address);
  console.log(`Pool token set`);
}
main();
