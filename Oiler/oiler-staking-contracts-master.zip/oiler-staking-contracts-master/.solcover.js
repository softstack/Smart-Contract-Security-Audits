module.exports = {
  skipFiles: [
    "mocks/OilerToken.sol",
    "mocks/PoolToken.sol",
    "mocks/USDC.sol",
    "test/MultipleTxnsProxy.sol",
  ],
};
