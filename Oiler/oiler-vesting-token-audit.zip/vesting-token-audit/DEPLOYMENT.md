# Vesting Deployment Instructions

1. Clone the repo
```
git clone https://github.com/DemerzelSolutions/vesting-token.git
```

2. Change branch to oiler-vesting5-.....
```
git checkout audit
```

3. Install dependencies
```
npm install
```

5. Fill in `advisors.csv` and `private.csv` with correct participants

6. Create and fill in `.env` based on `.env.example`.
The PRIVATE_KEY can be used as a deployer-address if you use a remote network.

7. Load the deployer address with some ETH for gas

8. Run the deployment on a chosen network
```
truffle migrate --reset --network kovan
```

9. Check the console output for pools info. Also the info will be output to
```
ADVISORS_onchain.csv
PRIVATE_onchain.csv
DISTRIBUTION_onchain.csv
```
You can check if everything is correct before proceeding

10. Release the PRIVATE and LIQUIDITY initial funds with preInitialize
```
truffle exec scripts/6_preinitialize.js --network kovan
```

11. Start the vesting timer with Initialize
```
truffle exec scripts/7_initialize.js --network kovan
```