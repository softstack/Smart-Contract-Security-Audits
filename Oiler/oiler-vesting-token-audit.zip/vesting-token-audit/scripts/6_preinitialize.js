const path = require('path')
const assert = require('assert');
const fs = require('fs');
require('dotenv').config({path: path.join(__dirname, '../.env')})
const { BN, fromWei } = web3.utils;
const { loadAddressBook } = require('../utils/addressBookManager')

const OilerToken = artifacts.require('OilerToken');
const Distribution = artifacts.require('Distribution');
const MultipleDistribution = artifacts.require('MultipleDistribution');

function printWei(name, value) {
  console.log(`${name}: ${fromWei(value)} (${value})`)
}

async function printDistribution(distribution) {
  console.log("\n\n Distribution parameters:")
  console.log("owner:", await distribution.owner())
  console.log("Oiler token address:", await distribution.token())
  printWei("supply", await distribution.supply())
  console.log("isInitialized:", await distribution.isInitialized())
  console.log("isPreInitialized:", await distribution.isPreInitialized())
  console.log("preInitializationTimestamp:", String(await distribution.preInitializationTimestamp()))
  console.log("distributionStartTimestamp:", String(await distribution.distributionStartTimestamp()))
}

module.exports = async deployer => {
  try {
    const networkId = await web3.eth.net.getId();
    addressBook = loadAddressBook(networkId);
    addresses = addressBook[networkId];

    // Read and initialize contracts addresses from addressBook
    const privateOfferingDistribution = await MultipleDistribution.at(addresses["privateOfferingDistribution"])
    const distribution = await Distribution.at(addresses["distribution"])
    const token = await OilerToken.at(addresses["token"])
    const liquidityFund = addresses["liquidityFund"]

    await distribution.preInitialize(token.address);

    assert(await distribution.isPreInitialized.call());

    await printDistribution(distribution)

    console.log("\n\n Balances:")
    printWei("PRIVATE POOL", privateOfferingDistribution.address, await token.balanceOf(privateOfferingDistribution.address))
    printWei("LIQUIDITY FUND", liquidityFund, await token.balanceOf(liquidityFund))
    process.exit()
  } catch(e) {
    console.log(e)
  }
};