const path = require('path')
const assert = require('assert');
const fs = require('fs');
require('dotenv').config({path: path.join(__dirname, '../.env')})
const { loadAddressBook } = require('../utils/addressBookManager')

const Distribution = artifacts.require('Distribution');
const OilerToken = artifacts.require('OilerToken');

module.exports = async function() {
  try {
    const networkId = await web3.eth.net.getId();
    addressBook = loadAddressBook(networkId);
    addresses = addressBook[networkId];

    accounts = await web3.eth.personal.getAccounts()

    if (!process.env.LIQUIDITY_FUND_ADDRESS) {
      process.env.LIQUIDITY_FUND_ADDRESS = accounts[1]
    } 

    // Read and initialize MultipleDistribution pools addresses from addressBook
    const distribution = await Distribution.at(addresses["distribution"])
    
    await distribution.initialize();
    assert(await distribution.isInitialized.call());

    console.log("\n\nDISTRIBUTION SUCCESFULLY INITIALIZED!")

    console.log("isInitialized:", await distribution.isInitialized())
    console.log("distributionStartTimestamp:", String(await distribution.distributionStartTimestamp()))

    const token = await OilerToken.at(addresses["token"])
    console.log("LIQUIDITY_FUND_ADDRESS:", process.env.LIQUIDITY_FUND_ADDRESS)
    console.log("Balance of Liquidity wallet:", web3.utils.fromWei(await token.balanceOf(process.env.LIQUIDITY_FUND_ADDRESS)), "OIL")
    process.exit()
  } catch(e) {
    console.log(e)
  }
};