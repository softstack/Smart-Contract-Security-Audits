const path = require('path')
const assert = require('assert');
const fs = require('fs');
require('dotenv').config({path: path.join(__dirname, '../.env')})
const { BN, fromWei } = web3.utils;
const { loadAddressBook } = require('../utils/addressBookManager')

const OilerToken = artifacts.require('OilerToken');
const Distribution = artifacts.require('Distribution');
const MultipleDistribution = artifacts.require('MultipleDistribution');

function printWei(name, value) {
  console.log(`${name}: ${fromWei(value)} (${value})`)
}

async function printMultipleDistribution(multipleDistribution, poolName) {
  console.log("\n\n", poolName, "parameters:")
  console.log("owner:", await multipleDistribution.owner())
  console.log("POOL_NUMBER:", String(await multipleDistribution.POOL_NUMBER()))
  printWei("poolStake", await multipleDistribution.poolStake())
  printWei("sumOfStakes", await multipleDistribution.sumOfStakes())
  console.log("distributionAddress:", await multipleDistribution.distributionAddress())
  console.log("isInitialized:", await multipleDistribution.isInitialized())
  console.log("isFinalized:", await multipleDistribution.isFinalized())
}

async function printDistribution(distribution) {
  console.log("\n\n Distribution parameters:")
  console.log("owner:", await distribution.owner())
  console.log("Oiler token address:", await distribution.token(), "<-- should be 0x0 before preInitialization")
  printWei("supply", await distribution.supply())
  console.log("isInitialized:", await distribution.isInitialized())
  console.log("isPreInitialized:", await distribution.isPreInitialized())
  console.log("preInitializationTimestamp:", String(await distribution.preInitializationTimestamp()))
  console.log("distributionStartTimestamp:", String(await distribution.distributionStartTimestamp()))

  let poolAddress = await Promise.all([1,2,3,4,5,6].map(poolNumber => distribution.poolAddress(poolNumber)))
  let stake = await Promise.all([1,2,3,4,5,6].map(poolNumber => distribution.stake(poolNumber)))
  let tokensLeft = await Promise.all([1,2,3,4,5,6].map(poolNumber => distribution.tokensLeft(poolNumber)))
  let cliff = await Promise.all([1,2,3,4,5,6].map(poolNumber => distribution.cliff(poolNumber)))
  let numberOfInstallments = await Promise.all([1,2,3,4,5,6].map(poolNumber => distribution.numberOfInstallments(poolNumber)))
  let numberOfInstallmentsMade = await Promise.all([1,2,3,4,5,6].map(poolNumber => distribution.numberOfInstallmentsMade(poolNumber)))
  let installmentValue = await Promise.all([1,2,3,4,5,6].map(poolNumber => distribution.installmentValue(poolNumber)))
  let valueAtCliff = await Promise.all([1,2,3,4,5,6].map(poolNumber => distribution.valueAtCliff(poolNumber)))
  let wasValueAtCliffPaid = await Promise.all([1,2,3,4,5,6].map(poolNumber => distribution.wasValueAtCliffPaid(poolNumber)))
  let installmentsEnded = await Promise.all([1,2,3,4,5,6].map(poolNumber => distribution.installmentsEnded(poolNumber)))

  let output = "poolNumber,poolAddress,stake,tokensLeft,cliff,numberOfInstallments,numberOfInstallmentsMade,installmentValue,valueAtCliff,wasValueAtCliffPaid,installmentsEnded"
  for (i=0; i<6; i++) {
    output += "\n" + [i+1,
                  poolAddress[i],
                  stake[i],
                  tokensLeft[i],
                  cliff[i],
                  numberOfInstallments[i],
                  numberOfInstallmentsMade[i],
                  installmentValue[i],
                  valueAtCliff[i],
                  wasValueAtCliffPaid[i],
                  installmentsEnded[i]].map(e => e.toString()).join(",")
  }
  console.log("\n" + output)

  fs.writeFileSync(path.join(__dirname, `../DISTRIBUTION_onchain.csv`), output);
}

async function printToken(token) {
  console.log("\n\n Token parameters:")
  console.log("token address:", addresses["token"])
  console.log("owner:", await token.owner())
  console.log("distributionAddress:", await token.distributionAddress())
  console.log("privateOfferingDistributionAddress:", await token.privateOfferingDistributionAddress())
  console.log("advisorsRewardDistributionAddress:", await token.advisorsRewardDistributionAddress())
  console.log("name:", await token.name())
  console.log("symbol:", await token.symbol())
  console.log("decimals:", String(await token.decimals()))
  printWei("totalSupply", await token.totalSupply())

}

module.exports = async deployer => {
  try {
    const networkId = await web3.eth.net.getId();
    addressBook = loadAddressBook(networkId);
    addresses = addressBook[networkId];

    // Read and initialize contracts addresses from addressBook
    const privateOfferingDistribution = await MultipleDistribution.at(addresses["privateOfferingDistribution"])
    const advisorsRewardDistribution = await MultipleDistribution.at(addresses["advisorsRewardDistribution"])
    const distribution = await Distribution.at(addresses["distribution"])
    const token = await OilerToken.at(addresses["token"])

    await printMultipleDistribution(privateOfferingDistribution, "PRIVATE OFFERING POOL")
    await printMultipleDistribution(advisorsRewardDistribution, "ADVISORS REWARD POOL")
    await printDistribution(distribution)
    await printToken(token)
  } catch(e) {
    console.log(e)
  }
};