const path = require('path')
const assert = require('assert');
const fs = require('fs');
require('dotenv').config({path: path.join(__dirname, '../.env')})
const { loadAddressBook, saveAddressBook } = require('../utils/addressBookManager')

const OilerToken = artifacts.require('OilerToken');
const Distribution = artifacts.require('Distribution');
const MultipleDistribution = artifacts.require('MultipleDistribution');

module.exports = async (deployer, network, accounts) => {
  try {
    await deployer;

    if (!process.env.LIQUIDITY_FUND_ADDRESS) {
      process.env.LIQUIDITY_FUND_ADDRESS = accounts[1]
      console.log("LIQUIDITY_FUND_ADDRESS wasn't set, so we set it as a second TestNet account:", accounts[1])
    } 

    const networkId = await web3.eth.net.getId();
    addressBook = loadAddressBook(networkId);
    addresses = addressBook[networkId];

    const TOKEN_NAME = networkId == 1 ? 'Oiler' : 'Molier';
    const TOKEN_SYMBOL = networkId == 1 ? 'OIL' : 'MOL';

    // Read and initialize MultipleDistribution pools addresses from addressBook
    const privateOfferingDistribution = await MultipleDistribution.at(addresses["privateOfferingDistribution"])
    const advisorsRewardDistribution = await MultipleDistribution.at(addresses["advisorsRewardDistribution"])
    
    const distribution = await deployer.deploy(
      Distribution,
      process.env.ECOSYSTEM_FUND_ADDRESS,
      process.env.TEAM_FUND_ADDRESS,
      privateOfferingDistribution.address,
      advisorsRewardDistribution.address,
      process.env.FOUNDATION_REWARD_ADDRESS,
      process.env.LIQUIDITY_FUND_ADDRESS
    );

    await privateOfferingDistribution.setDistributionAddress(distribution.address);
    await advisorsRewardDistribution.setDistributionAddress(distribution.address);

    assert(await privateOfferingDistribution.distributionAddress.call() == distribution.address);
    assert(await advisorsRewardDistribution.distributionAddress.call() == distribution.address);

    const token = await deployer.deploy(
      OilerToken,
      TOKEN_NAME,
      TOKEN_SYMBOL,
      distribution.address,
      privateOfferingDistribution.address,
      advisorsRewardDistribution.address
    );

    addresses["distribution"] = distribution.address;
    addresses["token"] = token.address;
    addresses["teamFund"] = process.env.TEAM_FUND_ADDRESS;
    addresses["liquidityFund"] = process.env.LIQUIDITY_FUND_ADDRESS;
    addresses["foundationReward"] = process.env.FOUNDATION_REWARD_ADDRESS;
    addresses["ecosystemFund"] = process.env.ECOSYSTEM_FUND_ADDRESS;

    console.log("Saving distribution, token, and funds addresses to addressBook.json:")
    console.log({[networkId]: addresses})
    addressBook[networkId] = addresses
    saveAddressBook(addressBook)
  } catch(e) {
    console.log(e)
  }
  // await distribution.initialize();
  // assert(await distribution.isInitialized.call());
};

// Example:
// ECOSYSTEM_FUND_ADDRESS=0xb28a3211ca4f9bf8058a4199acd95c999c4cdf3b PUBLIC_OFFERING_ADDRESS=0x975fe74ec9cc82afdcd8393ce96abe039c6dba84 FOUNDATION_REWARD_ADDRESS=0xb68d0a5c0566c39e8c2f8e15d8494032fd420da1 LIQUIDITY_FUND_ADDRESS=0x7f29ce8e46d01118888b1692f626d990318018ea INITIAL_STAKE_AMOUNT=220000000000000000000000 PRIVATE_OFFERING_DATA=./example.csv ADVISORS_REWARD_DATA=./example.csv ./node_modules/.bin/truffle migrate --reset
