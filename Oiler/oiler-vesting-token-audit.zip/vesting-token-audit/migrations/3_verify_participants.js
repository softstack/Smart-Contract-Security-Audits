const path = require('path')
const assert = require('assert');
const fs = require('fs');
const papaparse = require('papaparse');
require('dotenv').config({path: path.join(__dirname, '../.env')})
const { BN, fromWei } = web3.utils;
const MultipleDistribution = artifacts.require('MultipleDistribution');
const { loadAddressBook } = require('../utils/addressBookManager')

const deadAddress = "0x0000000000000000000000000000000000000000".toLowerCase()

function lengthWithoutDead(participants) {
  dead = participants.includes(deadAddress) ? 1 : 0
  return participants.length - dead
}

async function verifyParticipants(multipleDistribution, localParticipants, poolName) {
  let onchainParticipantsAddresses = (await multipleDistribution.getParticipants.call()).map(item => item.toLowerCase());

  assert(onchainParticipantsAddresses.length > 0);
  assert(lengthWithoutDead(onchainParticipantsAddresses) == localParticipants.length);

  let onchainParticipantsStakes = await Promise.all(onchainParticipantsAddresses.map(addr => multipleDistribution.participantStake(addr)))

  onchainParticipants = {}
  for (address in onchainParticipantsAddresses) {
    onchainParticipants[onchainParticipantsAddresses[address]] = onchainParticipantsStakes[address].toString()
  }

  for (participant of localParticipants) {
    assert(onchainParticipants[participant.participant.toLowerCase()] == participant.stake)
  }

  if (onchainParticipantsAddresses.includes(deadAddress)) {
    console.log("\n\n<<<<<<<<<<<<<<<<<<<<<<< WARNING >>>>>>>>>>>>>>>>>>>>>>>>>>")
    console.log(`${poolName} pool contains ${fromWei(onchainParticipants[deadAddress])} unstaked tokens`)
  }

  let totalStake = Object.keys(onchainParticipants).reduce((acc, key) => acc.add(new BN(onchainParticipants[key])), new BN(0))

  output = Object.keys(onchainParticipants).map(key => `${key},${onchainParticipants[key]},${fromWei(onchainParticipants[key])}`)
  console.log(`============${poolName}===========`)
  console.log(output)
  console.log(`${poolName} total stake: ${fromWei(totalStake)} (${totalStake.toString()})`)
  fs.writeFileSync(path.join(__dirname, `../${poolName}_onchain.csv`), "participant,stake in wei,stake\n"+output.join('\n')+`\ntotal,${totalStake.toString()},${fromWei(totalStake)}`);
}

module.exports = async deployer => {
  try {
    const networkId = await web3.eth.net.getId();
    addressBook = loadAddressBook(networkId);
    addresses = addressBook[networkId];

    const csvPrivateOfferingData = fs.readFileSync(process.env.PRIVATE_OFFERING_DATA, { encoding: 'utf8' });
    const privateOfferingParticipants = papaparse.parse(csvPrivateOfferingData, { delimiter: ',', header: true, skipEmptyLines: true }).data;

    const csvAdvisorsRewardData = fs.readFileSync(process.env.ADVISORS_REWARD_DATA, { encoding: 'utf8' });
    const advisorsRewardParticipants = papaparse.parse(csvAdvisorsRewardData, { delimiter: ',', header: true, skipEmptyLines: true }).data;

    // Read and initialize MultipleDistribution pools addresses from addressBook
    const privateOfferingDistribution = await MultipleDistribution.at(addresses["privateOfferingDistribution"])
    const advisorsRewardDistribution = await MultipleDistribution.at(addresses["advisorsRewardDistribution"])

    assert(await privateOfferingDistribution.isFinalized.call());
    assert(await advisorsRewardDistribution.isFinalized.call());

    await verifyParticipants(privateOfferingDistribution, privateOfferingParticipants, "PRIVATE");
    await verifyParticipants(advisorsRewardDistribution, advisorsRewardParticipants, "ADVISORS");
  } catch(e) {
    console.log(e)
  }
};