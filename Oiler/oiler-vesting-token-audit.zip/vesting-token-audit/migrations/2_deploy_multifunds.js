const path = require('path')
const assert = require('assert');
const fs = require('fs');
const papaparse = require('papaparse');
require('dotenv').config({path: path.join(__dirname, '../.env')})
const { loadAddressBook, saveAddressBook } = require('../utils/addressBookManager')

const MultipleDistribution = artifacts.require('MultipleDistribution');

module.exports = async deployer => {
  try {
    const networkId = await web3.eth.net.getId();
    addressBook = loadAddressBook(networkId);
    addresses = addressBook[networkId];

    const csvPrivateOfferingData = fs.readFileSync(process.env.PRIVATE_OFFERING_DATA, { encoding: 'utf8' });
    const privateOfferingData = papaparse.parse(csvPrivateOfferingData, { delimiter: ',', header: true, skipEmptyLines: true }).data;
    const privateOfferingParticipants = privateOfferingData.map(item => item.participant);
    const privateOfferingParticipantsStakes = privateOfferingData.map(item => item.stake);

    const csvAdvisorsRewardData = fs.readFileSync(process.env.ADVISORS_REWARD_DATA, { encoding: 'utf8' });
    const advisorsRewardData = papaparse.parse(csvAdvisorsRewardData, { delimiter: ',', header: true, skipEmptyLines: true }).data;
    const advisorsRewardParticipants = advisorsRewardData.map(item => item.participant);
    const advisorsRewardParticipantsStakes = advisorsRewardData.map(item => item.stake);

    await deployer;

    // Deploy private offering distribution contract.
    const privateOfferingDistribution = await deployer.deploy(MultipleDistribution, 3);
    await privateOfferingDistribution.addParticipants(
      privateOfferingParticipants,
      privateOfferingParticipantsStakes
    );
    await privateOfferingDistribution.finalizeParticipants();

    // Deploy advisors rewards distribution contract.
    const advisorsRewardDistribution = await deployer.deploy(MultipleDistribution, 4);
    await advisorsRewardDistribution.addParticipants(
      advisorsRewardParticipants,
      advisorsRewardParticipantsStakes
    );
    await advisorsRewardDistribution.finalizeParticipants();

    assert((await privateOfferingDistribution.getParticipants.call()).length > 0);
    assert((await advisorsRewardDistribution.getParticipants.call()).length > 0);
    assert(await privateOfferingDistribution.isFinalized.call());
    assert(await advisorsRewardDistribution.isFinalized.call());

    addresses["privateOfferingDistribution"] = privateOfferingDistribution.address;
    addresses["advisorsRewardDistribution"] = advisorsRewardDistribution.address;

    console.log("Saving multipleDistribution funds addresses to addressBook.json:")
    console.log({[networkId]: addresses})
    addressBook[networkId] = addresses
    saveAddressBook(addressBook)
  } catch(e) {
    console.log(e)
  }
};