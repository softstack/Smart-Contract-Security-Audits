const path = require('path')
const { loadEnv } = require("./utils/loadEnv");
const truffleNetwork = loadEnv();

console.log("preloaded", truffleNetwork);

let networks = {}

let mocha = {
  fullTrace: true,
  allowUncaught: true,
}

const isAlchemy = process.env.ALCHEMY_API_KEY !== undefined;
const isInfura = process.env.INFURA_API_KEY !== undefined;
const apiKey = process.env.ALCHEMY_API_KEY || process.env.INFURA_API_KEY;
const fallbackUrl = process.env.URL;

const url = isAlchemy
  ? `https://eth-${truffleNetwork}.alchemyapi.io/v2/${apiKey}`
  : isInfura
  ? `https://${truffleNetwork}.infura.io/v3/${apiKey}`
  : fallbackUrl !== undefined
  ? fallbackUrl
  : "http://localhost:8545";

const auth = process.env.AUTH && (process.env.AUTH == "true" || process.env.AUTH == "TRUE");

require('dotenv').config({path: path.join(__dirname, './.env')})

const HDWalletProvider = require("@truffle/hdwallet-provider");

if (process.env.PRIVATE_KEY || auth) {
  if (process.env.PRIVATE_KEY) {
    provider = new HDWalletProvider({
      privateKeys: [process.env.PRIVATE_KEY],
      providerOrUrl: url
    })
  } else {
    provider = new HDWalletProvider({
      providerOrUrl: url,
      numberOfAddresses: 1
    })
  }
  networks[truffleNetwork] = { 
    provider,
    reporterUrl: url
  }
} else {
  host = /http:\/\/(.*):(\d*)/gm.exec(process.env.URL)[1]
  port = /http:\/\/(.*):(\d*)/gm.exec(process.env.URL)[2]

  networks[truffleNetwork] = { 
    host,
    port,
    reporterUrl: url,
  }

  mocha = {
    reporter: 'eth-gas-reporter',
    reporterOptions: { url },
    fullTrace: true,
    allowUncaught: true,
  }
}

const networkGasLimit = {
  mainnet: 12000000,
  ropsten: 8000000,
  rinkeby: 10000000,
  kovan: 12000000,
  spaceneth: 12000000,
  ganache: 12000000,
  hardhat: 12000000
}

const networkIds = {
  mainnet: 1,
  ropsten: 3,
  rinkeby: 4,
  kovan: 42,
  spaceneth: 99,
  ganache: 1337,
  hardhat: 31337
}

if (process.env.NETWORK_ID) {
  networks[truffleNetwork].network_id = process.env.NETWORK_ID
} else {
  networks[truffleNetwork].network_id = networkIds[truffleNetwork]
}

if (process.env.GAS_PRICE) {
  networks[truffleNetwork].gasPrice = process.env.GAS_PRICE
}

networks[truffleNetwork].gas = networkGasLimit[truffleNetwork]
networks[truffleNetwork].skipDryRun = true

console.log("networks:", networks)
console.log("mocha:", mocha)

module.exports = {
  networks,
  mocha,

  // Configure your compilers
  compilers: {
    solc: {
      version: "0.5.12",    // Fetch exact version from solc-bin (default: truffle's version)
      settings: {
        optimizer: {
          enabled: true,
          runs: 999999   // Optimize for how many times you intend to run the code
        },
        evmVersion: "istanbul" // Default: "petersburg"
      }
    }
  }
}
