const { expect } = require('chai');

const Distribution = artifacts.require('DistributionMock');
const MultipleDistributionMock = artifacts.require('MultipleDistributionMock');
const OilerToken = artifacts.require('OilerTokenMock');

const { BN, toBN, fromWei } = web3.utils;

require('chai')
    .use(require('chai-as-promised'))
    .use(require('chai-bn')(BN))
    .should();


contract("Multiple distribution: withdrawals test", async accounts => {
    const {
        TOKEN_NAME,
        TOKEN_SYMBOL,
        EMPTY_ADDRESS,
        ECOSYSTEM_FUND,
        TEAM_FUND,
        PRIVATE_OFFERING,
        ADVISORS_REWARD,
        FOUNDATION_REWARD,
        LIQUIDITY_FUND,
        DAY_IN_SECONDS,
        owner,
        address,
        SUPPLY,
        privateOfferingParticipants,
        privateOfferingParticipantsStakes,
        stake
    } = require('./utils/constants')(accounts);

    let privateOfferingDistribution;
    let advisorsRewardDistribution;
    let liquidityFundDistribution;

    let distribution;
    let token;

    function createDistribution(privateOfferingDistribution, advisorsRewardDistribution) {
        return Distribution.new(
            address[ECOSYSTEM_FUND],
            address[TEAM_FUND],
            privateOfferingDistribution.address,
            advisorsRewardDistribution.address,
            address[FOUNDATION_REWARD],
            address[LIQUIDITY_FUND],
        );
    }

    describe("Private offering withdraw", async () => {
        beforeEach(async () => {
            const participants = [accounts[1], accounts[2]];
            const stakes = privateOfferingParticipantsStakes;


            privateOfferingDistribution = await MultipleDistributionMock.new(PRIVATE_OFFERING);
            advisorsRewardDistribution = await MultipleDistributionMock.new(ADVISORS_REWARD);

            distribution = await createDistribution(privateOfferingDistribution, advisorsRewardDistribution);

            await privateOfferingDistribution.setDistributionAddress(distribution.address);
            await privateOfferingDistribution.addParticipants(participants, stakes);
            await privateOfferingDistribution.finalizeParticipants();

            await advisorsRewardDistribution.setDistributionAddress(distribution.address);
            await advisorsRewardDistribution.addParticipants(participants, stakes)
            await advisorsRewardDistribution.finalizeParticipants();

            token = await OilerToken.new(
                TOKEN_NAME,
                TOKEN_SYMBOL,
                distribution.address,
                privateOfferingDistribution.address,
                advisorsRewardDistribution.address
            );
        
            await distribution.preInitialize(token.address);
            await distribution.initialize();
        });

        it("Should revert on privateOfferingDistribution withdraw attempt", async () => {
            const cliff = await distribution.cliff(3);
            const distributionStartTimestamp = await distribution.distributionStartTimestamp();

            let nextTimestamp = distributionStartTimestamp.add(cliff).add(DAY_IN_SECONDS.mul(toBN('1')));
            await distribution.setTimestamp(nextTimestamp);

            await privateOfferingDistribution.withdraw({from: accounts[1]}).should.be.rejectedWith("Private Offering withdrawals are locked during LBP event");
        });

        it("Should check liquidity fund OIL tokens balance", async () => {
            const liquidityFundAddress = await distribution.poolAddress(6);
            const liquidityFundBalance = await token.balanceOf(liquidityFundAddress);

            expect(liquidityFundBalance.toString()).to.be.equal(stake['6'].toString());
        });

        it("PrivateOfferingDistribution should be able to withdraw after 5 days", async () => {
            const cliff = await distribution.cliff(3);
            const distributionStartTimestamp = await distribution.distributionStartTimestamp();

            let nextTimestamp = distributionStartTimestamp.add(cliff).add(DAY_IN_SECONDS.mul(toBN('5')));
            await privateOfferingDistribution.setTimestamp(nextTimestamp);

            await privateOfferingDistribution.withdraw({from: accounts[1]}).should.be.fulfilled;
        });
    });

    describe("Withdrawal before initializing", async () => {
        beforeEach(async () => {
            const participants = [accounts[1], accounts[2]];
            const stakes = privateOfferingParticipantsStakes;

            privateOfferingDistribution = await MultipleDistributionMock.new(PRIVATE_OFFERING);
            advisorsRewardDistribution = await MultipleDistributionMock.new(ADVISORS_REWARD);

            distribution = await createDistribution(privateOfferingDistribution, advisorsRewardDistribution);

            await privateOfferingDistribution.setDistributionAddress(distribution.address);
            await privateOfferingDistribution.addParticipants(participants, stakes);
            await privateOfferingDistribution.finalizeParticipants();

            await advisorsRewardDistribution.setDistributionAddress(distribution.address);
            await advisorsRewardDistribution.addParticipants(participants, stakes)
            await advisorsRewardDistribution.finalizeParticipants();

            token = await OilerToken.new(
                TOKEN_NAME,
                TOKEN_SYMBOL,
                distribution.address,
                privateOfferingDistribution.address,
                advisorsRewardDistribution.address
            );
        
            await distribution.preInitialize(token.address);
        });

        it("Should revert on privateOfferingDistribution withdraw attempt when not initialized", async () => {
            await privateOfferingDistribution.withdraw({from: accounts[1]}).should.be.rejectedWith("Distribution should be initialized to enable withdrawals");
        });

        it("Liquidity pool should already have balance before initialization", async () => {
            const liquidityFundAddress = await distribution.poolAddress(6);
            const liquidityFundBalance = await token.balanceOf(liquidityFundAddress);
            
            console.log("Liquidity Fund balance:", fromWei(liquidityFundBalance))
            expect(liquidityFundBalance.toString()).to.be.equal(stake['6'].toString());
        });
    });
});