
const { BN, toWei } = web3.utils;

const ERROR_MSG = 'VM Exception while processing transaction: revert';

const TOKEN_NAME = 'OilerToken';
const TOKEN_SYMBOL = 'OILER';

const EMPTY_ADDRESS = '0x0000000000000000000000000000000000000000';
const WEEK_IN_SECONDS = new BN(604800);
const DAY_IN_SECONDS = new BN(86400);

const ECOSYSTEM_FUND = 1;
const TEAM_FUND = 2;
const PRIVATE_OFFERING = 3;
const ADVISORS_REWARD = 4;
const FOUNDATION_REWARD = 5;
const LIQUIDITY_FUND = 6;

const INITIAL_STAKE_AMOUNT = 0;

function getPoolAddresses(accounts) {
    return {
        [ECOSYSTEM_FUND]: accounts[1],
        [TEAM_FUND]: accounts[2],
        [FOUNDATION_REWARD]: accounts[3],
        [LIQUIDITY_FUND]: accounts[4],
    };
}

const stake = {
    [ECOSYSTEM_FUND]: new BN(toWei('20000000')),
    [TEAM_FUND]: new BN(toWei('12500000')),
    [PRIVATE_OFFERING]: new BN(toWei('13621102')),
    [ADVISORS_REWARD]: new BN(toWei('5351667')),
    [FOUNDATION_REWARD]: new BN(toWei('38527231')),
    [LIQUIDITY_FUND]: new BN(toWei('10000000')),
};

const cliff = {
    [ECOSYSTEM_FUND]: new BN(0),
    [TEAM_FUND]: new BN(270).mul(DAY_IN_SECONDS),
    [PRIVATE_OFFERING]: new BN(44).mul(DAY_IN_SECONDS),
    [ADVISORS_REWARD]: new BN(90).mul(DAY_IN_SECONDS),
    [FOUNDATION_REWARD]: new BN(360).mul(DAY_IN_SECONDS),
};

const percentAtCliff = {
    [ECOSYSTEM_FUND]: 7.5,
    [TEAM_FUND]: 10,
    [PRIVATE_OFFERING]: 0,
    [ADVISORS_REWARD]: 20,
    [FOUNDATION_REWARD]: 20,
};

const numberOfInstallments = {
    [ECOSYSTEM_FUND]: new BN(810),
    [TEAM_FUND]: new BN(720),
    [PRIVATE_OFFERING]: new BN(270),
    [ADVISORS_REWARD]: new BN(270),
    [FOUNDATION_REWARD]: new BN(360),
};

const prerelease = {
    [PRIVATE_OFFERING]: 25,
};

const SUPPLY = new BN(toWei('100000000'));

function getPrivateOfferingData(accounts) {
    return {
        privateOfferingParticipants: [accounts[6], accounts[7]],
        privateOfferingParticipantsStakes: [new BN(toWei('100000')), new BN(toWei('1800000'))],
    };
}

function getAdvisorsRewardData(accounts) {
    return {
        advisorsRewardParticipants: [accounts[6], accounts[7]],
        advisorsRewardParticipantsStakes: [new BN(toWei('600000')), new BN(toWei('50000'))],
    };
}

module.exports = accounts => ({
    ERROR_MSG,
    TOKEN_NAME,
    TOKEN_SYMBOL,
    EMPTY_ADDRESS,
    WEEK_IN_SECONDS,
    DAY_IN_SECONDS,
    ECOSYSTEM_FUND,
    TEAM_FUND,
    PRIVATE_OFFERING,
    ADVISORS_REWARD,
    FOUNDATION_REWARD,
    LIQUIDITY_FUND,
    INITIAL_STAKE_AMOUNT,
    owner: accounts[0],
    address: getPoolAddresses(accounts),
    stake,
    cliff,
    percentAtCliff,
    numberOfInstallments,
    prerelease,
    SUPPLY,
    ...getPrivateOfferingData(accounts),
    ...getAdvisorsRewardData(accounts),
});
