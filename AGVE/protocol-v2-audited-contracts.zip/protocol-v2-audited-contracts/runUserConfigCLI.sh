certoraRun specs/harness/UserConfigurationHarness.sol  --solc solc6.8 --verify UserConfigurationHarness:specs/UserConfiguration.spec --settings -useBitVectorTheory --staging master
