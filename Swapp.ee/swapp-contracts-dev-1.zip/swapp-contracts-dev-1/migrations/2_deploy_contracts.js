const fs = require('fs');

const LiquidityGuard = artifacts.require('./LiquidityGuard/LiquidityGuard');
const LiquidityTransformer = artifacts.require('./LiquidityTransformer/LiquidityTransformer');
const SwappToken = artifacts.require('./Swapp/SwappToken');
const Staking = artifacts.require('./Staking/Staking');
const YieldFarm = artifacts.require('./Staking/YieldFarm');
const YieldFarmLP = artifacts.require('./Staking/YieldFarmLP');

function saveDeployedAddress(contractNames, addresses) {
  const path = "./test/address.json";

  let data = {};

  for (let i = 0; i < contractNames.length; i++) {
    data[contractNames[i]] = addresses[i];
  }

  fs.writeFile(path, JSON.stringify(data), (err) => {
    if (err) throw err;
    console.log('Contract addresses written to file');
  });  
};

module.exports = async function (deployer) {
  await deployer.deploy(LiquidityGuard);
  await deployer.deploy(LiquidityTransformer);
  await deployer.deploy(SwappToken);
  await deployer.deploy(Staking);
  await deployer.deploy(YieldFarm, SwappToken.address, Staking.address);
  await deployer.deploy(YieldFarmLP, SwappToken.address, Staking.address);

  const contractNames = [
    'LiquidityGuard',
    'LiquidityTransformer',
    'SwappToken',
    'Staking',
    'YieldFarm',
    'YieldFarmLP'
  ];

  const addresses = [
    LiquidityGuard.address,
    LiquidityTransformer.address,
    SwappToken.address,
    Staking.address,
    YieldFarm.address,
    YieldFarmLP.address
  ]
  saveDeployedAddress(contractNames, addresses);
};
