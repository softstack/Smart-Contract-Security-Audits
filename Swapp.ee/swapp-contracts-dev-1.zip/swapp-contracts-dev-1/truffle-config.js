require('dotenv').config()

const HDWalletProvider = require("truffle-hdwallet-provider");

module.exports = {
  networks: {
    development: {
     host: "127.0.0.1",     // Localhost (default: none)
     port: 8545,            // Standard Ethereum port (default: none)
     network_id: "*",       // Any network (default: none)
     // gas: 6700000,           // Gas sent with each transaction (default: ~6700000)
     gasLimit: 6721975,
     gasPrice: 20000000000,  // 20 gwei (in wei) (default: 100 gwei)

    },
    kovan: {
      // provider: () => new HDWalletProvider(process.env.MNEMONIC, `https://kovan.infura.io/v3/` + process.env.PROJECTID),
      provider: () => new HDWalletProvider(process.env.MNEMONIC, `wss://kovan.infura.io/ws/v3/` + process.env.PROJECTID),
      network_id: 42,       // Ropsten's id
      gas: 5500000,        // Ropsten has a lower block limit than mainnet
      confirmations: 2,    // # of confs to wait between deployments. (default: 0)
      networkCheckTimeout: 60000000,
      timeoutBlocks: 20000,  // # of blocks before a deployment times out  (minimum/default: 50)
      skipDryRun: true,     // Skip dry run before migrations? (default: false for public nets )
      websockets: true
    },
  },

  mocha: {
    // timeout: 100000
  },

  compilers: {
    solc: {
      version: "0.7.6",    // Fetch exact version from solc-bin (default: truffle's version)
      // docker: true,        // Use "0.5.1" you've installed locally with docker (default: false)
      settings: {          // See the solidity docs for advice about optimization and evmVersion
       optimizer: {
         enabled: true,
         runs: 1
       },
      //  evmVersion: "byzantium"
      }
    },
  },
  plugins: [
    'truffle-plugin-verify'
  ],
  api_keys: {
    etherscan: process.env.ETHERSCAN_APIKEY
  }
};
