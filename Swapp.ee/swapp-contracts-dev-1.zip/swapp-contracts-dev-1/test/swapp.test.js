const SwappToken = artifacts.require("SwappToken");
const LiquidityGuard = artifacts.require("LiquidityGuard");
const catchRevert = require("./exceptionsHelpers.js").catchRevert;

const { advanceTimeAndBlock } = require("./utils");

const BN = web3.utils.BN;

// TESTING PARAMETERS
const SECONDS_IN_DAY = 10;
const ZERO_ADDRESS = "0x0000000000000000000000000000000000000000";
const SWAPP_TOKEN_OWNER = "0x6bDcb2F88fDc200eAa21368E2c506dCd97C591d8";

const getLastEvent = async (eventName, instance) => {
    const events = await instance.getPastEvents(eventName, {
        fromBlock: 0,
        toBlock: "latest",
    });
    return events.pop().returnValues;
};

contract("SwappToken", ([owner, user1, user2, random]) => {
    let token;
    let launchTime;
    let liquidityGuard;

    before(async () => {
        liquidityGuard = await LiquidityGuard.new();
        token = await SwappToken.new(liquidityGuard.address);
    });

    describe("Initial Variables", () => {
        it("correct token name", async () => {
            const name = await token.name();
            assert.equal(name, "Swapp Token");
        });

        it("correct token symbol", async () => {
            const symbol = await token.symbol();
            assert.equal(symbol, "SWAPP");
        });

        it("correct token decimals", async () => {
            const decimals = await token.decimals();
            assert.equal(decimals, 18);
        });

        it("correct initial supply", async () => {
            const supply = await token.supply();
            assert.equal(supply, 10000 * 10 ** 18);
        });
    });

    describe("Timing", () => {
        beforeEach(async () => {
            liquidityGuard = await LiquidityGuard.new();
            token = await SwappToken.new(liquidityGuard.address);

            const blockInfo = await web3.eth.getBlock("latest");
            launchTime = blockInfo.timestamp;
        });

        it("correct currentSwappDay", async () => {
            await advanceTimeAndBlock(10);

            const currentSwappDay = await token.currentSwappDay();
            const blockInfo = await web3.eth.getBlock("latest");
            assert.equal(
                currentSwappDay.toNumber(),
                Math.floor((blockInfo.timestamp - launchTime) / SECONDS_IN_DAY)
            );
        });

        it("correct nextSwappDay", async () => {
            await advanceTimeAndBlock(10);

            const _nextSwappDay = await token.nextSwappDay();
            const blockInfo = await web3.eth.getBlock("latest");
            assert.equal(
                _nextSwappDay,
                Math.floor((blockInfo.timestamp - launchTime) / SECONDS_IN_DAY) + 1
            );
        });

        it("correct swappDayFromStamp", async () => {
            await advanceTimeAndBlock(70);

            const blockInfo = await web3.eth.getBlock("latest");

            const swappDayFromStamp = await token.swappDayFromStamp(
                blockInfo.timestamp
            );
            assert.equal(
                swappDayFromStamp,
                Math.floor((blockInfo.timestamp - launchTime) / SECONDS_IN_DAY)
            );
        });
    });

    describe("Staking: Start", () => {
        beforeEach(async () => {
            liquidityGuard = await LiquidityGuard.new();
            token = await SwappToken.new(liquidityGuard.address);

            const blockInfo = await web3.eth.getBlock("latest");
            launchTime = blockInfo.timestamp;
        });

        it("should be able to start stake", async () => {
            // send 2 ether to SWAPP_TOKEN_OWNER for gas
            await web3.eth.sendTransaction({ from: user1, to: SWAPP_TOKEN_OWNER, value: '2000000000000000000' });
            await token.transfer(user1, 300, { from: SWAPP_TOKEN_OWNER });
            
            await token.createStake(200, 1, ZERO_ADDRESS, { from: user1 });
        });

        it("should burned staked tokens", async () => {
            await token.createStake(200, 1, ZERO_ADDRESS, { from: user1 });

            const { from, to, value } = await getLastEvent("Transfer", token);
            assert.equal(from, user1);
            assert.equal(to, ZERO_ADDRESS); // Tokens Burned
            assert.equal(value, 200);
        });

        it("correct stake details", async () => {
            // More than 1 day passes
            await advanceTimeAndBlock(SECONDS_IN_DAY + 1);

            await token.createStake(200, 1, ZERO_ADDRESS, { from: user1 });

            const stakeId = await token.myLatestStakeID({ from: user1 });
            const {
                stakesShares,
                stakedAmount,
                rewardAmount,
                openedTime,
                closedTime,
                startDay,
                finalDay,
                closeDay,
                lockDays,
                isActive,
            } = await token.Stakes(user1, stakeId);

            const blockInfo = await web3.eth.getBlock("latest");

            const nextDay = Math.floor((blockInfo.timestamp - launchTime) / SECONDS_IN_DAY) + 1;

            const { shareRate } = await token.globals();

            assert.equal(stakesShares, 200 * shareRate);
            assert.equal(stakedAmount, 200);
            assert.equal(rewardAmount, 0);
            assert.equal(openedTime, blockInfo.timestamp);
            assert.equal(closedTime, 0);
            assert.equal(startDay, nextDay); // we are on swapp day 1, so starts next day
            assert.equal(finalDay, nextDay + 1); // startDay + lockedDays
            assert.equal(closeDay, 0);
            assert.equal(lockDays, 1);
            assert.equal(isActive, true);
        });

        it("correct stakeStart event triggered", async () => {
            // More than 1 day passes
            await advanceTimeAndBlock(SECONDS_IN_DAY + 1);

            await token.transfer(user1, 100, { from: SWAPP_TOKEN_OWNER });
            await token.createStake(100, 1, ZERO_ADDRESS, { from: user1 });

            const {
                stakerAddress,
                stakedAmount,
                stakesShares,
                openedTime,
                startDay,
                lockDays,
            } = await getLastEvent("stakeStart", token);

            const blockInfo = await web3.eth.getBlock("latest");
            const nextDay = Math.floor((blockInfo.timestamp - launchTime) / SECONDS_IN_DAY) + 1;

            const { shareRate } = await token.globals();

            assert.equal(stakerAddress, user1);
            assert.equal(stakedAmount, 100);
            assert.equal(stakesShares, 100 * shareRate);
            assert.equal(startDay, nextDay);
            assert.equal(lockDays, 1);
            assert.equal(openedTime, blockInfo.timestamp);
        });
    });

    describe("Staking: End", () => {
        beforeEach(async () => {
            liquidityGuard = await LiquidityGuard.new();
            token = await SwappToken.new(liquidityGuard.address);

            const blockInfo = await web3.eth.getBlock("latest");
            launchTime = blockInfo.timestamp;

            // More than 1 day passes
            await advanceTimeAndBlock(SECONDS_IN_DAY + 1);
        });

        it("should get correct stake details after ending", async () => {
            // Stake Starts
            await token.transfer(user1, 100);
            await token.createStake(100, 1, ZERO_ADDRESS, { from: user1 });

            stakeId = await token.myLatestStakeID({ from: user1 });

            const startBlockInfo = await web3.eth.getBlock("latest");

            // More Time passes (10 days)
            await advanceTimeAndBlock(10 * SECONDS_IN_DAY);

            // Stake ends
            await token.endStake(stakeId, { from: user1 });

            const endBlockInfo = await web3.eth.getBlock("latest");
            const daysPassed = Math.floor(
                (endBlockInfo.timestamp - launchTime) / SECONDS_IN_DAY
            );

            const {
                stakedAmount,
                stakesShares,
                rewardAmount,
                openedTime,
                closedTime,
                startDay,
                finalDay,
                closeDay,
                lockDays,
                isActive,
            } = await token.Stakes(user1, stakeId);

            let rewards = new BN("0");
            for (let i = startDay; i < finalDay; i++) {
                const { totalShares, inflationAmount } = await token.snapshots(i);
                const scheduledToEnd = await token.scheduledToEnd(i);
                const totalPenalties = await token.totalPenalties(i);

                rewards = rewards
                    .add(
                        new BN("1000").div(new BN(totalShares).sub(new BN(scheduledToEnd)))
                    )
                    .mul(new BN(inflationAmount).add(new BN(totalPenalties)));
            }

            assert.equal(stakedAmount, 100);
            assert.equal(stakesShares, 1000);
            assert.equal(rewardAmount.toString(), rewards.toString());
            assert.equal(openedTime, startBlockInfo.timestamp);
            assert.equal(closedTime, endBlockInfo.timestamp);
            assert.equal(startDay, 2); // started on swapp day 2
            assert.equal(finalDay, 3); // selected 1 day
            assert.equal(closeDay, daysPassed);
            assert.equal(lockDays, 1);
            assert.equal(isActive, false);
        });

        it("should get correct stakeEnd event", async () => {
            // Stake Starts
            await token.transfer(user1, 100);
            await token.createStake(100, 1, ZERO_ADDRESS, { from: user1 });
            stakeId = await token.myLatestStakeID({ from: user1 });

            // More Time passes (10 days)
            await advanceTimeAndBlock(10 * SECONDS_IN_DAY);

            // Stake ends
            await token.endStake(stakeId, { from: user1 });

            const endBlockInfo = await web3.eth.getBlock("latest");
            const daysPassed = Math.floor(
                (endBlockInfo.timestamp - launchTime) / SECONDS_IN_DAY
            );

            const {
                stakerAddress,
                stakedAmount,
                closeDay,
                closedTime,
            } = await getLastEvent("stakeEnd", token);

            assert.equal(stakerAddress, user1);
            assert.equal(stakedAmount, 100);
            assert.equal(closedTime, endBlockInfo.timestamp);
            assert.equal(closeDay, daysPassed);
        });

        it("should get correct amount of tokens after ending stake", async () => {
            const STAKE_AMOUNT = 100;

            // Stake Starts
            await token.transfer(user1, STAKE_AMOUNT);
            await token.createStake(STAKE_AMOUNT, 1, ZERO_ADDRESS, { from: user1 });
            stakeId = await token.myLatestStakeID({ from: user1 });

            // More Time passes (10 days)
            await advanceTimeAndBlock(10 * SECONDS_IN_DAY);

            // Stake ends
            await token.endStake(stakeId, { from: user1 });

            const { startDay, finalDay } = await token.Stakes(user1, stakeId);

            let rewards = new BN("0");
            for (let i = startDay; i < finalDay; i++) {
                const { totalShares, inflationAmount } = await token.snapshots(i);
                const scheduledToEnd = await token.scheduledToEnd(i);
                const totalPenalties = await token.totalPenalties(i);

                rewards = rewards
                    .add(
                        new BN(String(STAKE_AMOUNT * 10)).div(
                            new BN(totalShares).sub(new BN(scheduledToEnd))
                        )
                    )
                    .mul(new BN(inflationAmount).add(new BN(totalPenalties)));
            }

            const { from, to, value } = await getLastEvent("Transfer", token);

            assert.equal(from, ZERO_ADDRESS);
            assert.equal(to, user1);
            assert.equal(value, STAKE_AMOUNT); //  Latest event sends initial amount staked

            const balance = await token.balanceOf(user1);
            assert.equal(
                balance.toString(),
                String(new BN(String(STAKE_AMOUNT)).add(new BN(rewards)))
            );
        });

        it("should get correct immature stake details", async () => {
            // Parameters
            const LOCK_PERIOD = 15;
            const STAKED_AMOUNT = 100;

            const endBlockInfo = await web3.eth.getBlock("latest");
            const daysPassed = Math.floor(
                (endBlockInfo.timestamp - launchTime) / SECONDS_IN_DAY
            );

            const initialDay = daysPassed;
            const startDay = daysPassed + 1;

            // Stake Starts
            await token.transfer(user1, STAKED_AMOUNT);
            await token.createStake(STAKED_AMOUNT, LOCK_PERIOD, ZERO_ADDRESS, { from: user1 });

            const DAYS_PASSED = 5;
            await advanceTimeAndBlock(DAYS_PASSED * SECONDS_IN_DAY);
            
            await token.manualDailySnapshot({ from: user1 });

            const latestStake = await token.checkMyLatestStake({ from: user1 }); 

            assert.equal(latestStake.startDay.toNumber(), startDay);
            assert.equal(latestStake.lockDays, LOCK_PERIOD);
            assert.equal(latestStake.finalDay, LOCK_PERIOD + startDay);
            assert.equal(latestStake.currentDay.toNumber(), initialDay + DAYS_PASSED);
            assert.equal(latestStake.daysLeft.toNumber(),  initialDay + LOCK_PERIOD -  DAYS_PASSED);
            assert.equal(latestStake.isActive, true);
            assert.equal(latestStake.isMature, false);
        });

        it("should be able to end stake with penalty", async () => {
            // Parameters
            const LOCK_PERIOD = 15;
            const STAKE_AMOUNT = 100;

            const _endBlockInfo = await web3.eth.getBlock("latest");
            const stakeStartDay = Math.floor(
                (_endBlockInfo.timestamp - launchTime) / SECONDS_IN_DAY
            );

            // const initialDay = _daysPassed;
            // const startDay = _daysPassed + 1;

            // Stake Starts
            await token.transfer(user1, STAKE_AMOUNT);
            await token.createStake(STAKE_AMOUNT, LOCK_PERIOD, ZERO_ADDRESS, { from: user1 });
            stakeId = await token.myLatestStakeID({ from: user1 });

            // More Time passes 
            const DAYS_PASSED = 3;
            await advanceTimeAndBlock(DAYS_PASSED * SECONDS_IN_DAY);


            // Stake ends
            await token.endStake(stakeId, { from: user1 });

            await token.manualDailySnapshot({ from: user1 });


            const endBlockInfo = await web3.eth.getBlock("latest");
            const currentSwappDay = Math.floor(
                (endBlockInfo.timestamp - launchTime) / SECONDS_IN_DAY
            );

            // const { startDay, finalDay } = await token.Stakes(user1, stakeId);

            // console.log(Number(startDay), Number(finalDay))


            let rewards = new BN("0");
            for (let i = stakeStartDay +1 ; i < currentSwappDay; i++) {
                const { totalShares, inflationAmount } = await token.snapshots(i);
                const scheduledToEnd = await token.scheduledToEnd(i);
                const totalPenalties = await token.totalPenalties(i);

                console.log(totalShares.toString(), inflationAmount.toString())
                console.log(scheduledToEnd.toString(), totalPenalties.toString())

                rewards = rewards
                    .add(
                        new BN(String(STAKE_AMOUNT * 10)).div(
                            new BN(totalShares).sub(new BN(scheduledToEnd))
                        )
                    )
                    .mul(new BN(inflationAmount).add(new BN(totalPenalties)));
            }

            const {
                stakerAddress,
                stakedAmount,
                rewardAmount,
                closeDay,
                closedTime,
            } = await getLastEvent("stakeEnd", token);

            const penalty =
                (STAKE_AMOUNT *
                    (100 + (800 * (DAYS_PASSED + LOCK_PERIOD - currentSwappDay)) / LOCK_PERIOD)) /
                1000;

            assert.equal(stakerAddress, user1);
            assert.equal(stakedAmount, STAKE_AMOUNT);
            // assert.equal(rewardAmount, rewards.toString()); // no penalty reward calculation yet
            assert.equal(closedTime, endBlockInfo.timestamp);
            assert.equal(closeDay, currentSwappDay);

            const balance = await token.balanceOf(user1);
            // assert.equal(balance, Math.floor(STAKE_AMOUNT - penalty)); // Gets back staked amount - penalty
        });

        it("should revert if user tries to end stake again", async () => {
            const LOCK_PERIOD = 1;

            // Stake Starts
            await token.transfer(user1, 100);
            await token.createStake(100, LOCK_PERIOD, ZERO_ADDRESS, { from: user1 });
            stakeId = await token.myLatestStakeID({ from: user1 });

            // More Time passes (10 days)
            await advanceTimeAndBlock(10 * SECONDS_IN_DAY);

            // Stake ends
            await token.endStake(stakeId, { from: user1 });
            await catchRevert(
                token.endStake(stakeId, { from: user1 }),
                "revert SWAPP: not an active stake"
            );
        });
    });

    describe("Daily Snapshot", () => {
        beforeEach(async () => {
            liquidityGuard = await LiquidityGuard.new();
            token = await SwappToken.new(liquidityGuard.address);

            const blockInfo = await web3.eth.getBlock("latest");
            launchTime = blockInfo.timestamp;
        });

        it("correct initial global data", async () => {
            const {
                totalStaked,
                totalShares,
                shareRate,
                currentSwappDay,
            } = await token.globals();

            assert.equal(totalStaked, 0);
            assert.equal(totalShares, 0);
            assert.equal(shareRate, 10);
            assert.equal(currentSwappDay, 0);
        });

        it("stake should trigger a snapshot save", async () => {
            // More than 1 day passes
            await advanceTimeAndBlock(SECONDS_IN_DAY + 1);

            // Stake Starts
            await token.transfer(user1, 1000);
            await token.createStake(100, 1, ZERO_ADDRESS, { from: user1 });

            // More Time passes (5 days)
            await advanceTimeAndBlock(5 * SECONDS_IN_DAY);

            // Second stake triggers daily snapshot of
            // snaphost is called before this stake, so this one is not stored
            await token.createStake(200, 1, ZERO_ADDRESS, { from: user1 });

            const { shareRate } = await token.globals();

            const { totalStaked, totalShares } = await token.snapshots(1);
            assert.equal(totalStaked, 100);
            assert.equal(totalShares, 100 * shareRate);
        });
    });
});
